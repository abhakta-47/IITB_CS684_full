/* --- Generated the 18/3/2025 at 22:26 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. mar. 8 9:40:4 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#ifndef LINE_FOLLOWER_H
#define LINE_FOLLOWER_H

#include "line_follower_types.h"
typedef struct Line_follower__calPidError_mem {
  long v_10;
  long v_9;
  long v_6;
  long v_5;
  long v_1;
  long v;
} Line_follower__calPidError_mem;

typedef struct Line_follower__calPidError_out {
  long pid_error;
} Line_follower__calPidError_out;

void Line_follower__calPidError_reset(Line_follower__calPidError_mem* self);

void Line_follower__calPidError_step(long value,
                                     Line_follower__calPidError_out* _out,
                                     Line_follower__calPidError_mem* self);

typedef struct Line_follower__weightedSum_out {
  long weighted_sum;
} Line_follower__weightedSum_out;

void Line_follower__weightedSum_step(long sen_value, long sen_weight,
                                     long prev_sum,
                                     Line_follower__weightedSum_out* _out);

typedef struct Line_follower__senWeightedAvg_out {
  long sensor_avg;
} Line_follower__senWeightedAvg_out;

void Line_follower__senWeightedAvg_step(long sen[5],
                                        Line_follower__senWeightedAvg_out* _out);

typedef struct Line_follower__safe_motor_update_out {
  long new_speed;
} Line_follower__safe_motor_update_out;

void Line_follower__safe_motor_update_step(long cur_speed, long change,
                                           Line_follower__safe_motor_update_out* _out);

typedef struct Line_follower__normalize_value_out {
  long norm_val;
} Line_follower__normalize_value_out;

void Line_follower__normalize_value_step(long min_val, long max_val, long value,
                                         Line_follower__normalize_value_out* _out);

typedef struct Line_follower__updateMins_out {
  long new_min;
} Line_follower__updateMins_out;

void Line_follower__updateMins_step(long cur_val, long cur_min,
                                    Line_follower__updateMins_out* _out);

typedef struct Line_follower__updateMaxs_out {
  long new_max;
} Line_follower__updateMaxs_out;

void Line_follower__updateMaxs_step(long cur_val, long cur_max,
                                    Line_follower__updateMaxs_out* _out);

typedef struct Line_follower__abs_out {
  long out;
} Line_follower__abs_out;

void Line_follower__abs_step(long input, Line_follower__abs_out* _out);

typedef struct Line_follower__main_mem {
  Line_follower__st_1 ck;
  Line_follower__st v_106;
  long v_109;
  long v_117;
  long v_115;
  long pnr_1;
  long sen_2[5];
  long max_vals_1[5];
  long min_vals_1[5];
  long pid_error_2;
  long calibrated_1;
  Line_follower__calPidError_mem calPidError;
} Line_follower__main_mem;

typedef struct Line_follower__main_out {
  long v_l;
  long v_r;
  long dir;
} Line_follower__main_out;

void Line_follower__main_reset(Line_follower__main_mem* self);

void Line_follower__main_step(long sen0, long sen1, long sen2, long sen3,
                              long sen4, Line_follower__main_out* _out,
                              Line_follower__main_mem* self);

#endif // LINE_FOLLOWER_H
