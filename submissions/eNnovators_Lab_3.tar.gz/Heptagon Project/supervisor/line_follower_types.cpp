/* --- Generated the 18/3/2025 at 22:26 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. mar. 8 9:40:4 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "line_follower_types.h"

Line_follower__st_1 Line_follower__st_1_of_string(char* s) {
  if ((strcmp(s, "St_1_WonB")==0)) {
    return Line_follower__St_1_WonB;
  };
  if ((strcmp(s, "St_1_Start")==0)) {
    return Line_follower__St_1_Start;
  };
  if ((strcmp(s, "St_1_Idle")==0)) {
    return Line_follower__St_1_Idle;
  };
  if ((strcmp(s, "St_1_Calibrate")==0)) {
    return Line_follower__St_1_Calibrate;
  };
}

char* string_of_Line_follower__st_1(Line_follower__st_1 x, char* buf) {
  switch (x) {
    case Line_follower__St_1_WonB:
      strcpy(buf, "St_1_WonB");
      break;
    case Line_follower__St_1_Start:
      strcpy(buf, "St_1_Start");
      break;
    case Line_follower__St_1_Idle:
      strcpy(buf, "St_1_Idle");
      break;
    case Line_follower__St_1_Calibrate:
      strcpy(buf, "St_1_Calibrate");
      break;
    default:
      break;
  };
  return buf;
}

Line_follower__st Line_follower__st_of_string(char* s) {
  if ((strcmp(s, "St_Recovery")==0)) {
    return Line_follower__St_Recovery;
  };
  if ((strcmp(s, "St_PID")==0)) {
    return Line_follower__St_PID;
  };
}

char* string_of_Line_follower__st(Line_follower__st x, char* buf) {
  switch (x) {
    case Line_follower__St_Recovery:
      strcpy(buf, "St_Recovery");
      break;
    case Line_follower__St_PID:
      strcpy(buf, "St_PID");
      break;
    default:
      break;
  };
  return buf;
}

