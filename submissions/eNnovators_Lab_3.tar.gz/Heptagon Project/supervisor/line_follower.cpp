/* --- Generated the 18/3/2025 at 22:26 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. mar. 8 9:40:4 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "line_follower.h"

void Line_follower__calPidError_reset(Line_follower__calPidError_mem* self) {
  self->v_9 = true;
  self->v_5 = true;
  self->v = true;
}

void Line_follower__calPidError_step(long value,
                                     Line_follower__calPidError_out* _out,
                                     Line_follower__calPidError_mem* self) {
  
  long v_16;
  long v_15;
  long v_14;
  long v_13;
  long v_12;
  long v_11;
  long v_8;
  long v_7;
  long v_4;
  long v_3;
  long v_2;
  long p;
  long i;
  long d;
  if (self->v_9) {
    v_11 = 0;
  } else {
    v_11 = self->v_10;
  };
  d = (value-v_11);
  v_15 = (Line_follower__kd*d);
  v_7 = (self->v_6+value);
  if (self->v_5) {
    v_8 = 0;
  } else {
    v_8 = v_7;
  };
  v_2 = (self->v_1+value);
  if (self->v) {
    v_3 = 0;
  } else {
    v_3 = v_2;
  };
  v_4 = (v_3<=Line_follower__max_i);
  if (v_4) {
    i = v_8;
  } else {
    i = 200000000;
  };
  v_13 = (Line_follower__ki*i);
  p = value;
  v_12 = (Line_follower__kp*p);
  v_14 = (v_12+v_13);
  v_16 = (v_14+v_15);
  _out->pid_error = (v_16/Line_follower__kscale);
  self->v_10 = value;
  self->v_9 = false;
  self->v_6 = i;
  self->v_5 = false;
  self->v_1 = i;
  self->v = false;;
}

void Line_follower__weightedSum_step(long sen_value, long sen_weight,
                                     long prev_sum,
                                     Line_follower__weightedSum_out* _out) {
  
  long v;
  v = (sen_value*sen_weight);
  _out->weighted_sum = (prev_sum+v);;
}

void Line_follower__senWeightedAvg_step(long sen[5],
                                        Line_follower__senWeightedAvg_out* _out) {
  Line_follower__weightedSum_out Line_follower__weightedSum_out_st;
  
  long v_20;
  long v_19;
  long v_18;
  long v_17;
  long v;
  long aritmetic_sum;
  v_19 = 0;
  {
    long i_5;
    for (i_5 = 0; i_5 < 5; ++i_5) {
      Line_follower__weightedSum_step(sen[i_5],
                                      Line_follower__sensor_weights[i_5],
                                      v_19,
                                      &Line_follower__weightedSum_out_st);
      v_19 = Line_follower__weightedSum_out_st.weighted_sum;
    }
  };
  v_17 = sen[2];
  v = 0;
  {
    long i;
    for (i = 0; i < 5; ++i) {
      v = (sen[i]+v);
    }
  };
  aritmetic_sum = (v-v_17);
  v_20 = (v_19/aritmetic_sum);
  v_18 = (aritmetic_sum==0);
  if (v_18) {
    _out->sensor_avg = 0;
  } else {
    _out->sensor_avg = v_20;
  };;
}

void Line_follower__safe_motor_update_step(long cur_speed, long change,
                                           Line_follower__safe_motor_update_out* _out) {
  
  long v_25;
  long v_24;
  long v_23;
  long v_22;
  long v_21;
  long v;
  v_24 = (cur_speed+change);
  v_22 = (cur_speed+change);
  v_23 = (v_22<0);
  if (v_23) {
    v_25 = 0;
  } else {
    v_25 = v_24;
  };
  v = (cur_speed+change);
  v_21 = (v>100);
  if (v_21) {
    _out->new_speed = 100;
  } else {
    _out->new_speed = v_25;
  };;
}

void Line_follower__normalize_value_step(long min_val, long max_val, long value,
                                         Line_follower__normalize_value_out* _out) {
  
  long v_30;
  long v_29;
  long v_28;
  long v_27;
  long v_26;
  long v;
  long safe_val;
  v_30 = (max_val-min_val);
  v_26 = (value<=min_val);
  if (v_26) {
    v_27 = min_val;
  } else {
    v_27 = value;
  };
  v = (value>=max_val);
  if (v) {
    safe_val = max_val;
  } else {
    safe_val = v_27;
  };
  v_28 = (safe_val-min_val);
  v_29 = (v_28*1000);
  _out->norm_val = (v_29/v_30);;
}

void Line_follower__updateMins_step(long cur_val, long cur_min,
                                    Line_follower__updateMins_out* _out) {
  
  long v_33;
  long v_32;
  long v_31;
  long v;
  v_32 = (cur_val<cur_min);
  v = (cur_val==0);
  v_31 = !(v);
  v_33 = (v_31&&v_32);
  if (v_33) {
    _out->new_min = cur_val;
  } else {
    _out->new_min = cur_min;
  };;
}

void Line_follower__updateMaxs_step(long cur_val, long cur_max,
                                    Line_follower__updateMaxs_out* _out) {
  
  long v;
  v = (cur_val>cur_max);
  if (v) {
    _out->new_max = cur_val;
  } else {
    _out->new_max = cur_max;
  };;
}

void Line_follower__abs_step(long input, Line_follower__abs_out* _out) {
  
  long v_34;
  long v;
  v_34 = (-1*input);
  v = (input>=0);
  if (v) {
    _out->out = input;
  } else {
    _out->out = v_34;
  };;
}

void Line_follower__main_reset(Line_follower__main_mem* self) {
  {
    long i_4;
    for (i_4 = 0; i_4 < 5; ++i_4) {
    }
  };
  {
    long i_3;
    for (i_3 = 0; i_3 < 5; ++i_3) {
    }
  };
  {
    long i_2;
    for (i_2 = 0; i_2 < 5; ++i_2) {
    }
  };
  Line_follower__calPidError_reset(&self->calPidError);
  {
    long i_1;
    for (i_1 = 0; i_1 < 5; ++i_1) {
    }
  };
  self->v_115 = true;
  self->v_109 = false;
  self->v_106 = Line_follower__St_PID;
  self->sen_2[0] = 0;
  self->sen_2[1] = 0;
  self->sen_2[2] = 0;
  self->sen_2[3] = 0;
  self->sen_2[4] = 0;
  self->max_vals_1[0] = 0;
  self->max_vals_1[1] = 0;
  self->max_vals_1[2] = 0;
  self->max_vals_1[3] = 0;
  self->max_vals_1[4] = 0;
  self->min_vals_1[0] = 10000;
  self->min_vals_1[1] = 10000;
  self->min_vals_1[2] = 10000;
  self->min_vals_1[3] = 800;
  self->min_vals_1[4] = 10000;
  self->pid_error_2 = 0;
  self->calibrated_1 = false;
  self->pnr_1 = false;
  self->ck = Line_follower__St_1_Calibrate;
}

void Line_follower__main_step(long sen0, long sen1, long sen2, long sen3,
                              long sen4, Line_follower__main_out* _out,
                              Line_follower__main_mem* self) {
  Line_follower__normalize_value_out Line_follower__normalize_value_out_st;
  Line_follower__calPidError_out Line_follower__calPidError_out_st;
  Line_follower__updateMins_out Line_follower__updateMins_out_st;
  Line_follower__updateMaxs_out Line_follower__updateMaxs_out_st;
  Line_follower__senWeightedAvg_out Line_follower__senWeightedAvg_out_st;
  Line_follower__safe_motor_update_out Line_follower__safe_motor_update_out_st;
  
  long r_1_St_1_WonB;
  Line_follower__st_1 s_1_St_1_WonB;
  long r_1_St_1_Start;
  Line_follower__st_1 s_1_St_1_Start;
  long r_1_St_1_Idle;
  Line_follower__st_1 s_1_St_1_Idle;
  long r_1_St_1_Calibrate;
  Line_follower__st_1 s_1_St_1_Calibrate;
  long r_St_Recovery;
  Line_follower__st s_St_Recovery;
  long r_St_PID;
  Line_follower__st s_St_PID;
  Line_follower__st ck_2;
  long v_107;
  long v_108;
  long nr_St_Recovery;
  Line_follower__st ns_St_Recovery;
  long dir_St_1_WonB_St_Recovery;
  long v_r_St_1_WonB_St_Recovery;
  long v_l_St_1_WonB_St_Recovery;
  long nr_St_PID;
  Line_follower__st ns_St_PID;
  long dir_St_1_WonB_St_PID;
  long v_r_St_1_WonB_St_PID;
  long v_l_St_1_WonB_St_PID;
  Line_follower__st ck_3;
  Line_follower__st s;
  Line_follower__st ns;
  long r;
  long nr;
  long pnr;
  long v_110;
  long v_118;
  long v_116;
  long v_114;
  long v_113;
  long v_112;
  long v_111;
  long ncycles;
  long nr_1_St_1_WonB;
  Line_follower__st_1 ns_1_St_1_WonB;
  long calibrated_St_1_WonB;
  long dir_St_1_WonB;
  long v_r_St_1_WonB;
  long v_l_St_1_WonB;
  long nr_1_St_1_Start;
  Line_follower__st_1 ns_1_St_1_Start;
  long calibrated_St_1_Start;
  long dir_St_1_Start;
  long v_r_St_1_Start;
  long v_l_St_1_Start;
  long nr_1_St_1_Idle;
  Line_follower__st_1 ns_1_St_1_Idle;
  long calibrated_St_1_Idle;
  long dir_St_1_Idle;
  long v_r_St_1_Idle;
  long v_l_St_1_Idle;
  long nr_1_St_1_Calibrate;
  Line_follower__st_1 ns_1_St_1_Calibrate;
  long calibrated_St_1_Calibrate;
  long dir_St_1_Calibrate;
  long v_r_St_1_Calibrate;
  long v_l_St_1_Calibrate;
  Line_follower__st_1 ck_1;
  long v_105;
  long v_104;
  long v_103;
  long v_102;
  long v_101;
  long v_100;
  long v_99;
  long v_98;
  long v_97;
  long v_96;
  long v_95;
  long v_94;
  long v_93;
  long v_92;
  long v_91;
  long v_90;
  long v_89;
  long v_88;
  long v_87;
  long v_86;
  long v_85;
  long v_84;
  long v_83;
  long v_82;
  long v_81;
  long v_80;
  long v_79;
  long v_78;
  long v_77;
  long v_76;
  long v_75;
  long v_74;
  long v_73;
  long v_72;
  long v_71;
  long v_70;
  long v_69;
  long v_68;
  long v_67;
  long v_66;
  long v_65;
  long v_64;
  long v_63;
  long v_62;
  long v_61;
  long v_60;
  long v_59;
  long v_58;
  long v_57;
  long v_56;
  long v_55;
  long v_54;
  long v_53;
  long v_52;
  long v_51;
  long v_50;
  long v_49;
  long v_48;
  long v_47;
  long v_46;
  long v_45;
  long v_44;
  long v_43;
  long v_42;
  long v_41;
  long v_40;
  long v_39;
  long v_38;
  long v_37;
  long v_36;
  long v_35[5];
  long v[5];
  Line_follower__st_1 s_1;
  Line_follower__st_1 ns_1;
  long r_1;
  long nr_1;
  long raw_sen[5];
  long norm_sen[5];
  long sensor_arithmetic_sum;
  long sensor_avg;
  long all_low;
  long any_high;
  long all_high;
  long only_middle_high;
  long only_middle_low;
  long calibrated;
  long pid_error;
  long min_vals[5];
  long max_vals[5];
  long sen[5];
  switch (self->ck) {
    case Line_follower__St_1_Calibrate:
      r_1_St_1_Calibrate = self->pnr_1;
      s_1_St_1_Calibrate = Line_follower__St_1_Calibrate;
      break;
    case Line_follower__St_1_Start:
      r_1_St_1_Start = self->pnr_1;
      s_1_St_1_Start = Line_follower__St_1_Start;
      break;
    case Line_follower__St_1_WonB:
      r_1_St_1_WonB = self->pnr_1;
      s_1_St_1_WonB = Line_follower__St_1_WonB;
      break;
    default:
      break;
  };
  raw_sen[0] = sen0;
  raw_sen[1] = sen1;
  raw_sen[2] = sen2;
  raw_sen[3] = sen3;
  raw_sen[4] = sen4;
  {
    long i_4;
    for (i_4 = 0; i_4 < 5; ++i_4) {
      Line_follower__updateMaxs_step(raw_sen[i_4], self->max_vals_1[i_4],
                                     &Line_follower__updateMaxs_out_st);
      v_35[i_4] = Line_follower__updateMaxs_out_st.new_max;
    }
  };
  if (self->calibrated_1) {
    {
      long _2;
      for (_2 = 0; _2 < 5; ++_2) {
        max_vals[_2] = self->max_vals_1[_2];
      }
    };
  } else {
    {
      long _3;
      for (_3 = 0; _3 < 5; ++_3) {
        max_vals[_3] = v_35[_3];
      }
    };
  };
  {
    long i_3;
    for (i_3 = 0; i_3 < 5; ++i_3) {
      Line_follower__updateMins_step(raw_sen[i_3], self->min_vals_1[i_3],
                                     &Line_follower__updateMins_out_st);
      v[i_3] = Line_follower__updateMins_out_st.new_min;
    }
  };
  if (self->calibrated_1) {
    {
      long _4;
      for (_4 = 0; _4 < 5; ++_4) {
        min_vals[_4] = self->min_vals_1[_4];
      }
    };
  } else {
    {
      long _5;
      for (_5 = 0; _5 < 5; ++_5) {
        min_vals[_5] = v[_5];
      }
    };
  };
  {
    long i_2;
    for (i_2 = 0; i_2 < 5; ++i_2) {
      Line_follower__normalize_value_step(min_vals[i_2], max_vals[i_2],
                                          raw_sen[i_2],
                                          &Line_follower__normalize_value_out_st);
      norm_sen[i_2] = Line_follower__normalize_value_out_st.norm_val;
    }
  };
  v_40 = norm_sen[4];
  v_39 = norm_sen[3];
  v_38 = norm_sen[2];
  v_37 = norm_sen[1];
  v_36 = norm_sen[0];
  sen[0] = v_36;
  sen[1] = v_37;
  sen[2] = v_38;
  sen[3] = v_39;
  sen[4] = v_40;
  v_104 = sen[4];
  v_105 = (v_104>=Line_follower__black_thresh);
  v_101 = sen[3];
  v_102 = (v_101>=Line_follower__black_thresh);
  v_98 = sen[2];
  v_99 = (v_98>=Line_follower__black_thresh);
  v_95 = sen[1];
  v_96 = (v_95>=Line_follower__black_thresh);
  v_93 = sen[0];
  v_94 = (v_93>=Line_follower__black_thresh);
  v_97 = (v_94&&v_96);
  v_100 = (v_97&&v_99);
  v_103 = (v_100&&v_102);
  all_high = (v_103&&v_105);
  v_91 = sen[4];
  v_92 = (v_91>=Line_follower__black_thresh);
  v_88 = sen[3];
  v_89 = (v_88>=Line_follower__black_thresh);
  v_85 = sen[2];
  v_86 = (v_85<=Line_follower__white_thresh);
  v_82 = sen[1];
  v_83 = (v_82>=Line_follower__black_thresh);
  v_80 = sen[0];
  v_81 = (v_80>=Line_follower__black_thresh);
  v_84 = (v_81&&v_83);
  v_87 = (v_84&&v_86);
  v_90 = (v_87&&v_89);
  only_middle_low = (v_90&&v_92);
  v_78 = sen[4];
  v_79 = (v_78<=Line_follower__white_thresh);
  v_75 = sen[3];
  v_76 = (v_75<=Line_follower__white_thresh);
  v_72 = sen[2];
  v_73 = (v_72>=Line_follower__black_thresh);
  v_69 = sen[1];
  v_70 = (v_69<=Line_follower__white_thresh);
  v_67 = sen[0];
  v_68 = (v_67<=Line_follower__white_thresh);
  v_71 = (v_68&&v_70);
  v_74 = (v_71&&v_73);
  v_77 = (v_74&&v_76);
  only_middle_high = (v_77&&v_79);
  v_65 = sen[4];
  v_66 = (v_65>=Line_follower__black_thresh);
  v_62 = sen[3];
  v_63 = (v_62>=Line_follower__black_thresh);
  v_59 = sen[2];
  v_60 = (v_59>=Line_follower__black_thresh);
  v_56 = sen[1];
  v_57 = (v_56>=Line_follower__black_thresh);
  v_54 = sen[0];
  v_55 = (v_54>=Line_follower__black_thresh);
  v_58 = (v_55||v_57);
  v_61 = (v_58||v_60);
  v_64 = (v_61||v_63);
  any_high = (v_64||v_66);
  v_52 = sen[4];
  v_53 = (v_52<=Line_follower__white_thresh);
  v_49 = sen[3];
  v_50 = (v_49<=Line_follower__white_thresh);
  v_46 = sen[2];
  v_47 = (v_46<=Line_follower__white_thresh);
  v_43 = sen[1];
  v_44 = (v_43<=Line_follower__white_thresh);
  v_41 = sen[0];
  v_42 = (v_41<=Line_follower__white_thresh);
  v_45 = (v_42&&v_44);
  v_48 = (v_45&&v_47);
  v_51 = (v_48&&v_50);
  all_low = (v_51&&v_53);
  Line_follower__senWeightedAvg_step(sen,
                                     &Line_follower__senWeightedAvg_out_st);
  sensor_avg = Line_follower__senWeightedAvg_out_st.sensor_avg;
  Line_follower__calPidError_step(sensor_avg,
                                  &Line_follower__calPidError_out_st,
                                  &self->calPidError);
  pid_error = Line_follower__calPidError_out_st.pid_error;
  sensor_arithmetic_sum = 0;
  {
    long i_1;
    for (i_1 = 0; i_1 < 5; ++i_1) {
      sensor_arithmetic_sum = (sen[i_1]+sensor_arithmetic_sum);
    }
  };
  switch (self->ck) {
    case Line_follower__St_1_Idle:
      if (all_high) {
        r_1_St_1_Idle = true;
        s_1_St_1_Idle = Line_follower__St_1_Start;
      } else {
        r_1_St_1_Idle = self->pnr_1;
        s_1_St_1_Idle = Line_follower__St_1_Idle;
      };
      s_1 = s_1_St_1_Idle;
      r_1 = r_1_St_1_Idle;
      break;
    case Line_follower__St_1_WonB:
      s_1 = s_1_St_1_WonB;
      r_1 = r_1_St_1_WonB;
      break;
    case Line_follower__St_1_Start:
      s_1 = s_1_St_1_Start;
      r_1 = r_1_St_1_Start;
      break;
    case Line_follower__St_1_Calibrate:
      s_1 = s_1_St_1_Calibrate;
      r_1 = r_1_St_1_Calibrate;
      break;
    default:
      break;
  };
  ck_1 = s_1;
  switch (ck_1) {
    case Line_follower__St_1_Calibrate:
      calibrated_St_1_Calibrate = self->calibrated_1;
      v_118 = (self->v_117+1);
      if (self->v_115) {
        v_116 = true;
      } else {
        v_116 = r_1;
      };
      if (v_116) {
        ncycles = 0;
      } else {
        ncycles = v_118;
      };
      dir_St_1_Calibrate = 3;
      v_r_St_1_Calibrate = 60;
      v_l_St_1_Calibrate = 60;
      v_112 = (ncycles>=150);
      v_113 = (all_high||v_112);
      v_111 = (ncycles>=100);
      v_114 = (v_111&&v_113);
      if (v_114) {
        nr_1_St_1_Calibrate = true;
        ns_1_St_1_Calibrate = Line_follower__St_1_Idle;
      } else {
        nr_1_St_1_Calibrate = false;
        ns_1_St_1_Calibrate = Line_follower__St_1_Calibrate;
      };
      calibrated = calibrated_St_1_Calibrate;
      ns_1 = ns_1_St_1_Calibrate;
      nr_1 = nr_1_St_1_Calibrate;
      _out->v_l = v_l_St_1_Calibrate;
      _out->v_r = v_r_St_1_Calibrate;
      _out->dir = dir_St_1_Calibrate;
      self->v_117 = ncycles;
      self->v_115 = false;
      break;
    case Line_follower__St_1_Idle:
      dir_St_1_Idle = 0;
      v_r_St_1_Idle = 0;
      v_l_St_1_Idle = 0;
      calibrated_St_1_Idle = true;
      nr_1_St_1_Idle = false;
      ns_1_St_1_Idle = Line_follower__St_1_Idle;
      calibrated = calibrated_St_1_Idle;
      ns_1 = ns_1_St_1_Idle;
      nr_1 = nr_1_St_1_Idle;
      _out->v_l = v_l_St_1_Idle;
      _out->v_r = v_r_St_1_Idle;
      _out->dir = dir_St_1_Idle;
      break;
    case Line_follower__St_1_Start:
      dir_St_1_Start = 1;
      v_r_St_1_Start = 30;
      v_l_St_1_Start = 30;
      calibrated_St_1_Start = true;
      v_110 = !(all_high);
      if (v_110) {
        nr_1_St_1_Start = true;
        ns_1_St_1_Start = Line_follower__St_1_WonB;
      } else {
        nr_1_St_1_Start = false;
        ns_1_St_1_Start = Line_follower__St_1_Start;
      };
      calibrated = calibrated_St_1_Start;
      ns_1 = ns_1_St_1_Start;
      nr_1 = nr_1_St_1_Start;
      _out->v_l = v_l_St_1_Start;
      _out->v_r = v_r_St_1_Start;
      _out->dir = dir_St_1_Start;
      break;
    case Line_follower__St_1_WonB:
      if (r_1) {
        pnr = false;
        ck_2 = Line_follower__St_PID;
      } else {
        pnr = self->v_109;
        ck_2 = self->v_106;
      };
      calibrated_St_1_WonB = true;
      nr_1_St_1_WonB = false;
      ns_1_St_1_WonB = Line_follower__St_1_WonB;
      calibrated = calibrated_St_1_WonB;
      ns_1 = ns_1_St_1_WonB;
      nr_1 = nr_1_St_1_WonB;
      switch (ck_2) {
        case Line_follower__St_PID:
          if (all_low) {
            r_St_PID = true;
            s_St_PID = Line_follower__St_Recovery;
          } else {
            r_St_PID = pnr;
            s_St_PID = Line_follower__St_PID;
          };
          s = s_St_PID;
          r = r_St_PID;
          break;
        case Line_follower__St_Recovery:
          r_St_Recovery = pnr;
          s_St_Recovery = Line_follower__St_Recovery;
          s = s_St_Recovery;
          r = r_St_Recovery;
          break;
        default:
          break;
      };
      ck_3 = s;
      switch (ck_3) {
        case Line_follower__St_PID:
          dir_St_1_WonB_St_PID = 1;
          v_108 = (-1*pid_error);
          Line_follower__safe_motor_update_step(Line_follower__base_speed,
                                                v_108,
                                                &Line_follower__safe_motor_update_out_st);
          v_r_St_1_WonB_St_PID = Line_follower__safe_motor_update_out_st.new_speed;
          Line_follower__safe_motor_update_step(Line_follower__base_speed,
                                                pid_error,
                                                &Line_follower__safe_motor_update_out_st);
          v_l_St_1_WonB_St_PID = Line_follower__safe_motor_update_out_st.new_speed;
          nr_St_PID = false;
          ns_St_PID = Line_follower__St_PID;
          v_l_St_1_WonB = v_l_St_1_WonB_St_PID;
          v_r_St_1_WonB = v_r_St_1_WonB_St_PID;
          dir_St_1_WonB = dir_St_1_WonB_St_PID;
          ns = ns_St_PID;
          nr = nr_St_PID;
          break;
        case Line_follower__St_Recovery:
          dir_St_1_WonB_St_Recovery = 4;
          v_r_St_1_WonB_St_Recovery = 30;
          v_l_St_1_WonB_St_Recovery = 30;
          v_107 = !(all_low);
          if (v_107) {
            nr_St_Recovery = true;
            ns_St_Recovery = Line_follower__St_PID;
          } else {
            nr_St_Recovery = false;
            ns_St_Recovery = Line_follower__St_Recovery;
          };
          v_l_St_1_WonB = v_l_St_1_WonB_St_Recovery;
          v_r_St_1_WonB = v_r_St_1_WonB_St_Recovery;
          dir_St_1_WonB = dir_St_1_WonB_St_Recovery;
          ns = ns_St_Recovery;
          nr = nr_St_Recovery;
          break;
        default:
          break;
      };
      _out->v_l = v_l_St_1_WonB;
      _out->v_r = v_r_St_1_WonB;
      _out->dir = dir_St_1_WonB;
      self->v_109 = nr;
      self->v_106 = ns;
      break;
    default:
      break;
  };
  {
    long _6;
    for (_6 = 0; _6 < 5; ++_6) {
      self->sen_2[_6] = sen[_6];
    }
  };
  {
    long _7;
    for (_7 = 0; _7 < 5; ++_7) {
      self->max_vals_1[_7] = max_vals[_7];
    }
  };
  {
    long _8;
    for (_8 = 0; _8 < 5; ++_8) {
      self->min_vals_1[_8] = min_vals[_8];
    }
  };
  self->pid_error_2 = pid_error;
  self->calibrated_1 = calibrated;
  self->pnr_1 = nr_1;
  self->ck = ns_1;;
}

