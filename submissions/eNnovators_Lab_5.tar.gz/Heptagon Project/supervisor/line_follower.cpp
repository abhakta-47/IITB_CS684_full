/* --- Generated the 8/4/2025 at 16:58 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. mar. 8 9:40:4 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "line_follower.h"

void Line_follower__calPidError_reset(Line_follower__calPidError_mem* self) {
  self->v_9 = true;
  self->v_5 = true;
  self->v = true;
}

void Line_follower__calPidError_step(long value, long scale_down,
                                     Line_follower__calPidError_out* _out,
                                     Line_follower__calPidError_mem* self) {
  
  long v_16;
  long v_15;
  long v_14;
  long v_13;
  long v_12;
  long v_11;
  long v_8;
  long v_7;
  long v_4;
  long v_3;
  long v_2;
  long p;
  long i;
  long d;
  if (self->v_9) {
    v_11 = 0;
  } else {
    v_11 = self->v_10;
  };
  d = (value-v_11);
  v_15 = (Line_follower__kd*d);
  v_7 = (self->v_6+value);
  if (self->v_5) {
    v_8 = 0;
  } else {
    v_8 = v_7;
  };
  v_2 = (self->v_1+value);
  if (self->v) {
    v_3 = 0;
  } else {
    v_3 = v_2;
  };
  v_4 = (v_3<=Line_follower__max_i);
  if (v_4) {
    i = v_8;
  } else {
    i = 200000000;
  };
  v_13 = (Line_follower__ki*i);
  p = value;
  v_12 = (Line_follower__kp*p);
  v_14 = (v_12+v_13);
  v_16 = (v_14+v_15);
  _out->pid_error = (v_16/scale_down);
  self->v_10 = value;
  self->v_9 = false;
  self->v_6 = i;
  self->v_5 = false;
  self->v_1 = i;
  self->v = false;;
}

void Line_follower__weightedSum_step(long sen_value, long sen_weight,
                                     long prev_sum,
                                     Line_follower__weightedSum_out* _out) {
  
  long v;
  v = (sen_value*sen_weight);
  _out->weighted_sum = (prev_sum+v);;
}

void Line_follower__senWeightedAvg_step(long sen[5],
                                        Line_follower__senWeightedAvg_out* _out) {
  Line_follower__weightedSum_out Line_follower__weightedSum_out_st;
  
  long v_19;
  long v_18;
  long v_17;
  long v;
  long aritmetic_sum;
  v_19 = 0;
  {
    long i_9;
    for (i_9 = 0; i_9 < 5; ++i_9) {
      Line_follower__weightedSum_step(sen[i_9],
                                      Line_follower__sensor_weights[i_9],
                                      v_19,
                                      &Line_follower__weightedSum_out_st);
      v_19 = Line_follower__weightedSum_out_st.weighted_sum;
    }
  };
  v_17 = sen[2];
  v = 0;
  {
    long i;
    for (i = 0; i < 5; ++i) {
      v = (sen[i]+v);
    }
  };
  aritmetic_sum = (v-v_17);
  v_18 = (aritmetic_sum==0);
  if (v_18) {
    _out->sensor_avg = 0;
  } else {
    _out->sensor_avg = v_19;
  };;
}

void Line_follower__safe_motor_update_step(long cur_speed, long change,
                                           Line_follower__safe_motor_update_out* _out) {
  
  long v_24;
  long v_23;
  long v_22;
  long v_21;
  long v_20;
  long v;
  v_23 = (cur_speed+change);
  v_21 = (cur_speed+change);
  v_22 = (v_21<0);
  if (v_22) {
    v_24 = 0;
  } else {
    v_24 = v_23;
  };
  v = (cur_speed+change);
  v_20 = (v>100);
  if (v_20) {
    _out->new_speed = 100;
  } else {
    _out->new_speed = v_24;
  };;
}

void Line_follower__normalize_value_step(long min_val, long max_val, long value,
                                         Line_follower__normalize_value_out* _out) {
  
  long v_29;
  long v_28;
  long v_27;
  long v_26;
  long v_25;
  long v;
  long safe_val;
  v_29 = (max_val-min_val);
  v_25 = (value<=min_val);
  if (v_25) {
    v_26 = min_val;
  } else {
    v_26 = value;
  };
  v = (value>=max_val);
  if (v) {
    safe_val = max_val;
  } else {
    safe_val = v_26;
  };
  v_27 = (safe_val-min_val);
  v_28 = (v_27*1000);
  _out->norm_val = (v_28/v_29);;
}

void Line_follower__updateMins_step(long cur_val, long cur_thresh, long cur_min,
                                    Line_follower__updateMins_out* _out) {
  
  long v_31;
  long v_30;
  long v;
  v_30 = (cur_val<cur_thresh);
  v = (cur_val>cur_min);
  v_31 = (v&&v_30);
  if (v_31) {
    _out->new_min = cur_val;
  } else {
    _out->new_min = cur_min;
  };;
}

void Line_follower__updateMaxs_step(long cur_val, long cur_thresh, long cur_max,
                                    Line_follower__updateMaxs_out* _out) {
  
  long v_33;
  long v_32;
  long v;
  v_32 = (cur_val>cur_thresh);
  v = (cur_val<cur_max);
  v_33 = (v&&v_32);
  if (v_33) {
    _out->new_max = cur_val;
  } else {
    _out->new_max = cur_max;
  };;
}

void Line_follower__max_step(long val_a, long val_b,
                             Line_follower__max_out* _out) {
  
  long v;
  v = (val_a>=val_b);
  if (v) {
    _out->val_m = val_a;
  } else {
    _out->val_m = val_b;
  };;
}

void Line_follower__abs_step(long input, Line_follower__abs_out* _out) {
  
  long v_34;
  long v;
  v_34 = (-1*input);
  v = (input>=0);
  if (v) {
    _out->out = input;
  } else {
    _out->out = v_34;
  };;
}

void Line_follower__pid_err_to_speeds_park_step(long pid_error,
                                                Line_follower__pid_err_to_speeds_park_out* _out) {
  Line_follower__abs_out Line_follower__abs_out_st;
  Line_follower__safe_motor_update_out Line_follower__safe_motor_update_out_st;
  
  long v_42;
  long v_41;
  long v_40;
  long v_39;
  long v_38;
  long v_37;
  long v_36;
  long v_35;
  long v;
  long sharp_thresh;
  _out->dir = 1;
  v_40 = (-1*pid_error);
  v_41 = (v_40/2);
  Line_follower__safe_motor_update_step(Line_follower__safe_speed_park, v_41,
                                        &Line_follower__safe_motor_update_out_st);
  v_42 = Line_follower__safe_motor_update_out_st.new_speed;
  Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
  v_38 = Line_follower__abs_out_st.out;
  v_36 = (pid_error/2);
  Line_follower__safe_motor_update_step(Line_follower__safe_speed_park, v_36,
                                        &Line_follower__safe_motor_update_out_st);
  v_37 = Line_follower__safe_motor_update_out_st.new_speed;
  Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
  v = Line_follower__abs_out_st.out;
  sharp_thresh = 40;
  v_39 = (v_38<=sharp_thresh);
  if (v_39) {
    _out->v_r = v_42;
  } else {
    _out->v_r = 100;
  };
  v_35 = (v<=sharp_thresh);
  if (v_35) {
    _out->v_l = v_37;
  } else {
    _out->v_l = 100;
  };;
}

void Line_follower__main_reset(Line_follower__main_mem* self) {
  {
    long i_8;
    for (i_8 = 0; i_8 < 5; ++i_8) {
    }
  };
  Line_follower__calPidError_reset(&self->calPidError_4);
  Line_follower__calPidError_reset(&self->calPidError_5);
  Line_follower__calPidError_reset(&self->calPidError_3);
  Line_follower__calPidError_reset(&self->calPidError_2);
  Line_follower__calPidError_reset(&self->calPidError_1);
  Line_follower__calPidError_reset(&self->calPidError);
  {
    long i_7;
    for (i_7 = 0; i_7 < 5; ++i_7) {
    }
  };
  {
    long i_6;
    for (i_6 = 0; i_6 < 5; ++i_6) {
    }
  };
  self->v_447 = false;
  self->v_414 = Line_follower__St_PID;
  self->v_352 = false;
  self->v_351 = Line_follower__St_1_Counter;
  self->v_255 = false;
  self->v_216 = Line_follower__St_3_Wait;
  self->v_172 = false;
  self->v_171 = Line_follower__St_4_Train;
  self->parking_cycles_thresh_1 = 0;
  self->inx_counter_1 = 0;
  self->sen_2[0] = 0;
  self->sen_2[1] = 0;
  self->sen_2[2] = 0;
  self->sen_2[3] = 0;
  self->sen_2[4] = 0;
  self->thresh_vals_1[0] = 500;
  self->thresh_vals_1[1] = 500;
  self->thresh_vals_1[2] = 500;
  self->thresh_vals_1[3] = 700;
  self->thresh_vals_1[4] = 500;
  self->min_vals_1[0] = 0;
  self->min_vals_1[1] = 0;
  self->min_vals_1[2] = 0;
  self->min_vals_1[3] = 0;
  self->min_vals_1[4] = 0;
  self->max_vals_1[0] = 1023;
  self->max_vals_1[1] = 1023;
  self->max_vals_1[2] = 1023;
  self->max_vals_1[3] = 1023;
  self->max_vals_1[4] = 1023;
  self->last_error_1 = 0;
  self->pid_error_11 = 0;
  self->pnr_5 = false;
  self->ck = Line_follower__St_5_Calibrate;
  self->v_249 = true;
  self->v_243 = true;
  self->v_242 = false;
  self->v_239 = Line_follower__St_2_St_high_0;
  self->v_224 = true;
  self->v_217 = true;
  self->v_154 = true;
  self->v_146 = true;
  self->v_141 = true;
  self->v_136 = true;
  self->v_127 = true;
  self->v_121 = true;
  self->v_108 = true;
  self->v_100 = true;
  self->v_92 = true;
  self->v_84 = true;
  self->v_76 = true;
}

void Line_follower__main_step(long sen0, long sen1, long sen2, long sen3,
                              long sen4, long ir_value, long obs_left,
                              long obs_right, Line_follower__main_out* _out,
                              Line_follower__main_mem* self) {
  Line_follower__normalize_value_out Line_follower__normalize_value_out_st;
  Line_follower__updateMaxs_out Line_follower__updateMaxs_out_st;
  Line_follower__pid_err_to_speeds_park_out Line_follower__pid_err_to_speeds_park_out_st;
  Line_follower__safe_motor_update_out Line_follower__safe_motor_update_out_st;
  Line_follower__abs_out Line_follower__abs_out_st;
  Line_follower__calPidError_out Line_follower__calPidError_out_st;
  Line_follower__max_out Line_follower__max_out_st;
  Line_follower__updateMins_out Line_follower__updateMins_out_st;
  Line_follower__senWeightedAvg_out Line_follower__senWeightedAvg_out_st;
  
  long v_56;
  long v_55;
  long v_58;
  long v_57;
  long v_72;
  long v_71;
  long v_70;
  long v_69;
  long v_68;
  long v_67;
  long v_66;
  long v_65;
  long v_64;
  long v_63;
  long v_62;
  long v_61;
  long v_60;
  long v_59;
  long r_5_St_5_Parking;
  Line_follower__st_5 s_5_St_5_Parking;
  long r_5_St_5_ObstacleAvoid;
  Line_follower__st_5 s_5_St_5_ObstacleAvoid;
  long r_5_St_5_Intersection;
  Line_follower__st_5 s_5_St_5_Intersection;
  long r_5_St_5_BonW;
  Line_follower__st_5 s_5_St_5_BonW;
  long r_5_St_5_WonB;
  Line_follower__st_5 s_5_St_5_WonB;
  long r_5_St_5_Start;
  Line_follower__st_5 s_5_St_5_Start;
  long r_5_St_5_Idle;
  Line_follower__st_5 s_5_St_5_Idle;
  long r_5_St_5_Calibrate;
  Line_follower__st_5 s_5_St_5_Calibrate;
  long v_80;
  long v_78;
  long v_77;
  long v_75;
  long v_74;
  long v_73;
  long ncycles_6;
  long v_88;
  long v_86;
  long v_85;
  long v_83;
  long v_82;
  long v_81;
  long ncycles_5;
  long v_96;
  long v_94;
  long v_93;
  long v_91;
  long v_90;
  long v_89;
  long ncycles_4;
  long v_104;
  long v_102;
  long v_101;
  long v_99;
  long v_98;
  long v_97;
  long r_6;
  long locdir_1;
  long ncycles_3;
  long v_112;
  long v_110;
  long v_109;
  long v_107;
  long v_106;
  long v_105;
  long r_7;
  long locdir;
  long ncycles_2;
  long v_132;
  long v_131;
  long v_129;
  long v_128;
  long v_126;
  long v_125;
  long v_123;
  long v_122;
  long v_120;
  Line_follower__st_4 v_119;
  long v_118;
  long v_117;
  long v_116;
  long v_115;
  long v_114;
  long v_113;
  long r_8;
  long cycles_left_1;
  long cycles_right_1;
  long v_170;
  long v_169;
  long v_168;
  long v_167;
  long v_166;
  long v_165;
  long v_164;
  long v_163;
  long v_162;
  long v_161;
  long v_160;
  long v_158;
  long v_157;
  long v_156;
  long v_155;
  long v_153;
  long v_152;
  long v_150;
  long v_149;
  long v_148;
  long v_147;
  long v_145;
  long v_143;
  long v_142;
  long v_140;
  long v_138;
  long v_137;
  long v_135;
  long v_134;
  long v_133;
  long r_9;
  long cycles_left;
  long cycles_right;
  long left_was_high;
  long right_was_high;
  long nr_4_St_4_Stop;
  Line_follower__st_4 ns_4_St_4_Stop;
  long parking_cycles_thresh_St_5_Parking_St_4_Stop;
  long pid_error_St_5_Parking_St_4_Stop;
  long dir_St_5_Parking_St_4_Stop;
  long v_r_St_5_Parking_St_4_Stop;
  long v_l_St_5_Parking_St_4_Stop;
  long nr_4_St_4_GoReverse;
  Line_follower__st_4 ns_4_St_4_GoReverse;
  long parking_cycles_thresh_St_5_Parking_St_4_GoReverse;
  long pid_error_St_5_Parking_St_4_GoReverse;
  long dir_St_5_Parking_St_4_GoReverse;
  long v_r_St_5_Parking_St_4_GoReverse;
  long v_l_St_5_Parking_St_4_GoReverse;
  long nr_4_St_4_ParkRight;
  Line_follower__st_4 ns_4_St_4_ParkRight;
  long parking_cycles_thresh_St_5_Parking_St_4_ParkRight;
  long pid_error_St_5_Parking_St_4_ParkRight;
  long dir_St_5_Parking_St_4_ParkRight;
  long v_r_St_5_Parking_St_4_ParkRight;
  long v_l_St_5_Parking_St_4_ParkRight;
  long nr_4_St_4_ParkLeft;
  Line_follower__st_4 ns_4_St_4_ParkLeft;
  long parking_cycles_thresh_St_5_Parking_St_4_ParkLeft;
  long pid_error_St_5_Parking_St_4_ParkLeft;
  long dir_St_5_Parking_St_4_ParkLeft;
  long v_r_St_5_Parking_St_4_ParkLeft;
  long v_l_St_5_Parking_St_4_ParkLeft;
  long nr_4_St_4_GoBackR;
  Line_follower__st_4 ns_4_St_4_GoBackR;
  long parking_cycles_thresh_St_5_Parking_St_4_GoBackR;
  long pid_error_St_5_Parking_St_4_GoBackR;
  long dir_St_5_Parking_St_4_GoBackR;
  long v_r_St_5_Parking_St_4_GoBackR;
  long v_l_St_5_Parking_St_4_GoBackR;
  long nr_4_St_4_GoBackL;
  Line_follower__st_4 ns_4_St_4_GoBackL;
  long parking_cycles_thresh_St_5_Parking_St_4_GoBackL;
  long pid_error_St_5_Parking_St_4_GoBackL;
  long dir_St_5_Parking_St_4_GoBackL;
  long v_r_St_5_Parking_St_4_GoBackL;
  long v_l_St_5_Parking_St_4_GoBackL;
  long nr_4_St_4_FindSpace;
  Line_follower__st_4 ns_4_St_4_FindSpace;
  long parking_cycles_thresh_St_5_Parking_St_4_FindSpace;
  long pid_error_St_5_Parking_St_4_FindSpace;
  long dir_St_5_Parking_St_4_FindSpace;
  long v_r_St_5_Parking_St_4_FindSpace;
  long v_l_St_5_Parking_St_4_FindSpace;
  long nr_4_St_4_Train;
  Line_follower__st_4 ns_4_St_4_Train;
  long parking_cycles_thresh_St_5_Parking_St_4_Train;
  long pid_error_St_5_Parking_St_4_Train;
  long dir_St_5_Parking_St_4_Train;
  long v_r_St_5_Parking_St_4_Train;
  long v_l_St_5_Parking_St_4_Train;
  Line_follower__st_4 ck_9;
  Line_follower__st_4 ns_4;
  long r_4;
  long nr_4;
  long pnr_4;
  long v_200;
  Line_follower__st_3 v_199;
  long v_198;
  long v_197;
  long v_196;
  long v_195;
  long v_194;
  long v_193;
  long v_192;
  long v_191;
  long v_190;
  long v_189;
  long v_188;
  long v_187;
  long v_186;
  long v_207;
  Line_follower__st_3 v_206;
  long v_205;
  Line_follower__st_3 v_204;
  long v_203;
  long v_202;
  long v_201;
  long v_215;
  Line_follower__st_3 v_214;
  long v_213;
  Line_follower__st_3 v_212;
  long v_211;
  long v_210;
  long v_209;
  long v_208;
  long r_3_St_3_ExitEnd2;
  Line_follower__st_3 s_3_St_3_ExitEnd2;
  long r_3_St_3_ExitEnd1;
  Line_follower__st_3 s_3_St_3_ExitEnd1;
  long r_3_St_3_ExitStart;
  Line_follower__st_3 s_3_St_3_ExitStart;
  long r_3_St_3_SlightLeft;
  Line_follower__st_3 s_3_St_3_SlightLeft;
  long r_3_St_3_SlightRight;
  Line_follower__st_3 s_3_St_3_SlightRight;
  long r_3_St_3_SlightStraight;
  Line_follower__st_3 s_3_St_3_SlightStraight;
  long r_3_St_3_FullRight;
  Line_follower__st_3 s_3_St_3_FullRight;
  long r_3_St_3_Wait;
  Line_follower__st_3 s_3_St_3_Wait;
  Line_follower__st_3 ck_5;
  long v_233;
  long v_232;
  long v_231;
  long v_230;
  long v_229;
  long v_228;
  long v_226;
  long v_225;
  long v_223;
  long v_222;
  long v_221;
  long v_219;
  long v_218;
  long sen_1_low1;
  long sen_1_high1;
  long v_235;
  long v_234;
  long v_237;
  long v_236;
  long v_238;
  long r_2_St_2_St_high_1;
  Line_follower__st_2 s_2_St_2_St_high_1;
  long r_2_St_2_St_low_1;
  Line_follower__st_2 s_2_St_2_St_low_1;
  long r_2_St_2_St_high_0;
  Line_follower__st_2 s_2_St_2_St_high_0;
  Line_follower__st_2 ck_7;
  long v_240;
  long nr_2_St_2_St_high_1;
  Line_follower__st_2 ns_2_St_2_St_high_1;
  long complete_1_St_3_ExitEnd1_St_2_St_high_1;
  long nr_2_St_2_St_low_1;
  Line_follower__st_2 ns_2_St_2_St_low_1;
  long complete_1_St_3_ExitEnd1_St_2_St_low_1;
  long nr_2_St_2_St_high_0;
  Line_follower__st_2 ns_2_St_2_St_high_0;
  long complete_1_St_3_ExitEnd1_St_2_St_high_0;
  Line_follower__st_2 ck_8;
  long v_241;
  Line_follower__st_2 s_2;
  Line_follower__st_2 ns_2;
  long r_2;
  long nr_2;
  long pnr_2;
  long v_247;
  long v_245;
  long v_244;
  long ncycles_1;
  long v_254;
  long v_253;
  long v_251;
  long v_250;
  long v_248;
  long ncycles;
  long nr_3_St_3_ExitEnd2;
  Line_follower__st_3 ns_3_St_3_ExitEnd2;
  long complete_1_St_3_ExitEnd2;
  long inx_counter_St_5_ObstacleAvoid_St_3_ExitEnd2;
  long dir_St_5_ObstacleAvoid_St_3_ExitEnd2;
  long v_r_St_5_ObstacleAvoid_St_3_ExitEnd2;
  long v_l_St_5_ObstacleAvoid_St_3_ExitEnd2;
  long nr_3_St_3_ExitEnd1;
  Line_follower__st_3 ns_3_St_3_ExitEnd1;
  long complete_1_St_3_ExitEnd1;
  long inx_counter_St_5_ObstacleAvoid_St_3_ExitEnd1;
  long dir_St_5_ObstacleAvoid_St_3_ExitEnd1;
  long v_r_St_5_ObstacleAvoid_St_3_ExitEnd1;
  long v_l_St_5_ObstacleAvoid_St_3_ExitEnd1;
  long nr_3_St_3_ExitStart;
  Line_follower__st_3 ns_3_St_3_ExitStart;
  long complete_1_St_3_ExitStart;
  long inx_counter_St_5_ObstacleAvoid_St_3_ExitStart;
  long dir_St_5_ObstacleAvoid_St_3_ExitStart;
  long v_r_St_5_ObstacleAvoid_St_3_ExitStart;
  long v_l_St_5_ObstacleAvoid_St_3_ExitStart;
  long nr_3_St_3_SlightLeft;
  Line_follower__st_3 ns_3_St_3_SlightLeft;
  long complete_1_St_3_SlightLeft;
  long inx_counter_St_5_ObstacleAvoid_St_3_SlightLeft;
  long dir_St_5_ObstacleAvoid_St_3_SlightLeft;
  long v_r_St_5_ObstacleAvoid_St_3_SlightLeft;
  long v_l_St_5_ObstacleAvoid_St_3_SlightLeft;
  long nr_3_St_3_SlightRight;
  Line_follower__st_3 ns_3_St_3_SlightRight;
  long complete_1_St_3_SlightRight;
  long inx_counter_St_5_ObstacleAvoid_St_3_SlightRight;
  long dir_St_5_ObstacleAvoid_St_3_SlightRight;
  long v_r_St_5_ObstacleAvoid_St_3_SlightRight;
  long v_l_St_5_ObstacleAvoid_St_3_SlightRight;
  long nr_3_St_3_SlightStraight;
  Line_follower__st_3 ns_3_St_3_SlightStraight;
  long complete_1_St_3_SlightStraight;
  long inx_counter_St_5_ObstacleAvoid_St_3_SlightStraight;
  long dir_St_5_ObstacleAvoid_St_3_SlightStraight;
  long v_r_St_5_ObstacleAvoid_St_3_SlightStraight;
  long v_l_St_5_ObstacleAvoid_St_3_SlightStraight;
  long nr_3_St_3_FullRight;
  Line_follower__st_3 ns_3_St_3_FullRight;
  long complete_1_St_3_FullRight;
  long inx_counter_St_5_ObstacleAvoid_St_3_FullRight;
  long dir_St_5_ObstacleAvoid_St_3_FullRight;
  long v_r_St_5_ObstacleAvoid_St_3_FullRight;
  long v_l_St_5_ObstacleAvoid_St_3_FullRight;
  long nr_3_St_3_Wait;
  Line_follower__st_3 ns_3_St_3_Wait;
  long complete_1_St_3_Wait;
  long inx_counter_St_5_ObstacleAvoid_St_3_Wait;
  long dir_St_5_ObstacleAvoid_St_3_Wait;
  long v_r_St_5_ObstacleAvoid_St_3_Wait;
  long v_l_St_5_ObstacleAvoid_St_3_Wait;
  Line_follower__st_3 ck_6;
  long v_185;
  long v_184;
  long v_183;
  long v_182;
  long v_181;
  long v_180;
  long v_179;
  long v_178;
  long v_177;
  long v_176;
  long v_175;
  long v_174;
  long v_173;
  Line_follower__st_3 s_3;
  Line_follower__st_3 ns_3;
  long r_3;
  long nr_3;
  long pnr_3;
  long complete_1;
  long all_very_high;
  long v_263;
  long v_348;
  long v_347;
  long v_346;
  long v_345;
  long v_344;
  long v_343;
  long v_342;
  long v_341;
  long v_340;
  long v_339;
  long v_338;
  long v_337;
  long v_336;
  long v_335;
  long v_334;
  long v_333;
  long v_332;
  long v_331;
  long v_330;
  long v_329;
  long v_328;
  long v_327;
  long v_326;
  long v_325;
  long v_324;
  long v_323;
  long v_322;
  long v_321;
  long v_320;
  long v_319;
  long v_318;
  long v_317;
  long v_316;
  long v_315;
  long v_314;
  long v_313;
  long v_312;
  long v_311;
  long v_310;
  long v_309;
  long v_308;
  long v_307;
  long v_306;
  long v_305;
  long v_304;
  long v_303;
  long v_302;
  long v_301;
  long v_300;
  long v_299;
  long v_298;
  long v_297;
  long v_296;
  long v_295;
  long v_294;
  long v_293;
  long v_292;
  long v_291;
  long v_290;
  long v_289;
  long v_288;
  long v_287;
  long v_286;
  long v_285;
  long v_284;
  long v_283;
  long v_282;
  long v_281;
  long v_280;
  long v_279;
  long v_278;
  long v_277;
  long v_276;
  long v_275;
  Line_follower__st_1 v_274;
  long v_273;
  Line_follower__st_1 v_272;
  long v_271;
  long v_270;
  long v_269;
  long v_268;
  long v_267;
  long v_266;
  long v_265;
  long v_264;
  long only_one_low;
  long v_350;
  long v_349;
  long nr_1_St_1_ExitStraight;
  Line_follower__st_1 ns_1_St_1_ExitStraight;
  long complete_St_1_ExitStraight;
  long inx_counter_St_5_Intersection_St_1_ExitStraight;
  long dir_St_5_Intersection_St_1_ExitStraight;
  long v_r_St_5_Intersection_St_1_ExitStraight;
  long v_l_St_5_Intersection_St_1_ExitStraight;
  long nr_1_St_1_ExitLeft;
  Line_follower__st_1 ns_1_St_1_ExitLeft;
  long complete_St_1_ExitLeft;
  long inx_counter_St_5_Intersection_St_1_ExitLeft;
  long dir_St_5_Intersection_St_1_ExitLeft;
  long v_r_St_5_Intersection_St_1_ExitLeft;
  long v_l_St_5_Intersection_St_1_ExitLeft;
  long nr_1_St_1_ExitRight;
  Line_follower__st_1 ns_1_St_1_ExitRight;
  long complete_St_1_ExitRight;
  long inx_counter_St_5_Intersection_St_1_ExitRight;
  long dir_St_5_Intersection_St_1_ExitRight;
  long v_r_St_5_Intersection_St_1_ExitRight;
  long v_l_St_5_Intersection_St_1_ExitRight;
  long nr_1_St_1_Entry;
  Line_follower__st_1 ns_1_St_1_Entry;
  long complete_St_1_Entry;
  long inx_counter_St_5_Intersection_St_1_Entry;
  long dir_St_5_Intersection_St_1_Entry;
  long v_r_St_5_Intersection_St_1_Entry;
  long v_l_St_5_Intersection_St_1_Entry;
  long nr_1_St_1_Counter;
  Line_follower__st_1 ns_1_St_1_Counter;
  long complete_St_1_Counter;
  long inx_counter_St_5_Intersection_St_1_Counter;
  long dir_St_5_Intersection_St_1_Counter;
  long v_r_St_5_Intersection_St_1_Counter;
  long v_l_St_5_Intersection_St_1_Counter;
  Line_follower__st_1 ck_4;
  long v_262;
  Line_follower__st_5 v_261;
  long v_260;
  long v_259;
  long v_258;
  long v_257;
  long v_256;
  Line_follower__st_1 ns_1;
  long r_1;
  long nr_1;
  long pnr_1;
  long complete;
  long v_399;
  long v_398;
  long v_397;
  long v_396;
  long v_395;
  long v_394;
  long v_393;
  long v_392;
  long v_391;
  long v_390;
  long v_389;
  long v_388;
  long v_387;
  long v_386;
  long v_385;
  long v_384;
  long v_383;
  long v_382;
  long v_381;
  long v_380;
  long v_379;
  long v_378;
  long v_377;
  long v_376;
  long v_375;
  long v_374;
  long v_373;
  long v_372;
  long v_371;
  long v_370;
  long v_369;
  long v_368;
  long v_367;
  long v_366;
  long v_365;
  long v_364;
  long v_363;
  long v_362;
  long v_361;
  long v_360;
  long v_359;
  long v_358;
  long v_357;
  long v_356;
  long v_355;
  long v_354;
  long v_353;
  long r_10;
  long inx_condition;
  long sharp_thresh_1;
  long v_413;
  long v_412;
  long v_411;
  long v_410;
  long v_409;
  long v_408;
  long v_407;
  long v_406;
  long v_405;
  long v_404;
  long v_403;
  long v_402;
  long v_401;
  long v_400;
  long r_St_Sharp;
  Line_follower__st s_St_Sharp;
  long r_St_PID;
  Line_follower__st s_St_PID;
  Line_follower__st ck_2;
  long v_431;
  long v_430;
  long v_429;
  long v_428;
  long v_427;
  long v_426;
  long v_425;
  long v_424;
  long v_423;
  long v_422;
  long v_421;
  long v_420;
  long v_419;
  long v_418;
  long v_417;
  long v_416;
  long v_415;
  long v_446;
  long v_445;
  long v_444;
  long v_443;
  long v_442;
  long v_441;
  long v_440;
  long v_439;
  long v_438;
  long v_437;
  long v_436;
  long v_435;
  long v_434;
  long v_433;
  long v_432;
  long r_11;
  long nr_St_Sharp;
  Line_follower__st ns_St_Sharp;
  long last_error_St_5_WonB_St_Sharp;
  long pid_error_St_5_WonB_St_Sharp;
  long dir_St_5_WonB_St_Sharp;
  long v_r_St_5_WonB_St_Sharp;
  long v_l_St_5_WonB_St_Sharp;
  long nr_St_PID;
  Line_follower__st ns_St_PID;
  long last_error_St_5_WonB_St_PID;
  long pid_error_St_5_WonB_St_PID;
  long dir_St_5_WonB_St_PID;
  long v_r_St_5_WonB_St_PID;
  long v_l_St_5_WonB_St_PID;
  Line_follower__st ck_3;
  Line_follower__st s;
  Line_follower__st ns;
  long r;
  long nr;
  long pnr;
  long sharp_thresh;
  long v_448;
  long nr_5_St_5_Parking;
  Line_follower__st_5 ns_5_St_5_Parking;
  long parking_cycles_thresh_St_5_Parking;
  long inx_counter_St_5_Parking;
  long thresh_vals_St_5_Parking[5];
  long min_vals_St_5_Parking[5];
  long max_vals_St_5_Parking[5];
  long last_error_St_5_Parking;
  long pid_error_St_5_Parking;
  long dir_St_5_Parking;
  long v_r_St_5_Parking;
  long v_l_St_5_Parking;
  long nr_5_St_5_ObstacleAvoid;
  Line_follower__st_5 ns_5_St_5_ObstacleAvoid;
  long parking_cycles_thresh_St_5_ObstacleAvoid;
  long inx_counter_St_5_ObstacleAvoid;
  long thresh_vals_St_5_ObstacleAvoid[5];
  long min_vals_St_5_ObstacleAvoid[5];
  long max_vals_St_5_ObstacleAvoid[5];
  long last_error_St_5_ObstacleAvoid;
  long pid_error_St_5_ObstacleAvoid;
  long dir_St_5_ObstacleAvoid;
  long v_r_St_5_ObstacleAvoid;
  long v_l_St_5_ObstacleAvoid;
  long nr_5_St_5_Intersection;
  Line_follower__st_5 ns_5_St_5_Intersection;
  long parking_cycles_thresh_St_5_Intersection;
  long inx_counter_St_5_Intersection;
  long thresh_vals_St_5_Intersection[5];
  long min_vals_St_5_Intersection[5];
  long max_vals_St_5_Intersection[5];
  long last_error_St_5_Intersection;
  long pid_error_St_5_Intersection;
  long dir_St_5_Intersection;
  long v_r_St_5_Intersection;
  long v_l_St_5_Intersection;
  long nr_5_St_5_BonW;
  Line_follower__st_5 ns_5_St_5_BonW;
  long parking_cycles_thresh_St_5_BonW;
  long inx_counter_St_5_BonW;
  long thresh_vals_St_5_BonW[5];
  long min_vals_St_5_BonW[5];
  long max_vals_St_5_BonW[5];
  long last_error_St_5_BonW;
  long pid_error_St_5_BonW;
  long dir_St_5_BonW;
  long v_r_St_5_BonW;
  long v_l_St_5_BonW;
  long nr_5_St_5_WonB;
  Line_follower__st_5 ns_5_St_5_WonB;
  long parking_cycles_thresh_St_5_WonB;
  long inx_counter_St_5_WonB;
  long thresh_vals_St_5_WonB[5];
  long min_vals_St_5_WonB[5];
  long max_vals_St_5_WonB[5];
  long last_error_St_5_WonB;
  long pid_error_St_5_WonB;
  long dir_St_5_WonB;
  long v_r_St_5_WonB;
  long v_l_St_5_WonB;
  long nr_5_St_5_Start;
  Line_follower__st_5 ns_5_St_5_Start;
  long parking_cycles_thresh_St_5_Start;
  long inx_counter_St_5_Start;
  long thresh_vals_St_5_Start[5];
  long min_vals_St_5_Start[5];
  long max_vals_St_5_Start[5];
  long last_error_St_5_Start;
  long pid_error_St_5_Start;
  long dir_St_5_Start;
  long v_r_St_5_Start;
  long v_l_St_5_Start;
  long nr_5_St_5_Idle;
  Line_follower__st_5 ns_5_St_5_Idle;
  long parking_cycles_thresh_St_5_Idle;
  long inx_counter_St_5_Idle;
  long thresh_vals_St_5_Idle[5];
  long min_vals_St_5_Idle[5];
  long max_vals_St_5_Idle[5];
  long last_error_St_5_Idle;
  long pid_error_St_5_Idle;
  long dir_St_5_Idle;
  long v_r_St_5_Idle;
  long v_l_St_5_Idle;
  long nr_5_St_5_Calibrate;
  Line_follower__st_5 ns_5_St_5_Calibrate;
  long parking_cycles_thresh_St_5_Calibrate;
  long inx_counter_St_5_Calibrate;
  long thresh_vals_St_5_Calibrate[5];
  long min_vals_St_5_Calibrate[5];
  long max_vals_St_5_Calibrate[5];
  long last_error_St_5_Calibrate;
  long pid_error_St_5_Calibrate;
  long dir_St_5_Calibrate;
  long v_r_St_5_Calibrate;
  long v_l_St_5_Calibrate;
  Line_follower__st_5 ck_1;
  long v_54;
  long v_53;
  long v_52;
  long v_51;
  long v_50;
  long v_49;
  long v_48;
  long v_47;
  long v_46;
  long v_45;
  long v_44;
  long v_43;
  long v;
  Line_follower__st_5 s_5;
  Line_follower__st_5 ns_5;
  long r_5;
  long nr_5;
  long raw_sen[5];
  long sensor_avg;
  long all_high;
  long pid_error;
  long last_error;
  long max_vals[5];
  long min_vals[5];
  long thresh_vals[5];
  long sen[5];
  long inx_counter;
  long parking_cycles_thresh;
  switch (self->ck) {
    case Line_follower__St_5_Calibrate:
      r_5_St_5_Calibrate = self->pnr_5;
      s_5_St_5_Calibrate = Line_follower__St_5_Calibrate;
      break;
    case Line_follower__St_5_Start:
      r_5_St_5_Start = self->pnr_5;
      s_5_St_5_Start = Line_follower__St_5_Start;
      break;
    case Line_follower__St_5_BonW:
      v_57 = (ir_value==0);
      v_58 = !(v_57);
      if (v_58) {
        r_5_St_5_BonW = true;
        s_5_St_5_BonW = Line_follower__St_5_ObstacleAvoid;
      } else {
        r_5_St_5_BonW = self->pnr_5;
        s_5_St_5_BonW = Line_follower__St_5_BonW;
      };
      break;
    case Line_follower__St_5_Intersection:
      v_55 = (ir_value==0);
      v_56 = !(v_55);
      if (v_56) {
        r_5_St_5_Intersection = true;
        s_5_St_5_Intersection = Line_follower__St_5_ObstacleAvoid;
      } else {
        r_5_St_5_Intersection = self->pnr_5;
        s_5_St_5_Intersection = Line_follower__St_5_Intersection;
      };
      break;
    case Line_follower__St_5_ObstacleAvoid:
      r_5_St_5_ObstacleAvoid = self->pnr_5;
      s_5_St_5_ObstacleAvoid = Line_follower__St_5_ObstacleAvoid;
      break;
    case Line_follower__St_5_Parking:
      r_5_St_5_Parking = self->pnr_5;
      s_5_St_5_Parking = Line_follower__St_5_Parking;
      break;
    default:
      break;
  };
  raw_sen[0] = sen0;
  raw_sen[1] = sen1;
  raw_sen[2] = sen2;
  raw_sen[3] = sen3;
  raw_sen[4] = sen4;
  {
    long i_8;
    for (i_8 = 0; i_8 < 5; ++i_8) {
      Line_follower__normalize_value_step(self->min_vals_1[i_8],
                                          self->max_vals_1[i_8],
                                          raw_sen[i_8],
                                          &Line_follower__normalize_value_out_st);
      sen[i_8] = Line_follower__normalize_value_out_st.norm_val;
    }
  };
  v_53 = sen[4];
  v_54 = (v_53>=Line_follower__high_thresh);
  v_50 = sen[3];
  v_51 = (v_50>=Line_follower__high_thresh);
  v_47 = sen[2];
  v_48 = (v_47>=Line_follower__high_thresh);
  v_44 = sen[1];
  v_45 = (v_44>=Line_follower__high_thresh);
  v = sen[0];
  v_43 = (v>=Line_follower__high_thresh);
  v_46 = (v_43&&v_45);
  v_49 = (v_46&&v_48);
  v_52 = (v_49&&v_51);
  all_high = (v_52&&v_54);
  Line_follower__senWeightedAvg_step(sen,
                                     &Line_follower__senWeightedAvg_out_st);
  sensor_avg = Line_follower__senWeightedAvg_out_st.sensor_avg;
  switch (self->ck) {
    case Line_follower__St_5_Idle:
      if (all_high) {
        r_5_St_5_Idle = true;
        s_5_St_5_Idle = Line_follower__St_5_Start;
      } else {
        r_5_St_5_Idle = self->pnr_5;
        s_5_St_5_Idle = Line_follower__St_5_Idle;
      };
      s_5 = s_5_St_5_Idle;
      r_5 = r_5_St_5_Idle;
      break;
    case Line_follower__St_5_WonB:
      v_70 = sen[4];
      v_71 = (v_70>=Line_follower__high_thresh);
      v_66 = sen[3];
      v_67 = (v_66<=Line_follower__low_thresh);
      v_63 = sen[2];
      v_64 = (v_63<=Line_follower__low_thresh);
      v_61 = sen[1];
      v_62 = (v_61<=Line_follower__low_thresh);
      v_65 = (v_62||v_64);
      v_68 = (v_65||v_67);
      v_59 = sen[0];
      v_60 = (v_59>=Line_follower__high_thresh);
      v_69 = (v_60&&v_68);
      v_72 = (v_69&&v_71);
      if (v_72) {
        r_5_St_5_WonB = true;
        s_5_St_5_WonB = Line_follower__St_5_BonW;
      } else {
        r_5_St_5_WonB = self->pnr_5;
        s_5_St_5_WonB = Line_follower__St_5_WonB;
      };
      s_5 = s_5_St_5_WonB;
      r_5 = r_5_St_5_WonB;
      break;
    case Line_follower__St_5_Parking:
      s_5 = s_5_St_5_Parking;
      r_5 = r_5_St_5_Parking;
      break;
    case Line_follower__St_5_ObstacleAvoid:
      s_5 = s_5_St_5_ObstacleAvoid;
      r_5 = r_5_St_5_ObstacleAvoid;
      break;
    case Line_follower__St_5_Intersection:
      s_5 = s_5_St_5_Intersection;
      r_5 = r_5_St_5_Intersection;
      break;
    case Line_follower__St_5_BonW:
      s_5 = s_5_St_5_BonW;
      r_5 = r_5_St_5_BonW;
      break;
    case Line_follower__St_5_Start:
      s_5 = s_5_St_5_Start;
      r_5 = r_5_St_5_Start;
      break;
    case Line_follower__St_5_Calibrate:
      s_5 = s_5_St_5_Calibrate;
      r_5 = r_5_St_5_Calibrate;
      break;
    default:
      break;
  };
  ck_1 = s_5;
  switch (ck_1) {
    case Line_follower__St_5_Calibrate:
      parking_cycles_thresh_St_5_Calibrate = self->parking_cycles_thresh_1;
      inx_counter_St_5_Calibrate = self->inx_counter_1;
      last_error_St_5_Calibrate = self->last_error_1;
      pid_error_St_5_Calibrate = self->pid_error_11;
      dir_St_5_Calibrate = 2;
      v_r_St_5_Calibrate = 40;
      v_l_St_5_Calibrate = 40;
      nr_5_St_5_Calibrate = false;
      ns_5_St_5_Calibrate = Line_follower__St_5_Calibrate;
      inx_counter = inx_counter_St_5_Calibrate;
      ns_5 = ns_5_St_5_Calibrate;
      nr_5 = nr_5_St_5_Calibrate;
      pid_error = pid_error_St_5_Calibrate;
      parking_cycles_thresh = parking_cycles_thresh_St_5_Calibrate;
      _out->v_l = v_l_St_5_Calibrate;
      _out->v_r = v_r_St_5_Calibrate;
      last_error = last_error_St_5_Calibrate;
      _out->dir = dir_St_5_Calibrate;
      {
        long _6;
        for (_6 = 0; _6 < 5; ++_6) {
          thresh_vals_St_5_Calibrate[_6] = self->thresh_vals_1[_6];
        }
      };
      {
        long _7;
        for (_7 = 0; _7 < 5; ++_7) {
          thresh_vals[_7] = thresh_vals_St_5_Calibrate[_7];
        }
      };
      {
        long i_7;
        for (i_7 = 0; i_7 < 5; ++i_7) {
          Line_follower__updateMaxs_step(raw_sen[i_7], thresh_vals[i_7],
                                         self->max_vals_1[i_7],
                                         &Line_follower__updateMaxs_out_st);
          max_vals_St_5_Calibrate[i_7] = Line_follower__updateMaxs_out_st.new_max;
        }
      };
      {
        long i_6;
        for (i_6 = 0; i_6 < 5; ++i_6) {
          Line_follower__updateMins_step(raw_sen[i_6], thresh_vals[i_6],
                                         self->min_vals_1[i_6],
                                         &Line_follower__updateMins_out_st);
          min_vals_St_5_Calibrate[i_6] = Line_follower__updateMins_out_st.new_min;
        }
      };
      {
        long _8;
        for (_8 = 0; _8 < 5; ++_8) {
          min_vals[_8] = min_vals_St_5_Calibrate[_8];
        }
      };
      {
        long _9;
        for (_9 = 0; _9 < 5; ++_9) {
          max_vals[_9] = max_vals_St_5_Calibrate[_9];
        }
      };
      break;
    case Line_follower__St_5_Idle:
      parking_cycles_thresh_St_5_Idle = self->parking_cycles_thresh_1;
      inx_counter_St_5_Idle = self->inx_counter_1;
      last_error_St_5_Idle = self->last_error_1;
      pid_error_St_5_Idle = self->pid_error_11;
      dir_St_5_Idle = 9;
      v_r_St_5_Idle = 0;
      v_l_St_5_Idle = 0;
      nr_5_St_5_Idle = false;
      ns_5_St_5_Idle = Line_follower__St_5_Idle;
      inx_counter = inx_counter_St_5_Idle;
      ns_5 = ns_5_St_5_Idle;
      nr_5 = nr_5_St_5_Idle;
      pid_error = pid_error_St_5_Idle;
      parking_cycles_thresh = parking_cycles_thresh_St_5_Idle;
      _out->v_l = v_l_St_5_Idle;
      _out->v_r = v_r_St_5_Idle;
      last_error = last_error_St_5_Idle;
      _out->dir = dir_St_5_Idle;
      {
        long _10;
        for (_10 = 0; _10 < 5; ++_10) {
          thresh_vals_St_5_Idle[_10] = self->thresh_vals_1[_10];
        }
      };
      {
        long _11;
        for (_11 = 0; _11 < 5; ++_11) {
          min_vals_St_5_Idle[_11] = self->min_vals_1[_11];
        }
      };
      {
        long _12;
        for (_12 = 0; _12 < 5; ++_12) {
          max_vals_St_5_Idle[_12] = self->max_vals_1[_12];
        }
      };
      {
        long _13;
        for (_13 = 0; _13 < 5; ++_13) {
          thresh_vals[_13] = thresh_vals_St_5_Idle[_13];
        }
      };
      {
        long _14;
        for (_14 = 0; _14 < 5; ++_14) {
          min_vals[_14] = min_vals_St_5_Idle[_14];
        }
      };
      {
        long _15;
        for (_15 = 0; _15 < 5; ++_15) {
          max_vals[_15] = max_vals_St_5_Idle[_15];
        }
      };
      break;
    case Line_follower__St_5_Start:
      parking_cycles_thresh_St_5_Start = self->parking_cycles_thresh_1;
      inx_counter_St_5_Start = self->inx_counter_1;
      last_error_St_5_Start = self->last_error_1;
      pid_error_St_5_Start = self->pid_error_11;
      dir_St_5_Start = 1;
      v_r_St_5_Start = 40;
      v_l_St_5_Start = 40;
      v_448 = !(all_high);
      if (v_448) {
        nr_5_St_5_Start = true;
        ns_5_St_5_Start = Line_follower__St_5_WonB;
      } else {
        nr_5_St_5_Start = false;
        ns_5_St_5_Start = Line_follower__St_5_Start;
      };
      inx_counter = inx_counter_St_5_Start;
      ns_5 = ns_5_St_5_Start;
      nr_5 = nr_5_St_5_Start;
      pid_error = pid_error_St_5_Start;
      parking_cycles_thresh = parking_cycles_thresh_St_5_Start;
      _out->v_l = v_l_St_5_Start;
      _out->v_r = v_r_St_5_Start;
      last_error = last_error_St_5_Start;
      _out->dir = dir_St_5_Start;
      {
        long _16;
        for (_16 = 0; _16 < 5; ++_16) {
          thresh_vals_St_5_Start[_16] = self->thresh_vals_1[_16];
        }
      };
      {
        long _17;
        for (_17 = 0; _17 < 5; ++_17) {
          min_vals_St_5_Start[_17] = self->min_vals_1[_17];
        }
      };
      {
        long _18;
        for (_18 = 0; _18 < 5; ++_18) {
          max_vals_St_5_Start[_18] = self->max_vals_1[_18];
        }
      };
      {
        long _19;
        for (_19 = 0; _19 < 5; ++_19) {
          thresh_vals[_19] = thresh_vals_St_5_Start[_19];
        }
      };
      {
        long _20;
        for (_20 = 0; _20 < 5; ++_20) {
          min_vals[_20] = min_vals_St_5_Start[_20];
        }
      };
      {
        long _21;
        for (_21 = 0; _21 < 5; ++_21) {
          max_vals[_21] = max_vals_St_5_Start[_21];
        }
      };
      break;
    case Line_follower__St_5_WonB:
      parking_cycles_thresh_St_5_WonB = self->parking_cycles_thresh_1;
      inx_counter_St_5_WonB = self->inx_counter_1;
      if (r_5) {
        pnr = false;
        ck_2 = Line_follower__St_PID;
      } else {
        pnr = self->v_447;
        ck_2 = self->v_414;
      };
      sharp_thresh = 15;
      nr_5_St_5_WonB = false;
      ns_5_St_5_WonB = Line_follower__St_5_WonB;
      switch (ck_2) {
        case Line_follower__St_PID:
          v_411 = sen[4];
          v_412 = (v_411<=Line_follower__low_thresh);
          v_408 = sen[3];
          v_409 = (v_408<=Line_follower__low_thresh);
          v_405 = sen[2];
          v_406 = (v_405<=Line_follower__low_thresh);
          v_402 = sen[1];
          v_403 = (v_402<=Line_follower__low_thresh);
          v_400 = sen[0];
          v_401 = (v_400<=Line_follower__low_thresh);
          v_404 = (v_401&&v_403);
          v_407 = (v_404&&v_406);
          v_410 = (v_407&&v_409);
          v_413 = (v_410&&v_412);
          if (v_413) {
            r_St_PID = true;
            s_St_PID = Line_follower__St_Sharp;
          } else {
            r_St_PID = pnr;
            s_St_PID = Line_follower__St_PID;
          };
          s = s_St_PID;
          r = r_St_PID;
          break;
        case Line_follower__St_Sharp:
          r_St_Sharp = pnr;
          s_St_Sharp = Line_follower__St_Sharp;
          s = s_St_Sharp;
          r = r_St_Sharp;
          break;
        default:
          break;
      };
      ck_3 = s;
      switch (ck_3) {
        case Line_follower__St_PID:
          dir_St_5_WonB_St_PID = 1;
          v_444 = (-1*sharp_thresh);
          v_445 = (v_444/2);
          Line_follower__safe_motor_update_step(Line_follower__base_speed,
                                                v_445,
                                                &Line_follower__safe_motor_update_out_st);
          v_446 = Line_follower__safe_motor_update_out_st.new_speed;
          v_438 = (sharp_thresh/2);
          Line_follower__safe_motor_update_step(Line_follower__base_speed,
                                                v_438,
                                                &Line_follower__safe_motor_update_out_st);
          v_439 = Line_follower__safe_motor_update_out_st.new_speed;
          nr_St_PID = false;
          ns_St_PID = Line_follower__St_PID;
          r_11 = (r_5||r);
          if (r_11) {
            Line_follower__calPidError_reset(&self->calPidError_5);
          };
          Line_follower__calPidError_step(sensor_avg,
                                          Line_follower__kscale_white,
                                          &Line_follower__calPidError_out_st,
                                          &self->calPidError_5);
          pid_error_St_5_WonB_St_PID = Line_follower__calPidError_out_st.pid_error;
          pid_error_St_5_WonB = pid_error_St_5_WonB_St_PID;
          ns = ns_St_PID;
          nr = nr_St_PID;
          break;
        case Line_follower__St_Sharp:
          last_error_St_5_WonB_St_Sharp = self->last_error_1;
          pid_error_St_5_WonB_St_Sharp = self->pid_error_11;
          v_r_St_5_WonB_St_Sharp = 40;
          v_l_St_5_WonB_St_Sharp = 40;
          v_426 = sen[4];
          v_427 = (v_426<=Line_follower__low_thresh);
          v_423 = sen[3];
          v_424 = (v_423<=Line_follower__low_thresh);
          v_420 = sen[2];
          v_421 = (v_420>=Line_follower__high_thresh);
          v_417 = sen[1];
          v_418 = (v_417<=Line_follower__low_thresh);
          v_415 = sen[0];
          v_416 = (v_415<=Line_follower__low_thresh);
          v_419 = (v_416&&v_418);
          v_422 = (v_419&&v_421);
          v_425 = (v_422&&v_424);
          v_428 = (v_425&&v_427);
          if (v_428) {
            nr_St_Sharp = true;
            ns_St_Sharp = Line_follower__St_PID;
          } else {
            nr_St_Sharp = false;
            ns_St_Sharp = Line_follower__St_Sharp;
          };
          pid_error_St_5_WonB = pid_error_St_5_WonB_St_Sharp;
          ns = ns_St_Sharp;
          nr = nr_St_Sharp;
          break;
        default:
          break;
      };
      inx_counter = inx_counter_St_5_WonB;
      ns_5 = ns_5_St_5_WonB;
      nr_5 = nr_5_St_5_WonB;
      pid_error = pid_error_St_5_WonB;
      parking_cycles_thresh = parking_cycles_thresh_St_5_WonB;
      switch (ck_3) {
        case Line_follower__St_PID:
          v_441 = (-1*pid_error);
          v_442 = (v_441/2);
          Line_follower__safe_motor_update_step(Line_follower__base_speed,
                                                v_442,
                                                &Line_follower__safe_motor_update_out_st);
          v_443 = Line_follower__safe_motor_update_out_st.new_speed;
          v_440 = (pid_error<=sharp_thresh);
          if (v_440) {
            v_r_St_5_WonB_St_PID = v_443;
          } else {
            v_r_St_5_WonB_St_PID = v_446;
          };
          v_436 = (pid_error/2);
          Line_follower__safe_motor_update_step(Line_follower__base_speed,
                                                v_436,
                                                &Line_follower__safe_motor_update_out_st);
          v_437 = Line_follower__safe_motor_update_out_st.new_speed;
          v_435 = (pid_error<=sharp_thresh);
          if (v_435) {
            v_l_St_5_WonB_St_PID = v_437;
          } else {
            v_l_St_5_WonB_St_PID = v_439;
          };
          v_433 = (pid_error>0);
          if (v_433) {
            v_434 = 1;
          } else {
            v_434 = -1;
          };
          v_432 = (pid_error<=sharp_thresh);
          if (v_432) {
            last_error_St_5_WonB_St_PID = self->last_error_1;
          } else {
            last_error_St_5_WonB_St_PID = v_434;
          };
          v_l_St_5_WonB = v_l_St_5_WonB_St_PID;
          v_r_St_5_WonB = v_r_St_5_WonB_St_PID;
          last_error_St_5_WonB = last_error_St_5_WonB_St_PID;
          break;
        case Line_follower__St_Sharp:
          v_l_St_5_WonB = v_l_St_5_WonB_St_Sharp;
          v_r_St_5_WonB = v_r_St_5_WonB_St_Sharp;
          last_error_St_5_WonB = last_error_St_5_WonB_St_Sharp;
          break;
        default:
          break;
      };
      _out->v_l = v_l_St_5_WonB;
      _out->v_r = v_r_St_5_WonB;
      last_error = last_error_St_5_WonB;
      switch (ck_3) {
        case Line_follower__St_Sharp:
          v_430 = (last_error>0);
          if (v_430) {
            v_431 = 3;
          } else {
            v_431 = 2;
          };
          v_429 = (last_error==0);
          if (v_429) {
            dir_St_5_WonB_St_Sharp = 4;
          } else {
            dir_St_5_WonB_St_Sharp = v_431;
          };
          dir_St_5_WonB = dir_St_5_WonB_St_Sharp;
          break;
        case Line_follower__St_PID:
          dir_St_5_WonB = dir_St_5_WonB_St_PID;
          break;
        default:
          break;
      };
      _out->dir = dir_St_5_WonB;
      {
        long _22;
        for (_22 = 0; _22 < 5; ++_22) {
          thresh_vals_St_5_WonB[_22] = self->thresh_vals_1[_22];
        }
      };
      {
        long _23;
        for (_23 = 0; _23 < 5; ++_23) {
          min_vals_St_5_WonB[_23] = self->min_vals_1[_23];
        }
      };
      {
        long _24;
        for (_24 = 0; _24 < 5; ++_24) {
          max_vals_St_5_WonB[_24] = self->max_vals_1[_24];
        }
      };
      {
        long _25;
        for (_25 = 0; _25 < 5; ++_25) {
          thresh_vals[_25] = thresh_vals_St_5_WonB[_25];
        }
      };
      {
        long _26;
        for (_26 = 0; _26 < 5; ++_26) {
          min_vals[_26] = min_vals_St_5_WonB[_26];
        }
      };
      {
        long _27;
        for (_27 = 0; _27 < 5; ++_27) {
          max_vals[_27] = max_vals_St_5_WonB[_27];
        }
      };
      self->v_447 = nr;
      self->v_414 = ns;
      break;
    case Line_follower__St_5_BonW:
      parking_cycles_thresh_St_5_BonW = self->parking_cycles_thresh_1;
      inx_counter_St_5_BonW = self->inx_counter_1;
      v_397 = sen[2];
      v_398 = (v_397<=Line_follower__low_thresh);
      v_394 = sen[3];
      v_395 = (v_394<=Line_follower__low_thresh);
      v_392 = sen[4];
      v_393 = (v_392<=Line_follower__low_thresh);
      v_396 = (v_393&&v_395);
      v_399 = (v_396&&v_398);
      v_388 = sen[2];
      v_389 = (v_388<=Line_follower__low_thresh);
      v_385 = sen[1];
      v_386 = (v_385<=Line_follower__low_thresh);
      v_383 = sen[3];
      v_384 = (v_383<=Line_follower__low_thresh);
      v_387 = (v_384&&v_386);
      v_390 = (v_387&&v_389);
      v_380 = sen[2];
      v_381 = (v_380<=Line_follower__low_thresh);
      v_377 = sen[1];
      v_378 = (v_377<=Line_follower__low_thresh);
      v_375 = sen[0];
      v_376 = (v_375<=Line_follower__low_thresh);
      v_379 = (v_376&&v_378);
      v_382 = (v_379&&v_381);
      v_391 = (v_382||v_390);
      inx_condition = (v_391||v_399);
      sharp_thresh_1 = 30;
      if (inx_condition) {
        nr_5_St_5_BonW = true;
        ns_5_St_5_BonW = Line_follower__St_5_Intersection;
      } else {
        nr_5_St_5_BonW = false;
        ns_5_St_5_BonW = Line_follower__St_5_BonW;
      };
      r_10 = r_5;
      if (r_10) {
        Line_follower__calPidError_reset(&self->calPidError_4);
      };
      Line_follower__calPidError_step(sensor_avg,
                                      Line_follower__kscale_black,
                                      &Line_follower__calPidError_out_st,
                                      &self->calPidError_4);
      pid_error_St_5_BonW = Line_follower__calPidError_out_st.pid_error;
      inx_counter = inx_counter_St_5_BonW;
      ns_5 = ns_5_St_5_BonW;
      nr_5 = nr_5_St_5_BonW;
      pid_error = pid_error_St_5_BonW;
      v_373 = (pid_error>0);
      if (v_373) {
        v_374 = 1;
      } else {
        v_374 = -1;
      };
      v_372 = (pid_error==0);
      if (v_372) {
        last_error_St_5_BonW = self->last_error_1;
      } else {
        last_error_St_5_BonW = v_374;
      };
      v_370 = (pid_error>0);
      if (v_370) {
        v_371 = 3;
      } else {
        v_371 = 2;
      };
      Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
      v_368 = Line_follower__abs_out_st.out;
      v_369 = (v_368<=sharp_thresh_1);
      if (v_369) {
        dir_St_5_BonW = 1;
      } else {
        dir_St_5_BonW = v_371;
      };
      Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
      v_365 = Line_follower__abs_out_st.out;
      v_366 = (v_365+20);
      Line_follower__safe_motor_update_step(0, v_366,
                                            &Line_follower__safe_motor_update_out_st);
      v_367 = Line_follower__safe_motor_update_out_st.new_speed;
      v_362 = (-1*pid_error);
      v_363 = (v_362/2);
      Line_follower__safe_motor_update_step(Line_follower__base_speed, v_363,
                                            &Line_follower__safe_motor_update_out_st);
      v_364 = Line_follower__safe_motor_update_out_st.new_speed;
      Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
      v_360 = Line_follower__abs_out_st.out;
      v_361 = (v_360<=sharp_thresh_1);
      if (v_361) {
        v_r_St_5_BonW = v_364;
      } else {
        v_r_St_5_BonW = v_367;
      };
      Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
      v_357 = Line_follower__abs_out_st.out;
      v_358 = (v_357+20);
      Line_follower__safe_motor_update_step(0, v_358,
                                            &Line_follower__safe_motor_update_out_st);
      v_359 = Line_follower__safe_motor_update_out_st.new_speed;
      v_355 = (pid_error/2);
      Line_follower__safe_motor_update_step(Line_follower__base_speed, v_355,
                                            &Line_follower__safe_motor_update_out_st);
      v_356 = Line_follower__safe_motor_update_out_st.new_speed;
      Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
      v_353 = Line_follower__abs_out_st.out;
      v_354 = (v_353<=sharp_thresh_1);
      if (v_354) {
        v_l_St_5_BonW = v_356;
      } else {
        v_l_St_5_BonW = v_359;
      };
      parking_cycles_thresh = parking_cycles_thresh_St_5_BonW;
      _out->v_l = v_l_St_5_BonW;
      _out->v_r = v_r_St_5_BonW;
      last_error = last_error_St_5_BonW;
      _out->dir = dir_St_5_BonW;
      {
        long _28;
        for (_28 = 0; _28 < 5; ++_28) {
          thresh_vals_St_5_BonW[_28] = self->thresh_vals_1[_28];
        }
      };
      {
        long _29;
        for (_29 = 0; _29 < 5; ++_29) {
          min_vals_St_5_BonW[_29] = self->min_vals_1[_29];
        }
      };
      {
        long _30;
        for (_30 = 0; _30 < 5; ++_30) {
          max_vals_St_5_BonW[_30] = self->max_vals_1[_30];
        }
      };
      {
        long _31;
        for (_31 = 0; _31 < 5; ++_31) {
          thresh_vals[_31] = thresh_vals_St_5_BonW[_31];
        }
      };
      {
        long _32;
        for (_32 = 0; _32 < 5; ++_32) {
          min_vals[_32] = min_vals_St_5_BonW[_32];
        }
      };
      {
        long _33;
        for (_33 = 0; _33 < 5; ++_33) {
          max_vals[_33] = max_vals_St_5_BonW[_33];
        }
      };
      break;
    case Line_follower__St_5_Intersection:
      parking_cycles_thresh_St_5_Intersection = self->parking_cycles_thresh_1;
      last_error_St_5_Intersection = self->last_error_1;
      pid_error_St_5_Intersection = self->pid_error_11;
      if (r_5) {
        pnr_1 = false;
      } else {
        pnr_1 = self->v_352;
      };
      r_1 = pnr_1;
      if (r_5) {
        ck_4 = Line_follower__St_1_Counter;
      } else {
        ck_4 = self->v_351;
      };
      switch (ck_4) {
        case Line_follower__St_1_Counter:
          complete_St_1_Counter = false;
          v_350 = (self->inx_counter_1+1);
          v_349 = (self->inx_counter_1>=2);
          if (v_349) {
            inx_counter_St_5_Intersection_St_1_Counter = v_350;
          } else {
            inx_counter_St_5_Intersection_St_1_Counter = self->inx_counter_1;
          };
          v_r_St_5_Intersection_St_1_Counter = 0;
          v_l_St_5_Intersection_St_1_Counter = 0;
          dir_St_5_Intersection_St_1_Counter = 0;
          if (true) {
            nr_1_St_1_Counter = true;
          } else {
            nr_1_St_1_Counter = false;
          };
          if (true) {
            ns_1_St_1_Counter = Line_follower__St_1_Entry;
          } else {
            ns_1_St_1_Counter = Line_follower__St_1_Counter;
          };
          v_l_St_5_Intersection = v_l_St_5_Intersection_St_1_Counter;
          v_r_St_5_Intersection = v_r_St_5_Intersection_St_1_Counter;
          dir_St_5_Intersection = dir_St_5_Intersection_St_1_Counter;
          inx_counter_St_5_Intersection = inx_counter_St_5_Intersection_St_1_Counter;
          complete = complete_St_1_Counter;
          break;
        case Line_follower__St_1_Entry:
          inx_counter_St_5_Intersection_St_1_Entry = self->inx_counter_1;
          v_346 = sen[3];
          v_347 = (v_346>=Line_follower__high_thresh);
          v_343 = sen[2];
          v_344 = (v_343>=Line_follower__high_thresh);
          v_340 = sen[1];
          v_341 = (v_340>=Line_follower__high_thresh);
          v_337 = sen[0];
          v_338 = (v_337>=Line_follower__high_thresh);
          v_335 = sen[4];
          v_336 = (v_335<=Line_follower__low_thresh);
          v_339 = (v_336&&v_338);
          v_342 = (v_339&&v_341);
          v_345 = (v_342&&v_344);
          v_348 = (v_345&&v_347);
          v_331 = sen[4];
          v_332 = (v_331>=Line_follower__high_thresh);
          v_328 = sen[2];
          v_329 = (v_328>=Line_follower__high_thresh);
          v_325 = sen[1];
          v_326 = (v_325>=Line_follower__high_thresh);
          v_322 = sen[0];
          v_323 = (v_322>=Line_follower__high_thresh);
          v_320 = sen[3];
          v_321 = (v_320<=Line_follower__low_thresh);
          v_324 = (v_321&&v_323);
          v_327 = (v_324&&v_326);
          v_330 = (v_327&&v_329);
          v_333 = (v_330&&v_332);
          v_316 = sen[4];
          v_317 = (v_316>=Line_follower__high_thresh);
          v_313 = sen[3];
          v_314 = (v_313>=Line_follower__high_thresh);
          v_310 = sen[1];
          v_311 = (v_310>=Line_follower__high_thresh);
          v_307 = sen[0];
          v_308 = (v_307>=Line_follower__high_thresh);
          v_305 = sen[2];
          v_306 = (v_305<=Line_follower__low_thresh);
          v_309 = (v_306&&v_308);
          v_312 = (v_309&&v_311);
          v_315 = (v_312&&v_314);
          v_318 = (v_315&&v_317);
          v_301 = sen[4];
          v_302 = (v_301>=Line_follower__high_thresh);
          v_298 = sen[3];
          v_299 = (v_298>=Line_follower__high_thresh);
          v_295 = sen[2];
          v_296 = (v_295>=Line_follower__high_thresh);
          v_292 = sen[0];
          v_293 = (v_292>=Line_follower__high_thresh);
          v_290 = sen[1];
          v_291 = (v_290<=Line_follower__low_thresh);
          v_294 = (v_291&&v_293);
          v_297 = (v_294&&v_296);
          v_300 = (v_297&&v_299);
          v_303 = (v_300&&v_302);
          v_287 = sen[4];
          v_288 = (v_287>=Line_follower__high_thresh);
          v_284 = sen[3];
          v_285 = (v_284>=Line_follower__high_thresh);
          v_281 = sen[2];
          v_282 = (v_281>=Line_follower__high_thresh);
          v_278 = sen[1];
          v_279 = (v_278>=Line_follower__high_thresh);
          v_276 = sen[0];
          v_277 = (v_276<=Line_follower__low_thresh);
          v_280 = (v_277&&v_279);
          v_283 = (v_280&&v_282);
          v_286 = (v_283&&v_285);
          v_289 = (v_286&&v_288);
          v_304 = (v_289||v_303);
          v_319 = (v_304||v_318);
          v_334 = (v_319||v_333);
          only_one_low = (v_334||v_348);
          complete_St_1_Entry = false;
          v_r_St_5_Intersection_St_1_Entry = 40;
          v_l_St_5_Intersection_St_1_Entry = 40;
          dir_St_5_Intersection_St_1_Entry = 1;
          v_l_St_5_Intersection = v_l_St_5_Intersection_St_1_Entry;
          v_r_St_5_Intersection = v_r_St_5_Intersection_St_1_Entry;
          dir_St_5_Intersection = dir_St_5_Intersection_St_1_Entry;
          inx_counter_St_5_Intersection = inx_counter_St_5_Intersection_St_1_Entry;
          complete = complete_St_1_Entry;
          break;
        case Line_follower__St_1_ExitRight:
          inx_counter_St_5_Intersection_St_1_ExitRight = self->inx_counter_1;
          complete_St_1_ExitRight = !(all_high);
          v_r_St_5_Intersection_St_1_ExitRight = 40;
          v_l_St_5_Intersection_St_1_ExitRight = 40;
          dir_St_5_Intersection_St_1_ExitRight = 3;
          nr_1_St_1_ExitRight = false;
          ns_1_St_1_ExitRight = Line_follower__St_1_ExitRight;
          v_l_St_5_Intersection = v_l_St_5_Intersection_St_1_ExitRight;
          v_r_St_5_Intersection = v_r_St_5_Intersection_St_1_ExitRight;
          dir_St_5_Intersection = dir_St_5_Intersection_St_1_ExitRight;
          inx_counter_St_5_Intersection = inx_counter_St_5_Intersection_St_1_ExitRight;
          complete = complete_St_1_ExitRight;
          break;
        case Line_follower__St_1_ExitLeft:
          inx_counter_St_5_Intersection_St_1_ExitLeft = self->inx_counter_1;
          v_263 = sen[0];
          complete_St_1_ExitLeft = (v_263<=Line_follower__low_thresh);
          v_r_St_5_Intersection_St_1_ExitLeft = 40;
          v_l_St_5_Intersection_St_1_ExitLeft = 40;
          dir_St_5_Intersection_St_1_ExitLeft = 2;
          nr_1_St_1_ExitLeft = false;
          ns_1_St_1_ExitLeft = Line_follower__St_1_ExitLeft;
          v_l_St_5_Intersection = v_l_St_5_Intersection_St_1_ExitLeft;
          v_r_St_5_Intersection = v_r_St_5_Intersection_St_1_ExitLeft;
          dir_St_5_Intersection = dir_St_5_Intersection_St_1_ExitLeft;
          inx_counter_St_5_Intersection = inx_counter_St_5_Intersection_St_1_ExitLeft;
          complete = complete_St_1_ExitLeft;
          break;
        case Line_follower__St_1_ExitStraight:
          inx_counter_St_5_Intersection_St_1_ExitStraight = self->inx_counter_1;
          complete_St_1_ExitStraight = true;
          v_r_St_5_Intersection_St_1_ExitStraight = 0;
          v_l_St_5_Intersection_St_1_ExitStraight = 0;
          dir_St_5_Intersection_St_1_ExitStraight = 9;
          nr_1_St_1_ExitStraight = false;
          ns_1_St_1_ExitStraight = Line_follower__St_1_ExitStraight;
          v_l_St_5_Intersection = v_l_St_5_Intersection_St_1_ExitStraight;
          v_r_St_5_Intersection = v_r_St_5_Intersection_St_1_ExitStraight;
          dir_St_5_Intersection = dir_St_5_Intersection_St_1_ExitStraight;
          inx_counter_St_5_Intersection = inx_counter_St_5_Intersection_St_1_ExitStraight;
          complete = complete_St_1_ExitStraight;
          break;
        default:
          break;
      };
      inx_counter = inx_counter_St_5_Intersection;
      v_259 = (inx_counter==5);
      v_260 = (complete&&v_259);
      if (v_260) {
        v_262 = true;
        v_261 = Line_follower__St_5_Parking;
      } else {
        v_262 = false;
        v_261 = Line_follower__St_5_Intersection;
      };
      v_256 = (inx_counter==5);
      v_257 = !(v_256);
      v_258 = (complete&&v_257);
      if (v_258) {
        nr_5_St_5_Intersection = true;
        ns_5_St_5_Intersection = Line_follower__St_5_BonW;
      } else {
        nr_5_St_5_Intersection = v_262;
        ns_5_St_5_Intersection = v_261;
      };
      ns_5 = ns_5_St_5_Intersection;
      nr_5 = nr_5_St_5_Intersection;
      switch (ck_4) {
        case Line_follower__St_1_Entry:
          v_270 = (inx_counter==5);
          v_271 = (v_270&&only_one_low);
          if (v_271) {
            v_273 = true;
            v_272 = Line_follower__St_1_ExitStraight;
          } else {
            v_273 = false;
            v_272 = Line_follower__St_1_Entry;
          };
          v_267 = (inx_counter==4);
          v_266 = (inx_counter==3);
          v_268 = (v_266||v_267);
          v_269 = (v_268&&only_one_low);
          if (v_269) {
            v_275 = true;
            v_274 = Line_follower__St_1_ExitLeft;
          } else {
            v_275 = v_273;
            v_274 = v_272;
          };
          v_264 = (inx_counter<=2);
          v_265 = (v_264&&all_high);
          if (v_265) {
            nr_1_St_1_Entry = true;
            ns_1_St_1_Entry = Line_follower__St_1_ExitRight;
          } else {
            nr_1_St_1_Entry = v_275;
            ns_1_St_1_Entry = v_274;
          };
          ns_1 = ns_1_St_1_Entry;
          nr_1 = nr_1_St_1_Entry;
          break;
        case Line_follower__St_1_ExitStraight:
          ns_1 = ns_1_St_1_ExitStraight;
          nr_1 = nr_1_St_1_ExitStraight;
          break;
        case Line_follower__St_1_ExitLeft:
          ns_1 = ns_1_St_1_ExitLeft;
          nr_1 = nr_1_St_1_ExitLeft;
          break;
        case Line_follower__St_1_ExitRight:
          ns_1 = ns_1_St_1_ExitRight;
          nr_1 = nr_1_St_1_ExitRight;
          break;
        case Line_follower__St_1_Counter:
          ns_1 = ns_1_St_1_Counter;
          nr_1 = nr_1_St_1_Counter;
          break;
        default:
          break;
      };
      pid_error = pid_error_St_5_Intersection;
      parking_cycles_thresh = parking_cycles_thresh_St_5_Intersection;
      _out->v_l = v_l_St_5_Intersection;
      _out->v_r = v_r_St_5_Intersection;
      last_error = last_error_St_5_Intersection;
      _out->dir = dir_St_5_Intersection;
      {
        long _34;
        for (_34 = 0; _34 < 5; ++_34) {
          thresh_vals_St_5_Intersection[_34] = self->thresh_vals_1[_34];
        }
      };
      {
        long _35;
        for (_35 = 0; _35 < 5; ++_35) {
          min_vals_St_5_Intersection[_35] = self->min_vals_1[_35];
        }
      };
      {
        long _36;
        for (_36 = 0; _36 < 5; ++_36) {
          max_vals_St_5_Intersection[_36] = self->max_vals_1[_36];
        }
      };
      {
        long _37;
        for (_37 = 0; _37 < 5; ++_37) {
          thresh_vals[_37] = thresh_vals_St_5_Intersection[_37];
        }
      };
      {
        long _38;
        for (_38 = 0; _38 < 5; ++_38) {
          min_vals[_38] = min_vals_St_5_Intersection[_38];
        }
      };
      {
        long _39;
        for (_39 = 0; _39 < 5; ++_39) {
          max_vals[_39] = max_vals_St_5_Intersection[_39];
        }
      };
      self->v_352 = nr_1;
      self->v_351 = ns_1;
      break;
    case Line_follower__St_5_ObstacleAvoid:
      parking_cycles_thresh_St_5_ObstacleAvoid = self->parking_cycles_thresh_1;
      last_error_St_5_ObstacleAvoid = self->last_error_1;
      pid_error_St_5_ObstacleAvoid = self->pid_error_11;
      if (r_5) {
        pnr_3 = false;
        ck_5 = Line_follower__St_3_Wait;
      } else {
        pnr_3 = self->v_255;
        ck_5 = self->v_216;
      };
      v_184 = sen[4];
      v_185 = (v_184>=Line_follower__higher_thresh);
      v_181 = sen[3];
      v_182 = (v_181>=Line_follower__higher_thresh);
      v_178 = sen[2];
      v_179 = (v_178>=Line_follower__higher_thresh);
      v_175 = sen[1];
      v_176 = (v_175>=Line_follower__higher_thresh);
      v_173 = sen[0];
      v_174 = (v_173>=Line_follower__higher_thresh);
      v_177 = (v_174&&v_176);
      v_180 = (v_177&&v_179);
      v_183 = (v_180&&v_182);
      all_very_high = (v_183&&v_185);
      switch (ck_5) {
        case Line_follower__St_3_Wait:
          r_3_St_3_Wait = pnr_3;
          s_3_St_3_Wait = Line_follower__St_3_Wait;
          s_3 = s_3_St_3_Wait;
          r_3 = r_3_St_3_Wait;
          break;
        case Line_follower__St_3_FullRight:
          if (obs_left) {
            r_3_St_3_FullRight = true;
            s_3_St_3_FullRight = Line_follower__St_3_SlightStraight;
          } else {
            r_3_St_3_FullRight = pnr_3;
            s_3_St_3_FullRight = Line_follower__St_3_FullRight;
          };
          s_3 = s_3_St_3_FullRight;
          r_3 = r_3_St_3_FullRight;
          break;
        case Line_follower__St_3_SlightStraight:
          r_3_St_3_SlightStraight = pnr_3;
          s_3_St_3_SlightStraight = Line_follower__St_3_SlightStraight;
          s_3 = s_3_St_3_SlightStraight;
          r_3 = r_3_St_3_SlightStraight;
          break;
        case Line_follower__St_3_SlightRight:
          v_211 = !(all_high);
          if (v_211) {
            v_213 = true;
            v_212 = Line_follower__St_3_ExitStart;
          } else {
            v_213 = pnr_3;
            v_212 = Line_follower__St_3_SlightRight;
          };
          v_209 = (ir_value==0);
          v_210 = !(v_209);
          if (v_210) {
            v_215 = true;
            v_214 = Line_follower__St_3_FullRight;
          } else {
            v_215 = v_213;
            v_214 = v_212;
          };
          v_208 = !(obs_left);
          if (v_208) {
            r_3_St_3_SlightRight = true;
            s_3_St_3_SlightRight = Line_follower__St_3_SlightLeft;
          } else {
            r_3_St_3_SlightRight = v_215;
            s_3_St_3_SlightRight = v_214;
          };
          s_3 = s_3_St_3_SlightRight;
          r_3 = r_3_St_3_SlightRight;
          break;
        case Line_follower__St_3_SlightLeft:
          v_203 = !(all_high);
          if (v_203) {
            v_205 = true;
            v_204 = Line_follower__St_3_ExitStart;
          } else {
            v_205 = pnr_3;
            v_204 = Line_follower__St_3_SlightLeft;
          };
          v_201 = (ir_value==0);
          v_202 = !(v_201);
          if (v_202) {
            v_207 = true;
          } else {
            v_207 = v_205;
          };
          if (obs_left) {
            r_3_St_3_SlightLeft = true;
          } else {
            r_3_St_3_SlightLeft = v_207;
          };
          if (v_202) {
            v_206 = Line_follower__St_3_FullRight;
          } else {
            v_206 = v_204;
          };
          if (obs_left) {
            s_3_St_3_SlightLeft = Line_follower__St_3_SlightRight;
          } else {
            s_3_St_3_SlightLeft = v_206;
          };
          s_3 = s_3_St_3_SlightLeft;
          r_3 = r_3_St_3_SlightLeft;
          break;
        case Line_follower__St_3_ExitStart:
          v_196 = sen[4];
          v_197 = (v_196<=Line_follower__low_thresh);
          v_193 = sen[3];
          v_194 = (v_193<=Line_follower__low_thresh);
          v_191 = sen[2];
          v_192 = (v_191<=Line_follower__low_thresh);
          v_195 = (v_192||v_194);
          v_198 = (v_195||v_197);
          if (v_198) {
            v_200 = true;
            v_199 = Line_follower__St_3_ExitEnd2;
          } else {
            v_200 = pnr_3;
            v_199 = Line_follower__St_3_ExitStart;
          };
          v_188 = sen[1];
          v_189 = (v_188<=Line_follower__low_thresh);
          v_186 = sen[0];
          v_187 = (v_186<=Line_follower__low_thresh);
          v_190 = (v_187||v_189);
          if (v_190) {
            r_3_St_3_ExitStart = true;
            s_3_St_3_ExitStart = Line_follower__St_3_ExitEnd1;
          } else {
            r_3_St_3_ExitStart = v_200;
            s_3_St_3_ExitStart = v_199;
          };
          s_3 = s_3_St_3_ExitStart;
          r_3 = r_3_St_3_ExitStart;
          break;
        case Line_follower__St_3_ExitEnd1:
          r_3_St_3_ExitEnd1 = pnr_3;
          s_3_St_3_ExitEnd1 = Line_follower__St_3_ExitEnd1;
          s_3 = s_3_St_3_ExitEnd1;
          r_3 = r_3_St_3_ExitEnd1;
          break;
        case Line_follower__St_3_ExitEnd2:
          r_3_St_3_ExitEnd2 = pnr_3;
          s_3_St_3_ExitEnd2 = Line_follower__St_3_ExitEnd2;
          s_3 = s_3_St_3_ExitEnd2;
          r_3 = r_3_St_3_ExitEnd2;
          break;
        default:
          break;
      };
      ck_6 = s_3;
      switch (ck_6) {
        case Line_follower__St_3_Wait:
          inx_counter_St_5_ObstacleAvoid_St_3_Wait = self->inx_counter_1;
          v_254 = (ir_value==0);
          if (v_254) {
            complete_1_St_3_Wait = true;
          } else {
            complete_1_St_3_Wait = false;
          };
          v_253 = (self->v_252+1);
          v_250 = (r_5||r_3);
          if (self->v_249) {
            v_251 = true;
          } else {
            v_251 = v_250;
          };
          if (v_251) {
            ncycles = 0;
          } else {
            ncycles = v_253;
          };
          dir_St_5_ObstacleAvoid_St_3_Wait = 9;
          v_r_St_5_ObstacleAvoid_St_3_Wait = 0;
          v_l_St_5_ObstacleAvoid_St_3_Wait = 0;
          v_248 = (ncycles>1000);
          if (v_248) {
            nr_3_St_3_Wait = true;
            ns_3_St_3_Wait = Line_follower__St_3_FullRight;
          } else {
            nr_3_St_3_Wait = false;
            ns_3_St_3_Wait = Line_follower__St_3_Wait;
          };
          v_l_St_5_ObstacleAvoid = v_l_St_5_ObstacleAvoid_St_3_Wait;
          v_r_St_5_ObstacleAvoid = v_r_St_5_ObstacleAvoid_St_3_Wait;
          dir_St_5_ObstacleAvoid = dir_St_5_ObstacleAvoid_St_3_Wait;
          inx_counter_St_5_ObstacleAvoid = inx_counter_St_5_ObstacleAvoid_St_3_Wait;
          ns_3 = ns_3_St_3_Wait;
          nr_3 = nr_3_St_3_Wait;
          complete_1 = complete_1_St_3_Wait;
          break;
        case Line_follower__St_3_FullRight:
          inx_counter_St_5_ObstacleAvoid_St_3_FullRight = self->inx_counter_1;
          complete_1_St_3_FullRight = false;
          dir_St_5_ObstacleAvoid_St_3_FullRight = 3;
          v_r_St_5_ObstacleAvoid_St_3_FullRight = 40;
          v_l_St_5_ObstacleAvoid_St_3_FullRight = 40;
          nr_3_St_3_FullRight = false;
          ns_3_St_3_FullRight = Line_follower__St_3_FullRight;
          v_l_St_5_ObstacleAvoid = v_l_St_5_ObstacleAvoid_St_3_FullRight;
          v_r_St_5_ObstacleAvoid = v_r_St_5_ObstacleAvoid_St_3_FullRight;
          dir_St_5_ObstacleAvoid = dir_St_5_ObstacleAvoid_St_3_FullRight;
          inx_counter_St_5_ObstacleAvoid = inx_counter_St_5_ObstacleAvoid_St_3_FullRight;
          ns_3 = ns_3_St_3_FullRight;
          nr_3 = nr_3_St_3_FullRight;
          complete_1 = complete_1_St_3_FullRight;
          break;
        case Line_follower__St_3_SlightStraight:
          inx_counter_St_5_ObstacleAvoid_St_3_SlightStraight = self->inx_counter_1;
          complete_1_St_3_SlightStraight = false;
          v_247 = (self->v_246+1);
          v_244 = (r_5||r_3);
          if (self->v_243) {
            v_245 = true;
          } else {
            v_245 = v_244;
          };
          if (v_245) {
            ncycles_1 = 0;
          } else {
            ncycles_1 = v_247;
          };
          v_r_St_5_ObstacleAvoid_St_3_SlightStraight = 40;
          v_l_St_5_ObstacleAvoid_St_3_SlightStraight = 40;
          dir_St_5_ObstacleAvoid_St_3_SlightStraight = 1;
          if (all_high) {
            nr_3_St_3_SlightStraight = true;
            ns_3_St_3_SlightStraight = Line_follower__St_3_SlightLeft;
          } else {
            nr_3_St_3_SlightStraight = false;
            ns_3_St_3_SlightStraight = Line_follower__St_3_SlightStraight;
          };
          v_l_St_5_ObstacleAvoid = v_l_St_5_ObstacleAvoid_St_3_SlightStraight;
          v_r_St_5_ObstacleAvoid = v_r_St_5_ObstacleAvoid_St_3_SlightStraight;
          dir_St_5_ObstacleAvoid = dir_St_5_ObstacleAvoid_St_3_SlightStraight;
          inx_counter_St_5_ObstacleAvoid = inx_counter_St_5_ObstacleAvoid_St_3_SlightStraight;
          ns_3 = ns_3_St_3_SlightStraight;
          nr_3 = nr_3_St_3_SlightStraight;
          complete_1 = complete_1_St_3_SlightStraight;
          break;
        case Line_follower__St_3_SlightRight:
          inx_counter_St_5_ObstacleAvoid_St_3_SlightRight = self->inx_counter_1;
          complete_1_St_3_SlightRight = false;
          v_r_St_5_ObstacleAvoid_St_3_SlightRight = 10;
          v_l_St_5_ObstacleAvoid_St_3_SlightRight = 50;
          dir_St_5_ObstacleAvoid_St_3_SlightRight = 1;
          nr_3_St_3_SlightRight = false;
          ns_3_St_3_SlightRight = Line_follower__St_3_SlightRight;
          v_l_St_5_ObstacleAvoid = v_l_St_5_ObstacleAvoid_St_3_SlightRight;
          v_r_St_5_ObstacleAvoid = v_r_St_5_ObstacleAvoid_St_3_SlightRight;
          dir_St_5_ObstacleAvoid = dir_St_5_ObstacleAvoid_St_3_SlightRight;
          inx_counter_St_5_ObstacleAvoid = inx_counter_St_5_ObstacleAvoid_St_3_SlightRight;
          ns_3 = ns_3_St_3_SlightRight;
          nr_3 = nr_3_St_3_SlightRight;
          complete_1 = complete_1_St_3_SlightRight;
          break;
        case Line_follower__St_3_SlightLeft:
          inx_counter_St_5_ObstacleAvoid_St_3_SlightLeft = self->inx_counter_1;
          complete_1_St_3_SlightLeft = false;
          v_r_St_5_ObstacleAvoid_St_3_SlightLeft = 50;
          v_l_St_5_ObstacleAvoid_St_3_SlightLeft = 10;
          dir_St_5_ObstacleAvoid_St_3_SlightLeft = 1;
          nr_3_St_3_SlightLeft = false;
          ns_3_St_3_SlightLeft = Line_follower__St_3_SlightLeft;
          v_l_St_5_ObstacleAvoid = v_l_St_5_ObstacleAvoid_St_3_SlightLeft;
          v_r_St_5_ObstacleAvoid = v_r_St_5_ObstacleAvoid_St_3_SlightLeft;
          dir_St_5_ObstacleAvoid = dir_St_5_ObstacleAvoid_St_3_SlightLeft;
          inx_counter_St_5_ObstacleAvoid = inx_counter_St_5_ObstacleAvoid_St_3_SlightLeft;
          ns_3 = ns_3_St_3_SlightLeft;
          nr_3 = nr_3_St_3_SlightLeft;
          complete_1 = complete_1_St_3_SlightLeft;
          break;
        case Line_follower__St_3_ExitStart:
          inx_counter_St_5_ObstacleAvoid_St_3_ExitStart = 2;
          complete_1_St_3_ExitStart = false;
          v_r_St_5_ObstacleAvoid_St_3_ExitStart = 0;
          v_l_St_5_ObstacleAvoid_St_3_ExitStart = 0;
          dir_St_5_ObstacleAvoid_St_3_ExitStart = 9;
          nr_3_St_3_ExitStart = false;
          ns_3_St_3_ExitStart = Line_follower__St_3_ExitStart;
          v_l_St_5_ObstacleAvoid = v_l_St_5_ObstacleAvoid_St_3_ExitStart;
          v_r_St_5_ObstacleAvoid = v_r_St_5_ObstacleAvoid_St_3_ExitStart;
          dir_St_5_ObstacleAvoid = dir_St_5_ObstacleAvoid_St_3_ExitStart;
          inx_counter_St_5_ObstacleAvoid = inx_counter_St_5_ObstacleAvoid_St_3_ExitStart;
          ns_3 = ns_3_St_3_ExitStart;
          nr_3 = nr_3_St_3_ExitStart;
          complete_1 = complete_1_St_3_ExitStart;
          break;
        case Line_follower__St_3_ExitEnd1:
          inx_counter_St_5_ObstacleAvoid_St_3_ExitEnd1 = self->inx_counter_1;
          v_241 = (r_5||r_3);
          if (v_241) {
            pnr_2 = false;
          } else {
            pnr_2 = self->v_242;
          };
          v_238 = (r_5||r_3);
          if (v_238) {
            ck_7 = Line_follower__St_2_St_high_0;
          } else {
            ck_7 = self->v_239;
          };
          v_r_St_5_ObstacleAvoid_St_3_ExitEnd1 = 10;
          v_l_St_5_ObstacleAvoid_St_3_ExitEnd1 = 50;
          dir_St_5_ObstacleAvoid_St_3_ExitEnd1 = 1;
          nr_3_St_3_ExitEnd1 = false;
          ns_3_St_3_ExitEnd1 = Line_follower__St_3_ExitEnd1;
          v_l_St_5_ObstacleAvoid = v_l_St_5_ObstacleAvoid_St_3_ExitEnd1;
          v_r_St_5_ObstacleAvoid = v_r_St_5_ObstacleAvoid_St_3_ExitEnd1;
          dir_St_5_ObstacleAvoid = dir_St_5_ObstacleAvoid_St_3_ExitEnd1;
          inx_counter_St_5_ObstacleAvoid = inx_counter_St_5_ObstacleAvoid_St_3_ExitEnd1;
          ns_3 = ns_3_St_3_ExitEnd1;
          nr_3 = nr_3_St_3_ExitEnd1;
          switch (ck_7) {
            case Line_follower__St_2_St_high_0:
              v_236 = sen[0];
              v_237 = (v_236<=Line_follower__low_thresh);
              if (v_237) {
                r_2_St_2_St_high_0 = true;
                s_2_St_2_St_high_0 = Line_follower__St_2_St_low_1;
              } else {
                r_2_St_2_St_high_0 = pnr_2;
                s_2_St_2_St_high_0 = Line_follower__St_2_St_high_0;
              };
              s_2 = s_2_St_2_St_high_0;
              r_2 = r_2_St_2_St_high_0;
              break;
            case Line_follower__St_2_St_low_1:
              v_234 = sen[0];
              v_235 = (v_234>=Line_follower__high_thresh);
              if (v_235) {
                r_2_St_2_St_low_1 = true;
                s_2_St_2_St_low_1 = Line_follower__St_2_St_high_1;
              } else {
                r_2_St_2_St_low_1 = pnr_2;
                s_2_St_2_St_low_1 = Line_follower__St_2_St_low_1;
              };
              s_2 = s_2_St_2_St_low_1;
              r_2 = r_2_St_2_St_low_1;
              break;
            case Line_follower__St_2_St_high_1:
              r_2_St_2_St_high_1 = pnr_2;
              s_2_St_2_St_high_1 = Line_follower__St_2_St_high_1;
              s_2 = s_2_St_2_St_high_1;
              r_2 = r_2_St_2_St_high_1;
              break;
            default:
              break;
          };
          ck_8 = s_2;
          switch (ck_8) {
            case Line_follower__St_2_St_high_0:
              complete_1_St_3_ExitEnd1_St_2_St_high_0 = false;
              nr_2_St_2_St_high_0 = false;
              ns_2_St_2_St_high_0 = Line_follower__St_2_St_high_0;
              complete_1_St_3_ExitEnd1 = complete_1_St_3_ExitEnd1_St_2_St_high_0;
              ns_2 = ns_2_St_2_St_high_0;
              nr_2 = nr_2_St_2_St_high_0;
              break;
            case Line_follower__St_2_St_low_1:
              complete_1_St_3_ExitEnd1_St_2_St_low_1 = false;
              nr_2_St_2_St_low_1 = false;
              ns_2_St_2_St_low_1 = Line_follower__St_2_St_low_1;
              complete_1_St_3_ExitEnd1 = complete_1_St_3_ExitEnd1_St_2_St_low_1;
              ns_2 = ns_2_St_2_St_low_1;
              nr_2 = nr_2_St_2_St_low_1;
              break;
            case Line_follower__St_2_St_high_1:
              v_240 = sen[0];
              complete_1_St_3_ExitEnd1_St_2_St_high_1 = (v_240<=Line_follower__low_thresh);
              nr_2_St_2_St_high_1 = false;
              ns_2_St_2_St_high_1 = Line_follower__St_2_St_high_1;
              complete_1_St_3_ExitEnd1 = complete_1_St_3_ExitEnd1_St_2_St_high_1;
              ns_2 = ns_2_St_2_St_high_1;
              nr_2 = nr_2_St_2_St_high_1;
              break;
            default:
              break;
          };
          complete_1 = complete_1_St_3_ExitEnd1;
          break;
        case Line_follower__St_3_ExitEnd2:
          inx_counter_St_5_ObstacleAvoid_St_3_ExitEnd2 = self->inx_counter_1;
          v_232 = sen[2];
          v_233 = (v_232<=Line_follower__low_thresh);
          v_228 = sen[2];
          v_229 = (v_228>=Line_follower__high_thresh);
          v_225 = (r_5||r_3);
          if (self->v_224) {
            v_226 = true;
          } else {
            v_226 = v_225;
          };
          v_221 = sen[1];
          v_222 = (v_221<=Line_follower__low_thresh);
          if (self->v_220) {
            v_223 = true;
          } else {
            v_223 = v_222;
          };
          v_218 = (r_5||r_3);
          if (self->v_217) {
            v_219 = true;
          } else {
            v_219 = v_218;
          };
          if (v_219) {
            sen_1_low1 = false;
          } else {
            sen_1_low1 = v_223;
          };
          v_230 = (sen_1_low1&&v_229);
          if (self->v_227) {
            v_231 = true;
          } else {
            v_231 = v_230;
          };
          if (v_226) {
            sen_1_high1 = false;
          } else {
            sen_1_high1 = v_231;
          };
          complete_1_St_3_ExitEnd2 = (sen_1_high1&&v_233);
          v_r_St_5_ObstacleAvoid_St_3_ExitEnd2 = 10;
          v_l_St_5_ObstacleAvoid_St_3_ExitEnd2 = 50;
          dir_St_5_ObstacleAvoid_St_3_ExitEnd2 = 1;
          nr_3_St_3_ExitEnd2 = false;
          ns_3_St_3_ExitEnd2 = Line_follower__St_3_ExitEnd2;
          v_l_St_5_ObstacleAvoid = v_l_St_5_ObstacleAvoid_St_3_ExitEnd2;
          v_r_St_5_ObstacleAvoid = v_r_St_5_ObstacleAvoid_St_3_ExitEnd2;
          dir_St_5_ObstacleAvoid = dir_St_5_ObstacleAvoid_St_3_ExitEnd2;
          inx_counter_St_5_ObstacleAvoid = inx_counter_St_5_ObstacleAvoid_St_3_ExitEnd2;
          ns_3 = ns_3_St_3_ExitEnd2;
          nr_3 = nr_3_St_3_ExitEnd2;
          complete_1 = complete_1_St_3_ExitEnd2;
          break;
        default:
          break;
      };
      if (complete_1) {
        nr_5_St_5_ObstacleAvoid = true;
        ns_5_St_5_ObstacleAvoid = Line_follower__St_5_BonW;
      } else {
        nr_5_St_5_ObstacleAvoid = false;
        ns_5_St_5_ObstacleAvoid = Line_follower__St_5_ObstacleAvoid;
      };
      inx_counter = inx_counter_St_5_ObstacleAvoid;
      ns_5 = ns_5_St_5_ObstacleAvoid;
      nr_5 = nr_5_St_5_ObstacleAvoid;
      pid_error = pid_error_St_5_ObstacleAvoid;
      parking_cycles_thresh = parking_cycles_thresh_St_5_ObstacleAvoid;
      _out->v_l = v_l_St_5_ObstacleAvoid;
      _out->v_r = v_r_St_5_ObstacleAvoid;
      last_error = last_error_St_5_ObstacleAvoid;
      _out->dir = dir_St_5_ObstacleAvoid;
      {
        long _40;
        for (_40 = 0; _40 < 5; ++_40) {
          thresh_vals_St_5_ObstacleAvoid[_40] = self->thresh_vals_1[_40];
        }
      };
      {
        long _41;
        for (_41 = 0; _41 < 5; ++_41) {
          thresh_vals[_41] = thresh_vals_St_5_ObstacleAvoid[_41];
        }
      };
      {
        long _42;
        for (_42 = 0; _42 < 5; ++_42) {
          min_vals_St_5_ObstacleAvoid[_42] = self->min_vals_1[_42];
        }
      };
      {
        long _43;
        for (_43 = 0; _43 < 5; ++_43) {
          min_vals[_43] = min_vals_St_5_ObstacleAvoid[_43];
        }
      };
      {
        long _44;
        for (_44 = 0; _44 < 5; ++_44) {
          max_vals_St_5_ObstacleAvoid[_44] = self->max_vals_1[_44];
        }
      };
      {
        long _45;
        for (_45 = 0; _45 < 5; ++_45) {
          max_vals[_45] = max_vals_St_5_ObstacleAvoid[_45];
        }
      };
      self->v_255 = nr_3;
      self->v_216 = ns_3;
      break;
    case Line_follower__St_5_Parking:
      inx_counter_St_5_Parking = self->inx_counter_1;
      last_error_St_5_Parking = self->last_error_1;
      if (r_5) {
        pnr_4 = false;
      } else {
        pnr_4 = self->v_172;
      };
      r_4 = pnr_4;
      if (r_5) {
        ck_9 = Line_follower__St_4_Train;
      } else {
        ck_9 = self->v_171;
      };
      nr_5_St_5_Parking = false;
      ns_5_St_5_Parking = Line_follower__St_5_Parking;
      inx_counter = inx_counter_St_5_Parking;
      ns_5 = ns_5_St_5_Parking;
      nr_5 = nr_5_St_5_Parking;
      switch (ck_9) {
        case Line_follower__St_4_Train:
          v_165 = !(obs_right);
          v_163 = !(obs_left);
          v_162 = (obs_left&&obs_right);
          v_160 = (self->v_159+1);
          v_157 = !(obs_right);
          v_155 = (r_5||r_4);
          if (self->v_154) {
            v_156 = true;
          } else {
            v_156 = v_155;
          };
          v_152 = (self->v_151+1);
          v_149 = !(obs_left);
          v_147 = (r_5||r_4);
          if (self->v_146) {
            v_148 = true;
          } else {
            v_148 = v_147;
          };
          if (self->v_144) {
            v_145 = true;
          } else {
            v_145 = obs_right;
          };
          v_142 = (r_5||r_4);
          if (self->v_141) {
            v_143 = true;
          } else {
            v_143 = v_142;
          };
          if (v_143) {
            right_was_high = false;
          } else {
            right_was_high = v_145;
          };
          v_158 = (v_157&&right_was_high);
          if (v_158) {
            v_161 = v_160;
          } else {
            v_161 = 0;
          };
          if (v_156) {
            cycles_right = 0;
          } else {
            cycles_right = v_161;
          };
          Line_follower__max_step(self->parking_cycles_thresh_1,
                                  cycles_right, &Line_follower__max_out_st);
          v_166 = Line_follower__max_out_st.val_m;
          if (self->v_139) {
            v_140 = true;
          } else {
            v_140 = obs_left;
          };
          v_137 = (r_5||r_4);
          if (self->v_136) {
            v_138 = true;
          } else {
            v_138 = v_137;
          };
          if (v_138) {
            left_was_high = false;
          } else {
            left_was_high = v_140;
          };
          v_150 = (v_149&&left_was_high);
          if (v_150) {
            v_153 = v_152;
          } else {
            v_153 = 0;
          };
          if (v_148) {
            cycles_left = 0;
          } else {
            cycles_left = v_153;
          };
          Line_follower__max_step(cycles_left, cycles_right,
                                  &Line_follower__max_out_st);
          v_167 = Line_follower__max_out_st.val_m;
          Line_follower__max_step(self->parking_cycles_thresh_1, v_167,
                                  &Line_follower__max_out_st);
          v_168 = Line_follower__max_out_st.val_m;
          if (v_165) {
            v_169 = v_166;
          } else {
            v_169 = v_168;
          };
          Line_follower__max_step(self->parking_cycles_thresh_1, cycles_left,
                                  &Line_follower__max_out_st);
          v_164 = Line_follower__max_out_st.val_m;
          if (v_163) {
            v_170 = v_164;
          } else {
            v_170 = v_169;
          };
          if (v_162) {
            parking_cycles_thresh_St_5_Parking_St_4_Train = self->parking_cycles_thresh_1;
          } else {
            parking_cycles_thresh_St_5_Parking_St_4_Train = v_170;
          };
          r_9 = (r_5||r_4);
          if (r_9) {
            Line_follower__calPidError_reset(&self->calPidError_3);
          };
          Line_follower__calPidError_step(sensor_avg,
                                          Line_follower__kscale_black,
                                          &Line_follower__calPidError_out_st,
                                          &self->calPidError_3);
          pid_error_St_5_Parking_St_4_Train = Line_follower__calPidError_out_st.pid_error;
          pid_error_St_5_Parking = pid_error_St_5_Parking_St_4_Train;
          parking_cycles_thresh_St_5_Parking = parking_cycles_thresh_St_5_Parking_St_4_Train;
          break;
        case Line_follower__St_4_FindSpace:
          parking_cycles_thresh_St_5_Parking_St_4_FindSpace = self->parking_cycles_thresh_1;
          v_131 = (self->v_130+1);
          if (obs_right) {
            v_132 = 0;
          } else {
            v_132 = v_131;
          };
          v_128 = (r_5||r_4);
          if (self->v_127) {
            v_129 = true;
          } else {
            v_129 = v_128;
          };
          if (v_129) {
            cycles_right_1 = 0;
          } else {
            cycles_right_1 = v_132;
          };
          v_125 = (self->v_124+1);
          if (obs_left) {
            v_126 = 0;
          } else {
            v_126 = v_125;
          };
          v_122 = (r_5||r_4);
          if (self->v_121) {
            v_123 = true;
          } else {
            v_123 = v_122;
          };
          if (v_123) {
            cycles_left_1 = 0;
          } else {
            cycles_left_1 = v_126;
          };
          r_8 = (r_5||r_4);
          if (r_8) {
            Line_follower__calPidError_reset(&self->calPidError_2);
          };
          Line_follower__calPidError_step(sensor_avg,
                                          Line_follower__kscale_black,
                                          &Line_follower__calPidError_out_st,
                                          &self->calPidError_2);
          pid_error_St_5_Parking_St_4_FindSpace = Line_follower__calPidError_out_st.pid_error;
          pid_error_St_5_Parking = pid_error_St_5_Parking_St_4_FindSpace;
          parking_cycles_thresh_St_5_Parking = parking_cycles_thresh_St_5_Parking_St_4_FindSpace;
          break;
        case Line_follower__St_4_GoBackL:
          parking_cycles_thresh_St_5_Parking_St_4_GoBackL = self->parking_cycles_thresh_1;
          dir_St_5_Parking_St_4_GoBackL = 4;
          v_112 = (self->v_111+1);
          v_109 = (r_5||r_4);
          if (self->v_108) {
            v_110 = true;
          } else {
            v_110 = v_109;
          };
          if (v_110) {
            ncycles_2 = 0;
          } else {
            ncycles_2 = v_112;
          };
          r_7 = (r_5||r_4);
          if (r_7) {
            Line_follower__calPidError_reset(&self->calPidError_1);
          };
          Line_follower__calPidError_step(sensor_avg,
                                          Line_follower__kscale_black,
                                          &Line_follower__calPidError_out_st,
                                          &self->calPidError_1);
          pid_error_St_5_Parking_St_4_GoBackL = Line_follower__calPidError_out_st.pid_error;
          pid_error_St_5_Parking = pid_error_St_5_Parking_St_4_GoBackL;
          parking_cycles_thresh_St_5_Parking = parking_cycles_thresh_St_5_Parking_St_4_GoBackL;
          break;
        case Line_follower__St_4_GoBackR:
          parking_cycles_thresh_St_5_Parking_St_4_GoBackR = self->parking_cycles_thresh_1;
          dir_St_5_Parking_St_4_GoBackR = 4;
          v_104 = (self->v_103+1);
          v_101 = (r_5||r_4);
          if (self->v_100) {
            v_102 = true;
          } else {
            v_102 = v_101;
          };
          if (v_102) {
            ncycles_3 = 0;
          } else {
            ncycles_3 = v_104;
          };
          r_6 = (r_5||r_4);
          if (r_6) {
            Line_follower__calPidError_reset(&self->calPidError);
          };
          Line_follower__calPidError_step(sensor_avg,
                                          Line_follower__kscale_black,
                                          &Line_follower__calPidError_out_st,
                                          &self->calPidError);
          pid_error_St_5_Parking_St_4_GoBackR = Line_follower__calPidError_out_st.pid_error;
          pid_error_St_5_Parking = pid_error_St_5_Parking_St_4_GoBackR;
          parking_cycles_thresh_St_5_Parking = parking_cycles_thresh_St_5_Parking_St_4_GoBackR;
          break;
        case Line_follower__St_4_ParkLeft:
          parking_cycles_thresh_St_5_Parking_St_4_ParkLeft = self->parking_cycles_thresh_1;
          pid_error_St_5_Parking_St_4_ParkLeft = self->pid_error_11;
          dir_St_5_Parking_St_4_ParkLeft = 3;
          v_r_St_5_Parking_St_4_ParkLeft = 50;
          v_l_St_5_Parking_St_4_ParkLeft = 50;
          v_96 = (self->v_95+1);
          v_93 = (r_5||r_4);
          if (self->v_92) {
            v_94 = true;
          } else {
            v_94 = v_93;
          };
          if (v_94) {
            ncycles_4 = 0;
          } else {
            ncycles_4 = v_96;
          };
          pid_error_St_5_Parking = pid_error_St_5_Parking_St_4_ParkLeft;
          parking_cycles_thresh_St_5_Parking = parking_cycles_thresh_St_5_Parking_St_4_ParkLeft;
          break;
        case Line_follower__St_4_ParkRight:
          parking_cycles_thresh_St_5_Parking_St_4_ParkRight = self->parking_cycles_thresh_1;
          pid_error_St_5_Parking_St_4_ParkRight = self->pid_error_11;
          dir_St_5_Parking_St_4_ParkRight = 2;
          v_r_St_5_Parking_St_4_ParkRight = 50;
          v_l_St_5_Parking_St_4_ParkRight = 50;
          v_88 = (self->v_87+1);
          v_85 = (r_5||r_4);
          if (self->v_84) {
            v_86 = true;
          } else {
            v_86 = v_85;
          };
          if (v_86) {
            ncycles_5 = 0;
          } else {
            ncycles_5 = v_88;
          };
          pid_error_St_5_Parking = pid_error_St_5_Parking_St_4_ParkRight;
          parking_cycles_thresh_St_5_Parking = parking_cycles_thresh_St_5_Parking_St_4_ParkRight;
          break;
        case Line_follower__St_4_GoReverse:
          parking_cycles_thresh_St_5_Parking_St_4_GoReverse = self->parking_cycles_thresh_1;
          pid_error_St_5_Parking_St_4_GoReverse = self->pid_error_11;
          dir_St_5_Parking_St_4_GoReverse = 4;
          v_r_St_5_Parking_St_4_GoReverse = 50;
          v_l_St_5_Parking_St_4_GoReverse = 50;
          v_80 = (self->v_79+1);
          v_77 = (r_5||r_4);
          if (self->v_76) {
            v_78 = true;
          } else {
            v_78 = v_77;
          };
          if (v_78) {
            ncycles_6 = 0;
          } else {
            ncycles_6 = v_80;
          };
          pid_error_St_5_Parking = pid_error_St_5_Parking_St_4_GoReverse;
          parking_cycles_thresh_St_5_Parking = parking_cycles_thresh_St_5_Parking_St_4_GoReverse;
          break;
        case Line_follower__St_4_Stop:
          parking_cycles_thresh_St_5_Parking_St_4_Stop = self->parking_cycles_thresh_1;
          pid_error_St_5_Parking_St_4_Stop = self->pid_error_11;
          dir_St_5_Parking_St_4_Stop = 9;
          v_r_St_5_Parking_St_4_Stop = 0;
          v_l_St_5_Parking_St_4_Stop = 0;
          nr_4_St_4_Stop = false;
          ns_4_St_4_Stop = Line_follower__St_4_Stop;
          pid_error_St_5_Parking = pid_error_St_5_Parking_St_4_Stop;
          parking_cycles_thresh_St_5_Parking = parking_cycles_thresh_St_5_Parking_St_4_Stop;
          break;
        default:
          break;
      };
      pid_error = pid_error_St_5_Parking;
      parking_cycles_thresh = parking_cycles_thresh_St_5_Parking;
      switch (ck_9) {
        case Line_follower__St_4_Train:
          Line_follower__pid_err_to_speeds_park_step(pid_error,
                                                     &Line_follower__pid_err_to_speeds_park_out_st);
          v_l_St_5_Parking_St_4_Train = Line_follower__pid_err_to_speeds_park_out_st.v_l;
          v_r_St_5_Parking_St_4_Train = Line_follower__pid_err_to_speeds_park_out_st.v_r;
          dir_St_5_Parking_St_4_Train = Line_follower__pid_err_to_speeds_park_out_st.dir;
          v_133 = (parking_cycles_thresh>0);
          v_134 = (v_133&&obs_left);
          v_135 = (v_134&&obs_right);
          if (v_135) {
            nr_4_St_4_Train = true;
            ns_4_St_4_Train = Line_follower__St_4_FindSpace;
          } else {
            nr_4_St_4_Train = false;
            ns_4_St_4_Train = Line_follower__St_4_Train;
          };
          v_l_St_5_Parking = v_l_St_5_Parking_St_4_Train;
          v_r_St_5_Parking = v_r_St_5_Parking_St_4_Train;
          dir_St_5_Parking = dir_St_5_Parking_St_4_Train;
          ns_4 = ns_4_St_4_Train;
          nr_4 = nr_4_St_4_Train;
          break;
        case Line_follower__St_4_FindSpace:
          Line_follower__pid_err_to_speeds_park_step(pid_error,
                                                     &Line_follower__pid_err_to_speeds_park_out_st);
          v_l_St_5_Parking_St_4_FindSpace = Line_follower__pid_err_to_speeds_park_out_st.v_l;
          v_r_St_5_Parking_St_4_FindSpace = Line_follower__pid_err_to_speeds_park_out_st.v_r;
          dir_St_5_Parking_St_4_FindSpace = Line_follower__pid_err_to_speeds_park_out_st.dir;
          v_116 = (parking_cycles_thresh*7);
          v_117 = (v_116/3);
          v_118 = (cycles_right_1>v_117);
          if (v_118) {
            v_120 = true;
            v_119 = Line_follower__St_4_GoBackR;
          } else {
            v_120 = false;
            v_119 = Line_follower__St_4_FindSpace;
          };
          v_113 = (parking_cycles_thresh*7);
          v_114 = (v_113/3);
          v_115 = (cycles_left_1>v_114);
          if (v_115) {
            nr_4_St_4_FindSpace = true;
            ns_4_St_4_FindSpace = Line_follower__St_4_GoBackL;
          } else {
            nr_4_St_4_FindSpace = v_120;
            ns_4_St_4_FindSpace = v_119;
          };
          v_l_St_5_Parking = v_l_St_5_Parking_St_4_FindSpace;
          v_r_St_5_Parking = v_r_St_5_Parking_St_4_FindSpace;
          dir_St_5_Parking = dir_St_5_Parking_St_4_FindSpace;
          ns_4 = ns_4_St_4_FindSpace;
          nr_4 = nr_4_St_4_FindSpace;
          break;
        case Line_follower__St_4_GoBackL:
          Line_follower__pid_err_to_speeds_park_step(pid_error,
                                                     &Line_follower__pid_err_to_speeds_park_out_st);
          v_l_St_5_Parking_St_4_GoBackL = Line_follower__pid_err_to_speeds_park_out_st.v_l;
          v_r_St_5_Parking_St_4_GoBackL = Line_follower__pid_err_to_speeds_park_out_st.v_r;
          locdir = Line_follower__pid_err_to_speeds_park_out_st.dir;
          v_105 = (parking_cycles_thresh*7);
          v_106 = (v_105/6);
          v_107 = (ncycles_2>v_106);
          if (v_107) {
            nr_4_St_4_GoBackL = true;
            ns_4_St_4_GoBackL = Line_follower__St_4_ParkLeft;
          } else {
            nr_4_St_4_GoBackL = false;
            ns_4_St_4_GoBackL = Line_follower__St_4_GoBackL;
          };
          v_l_St_5_Parking = v_l_St_5_Parking_St_4_GoBackL;
          v_r_St_5_Parking = v_r_St_5_Parking_St_4_GoBackL;
          dir_St_5_Parking = dir_St_5_Parking_St_4_GoBackL;
          ns_4 = ns_4_St_4_GoBackL;
          nr_4 = nr_4_St_4_GoBackL;
          break;
        case Line_follower__St_4_GoBackR:
          Line_follower__pid_err_to_speeds_park_step(pid_error,
                                                     &Line_follower__pid_err_to_speeds_park_out_st);
          v_l_St_5_Parking_St_4_GoBackR = Line_follower__pid_err_to_speeds_park_out_st.v_l;
          v_r_St_5_Parking_St_4_GoBackR = Line_follower__pid_err_to_speeds_park_out_st.v_r;
          locdir_1 = Line_follower__pid_err_to_speeds_park_out_st.dir;
          v_97 = (parking_cycles_thresh*7);
          v_98 = (v_97/6);
          v_99 = (ncycles_3>v_98);
          if (v_99) {
            nr_4_St_4_GoBackR = true;
            ns_4_St_4_GoBackR = Line_follower__St_4_ParkRight;
          } else {
            nr_4_St_4_GoBackR = false;
            ns_4_St_4_GoBackR = Line_follower__St_4_GoBackR;
          };
          v_l_St_5_Parking = v_l_St_5_Parking_St_4_GoBackR;
          v_r_St_5_Parking = v_r_St_5_Parking_St_4_GoBackR;
          dir_St_5_Parking = dir_St_5_Parking_St_4_GoBackR;
          ns_4 = ns_4_St_4_GoBackR;
          nr_4 = nr_4_St_4_GoBackR;
          break;
        case Line_follower__St_4_ParkLeft:
          v_89 = (parking_cycles_thresh*3);
          v_90 = (v_89/4);
          v_91 = (ncycles_4>v_90);
          if (v_91) {
            nr_4_St_4_ParkLeft = true;
            ns_4_St_4_ParkLeft = Line_follower__St_4_GoReverse;
          } else {
            nr_4_St_4_ParkLeft = false;
            ns_4_St_4_ParkLeft = Line_follower__St_4_ParkLeft;
          };
          v_l_St_5_Parking = v_l_St_5_Parking_St_4_ParkLeft;
          v_r_St_5_Parking = v_r_St_5_Parking_St_4_ParkLeft;
          dir_St_5_Parking = dir_St_5_Parking_St_4_ParkLeft;
          ns_4 = ns_4_St_4_ParkLeft;
          nr_4 = nr_4_St_4_ParkLeft;
          break;
        case Line_follower__St_4_ParkRight:
          v_81 = (parking_cycles_thresh*3);
          v_82 = (v_81/4);
          v_83 = (ncycles_5>v_82);
          if (v_83) {
            nr_4_St_4_ParkRight = true;
            ns_4_St_4_ParkRight = Line_follower__St_4_GoReverse;
          } else {
            nr_4_St_4_ParkRight = false;
            ns_4_St_4_ParkRight = Line_follower__St_4_ParkRight;
          };
          v_l_St_5_Parking = v_l_St_5_Parking_St_4_ParkRight;
          v_r_St_5_Parking = v_r_St_5_Parking_St_4_ParkRight;
          dir_St_5_Parking = dir_St_5_Parking_St_4_ParkRight;
          ns_4 = ns_4_St_4_ParkRight;
          nr_4 = nr_4_St_4_ParkRight;
          break;
        case Line_follower__St_4_GoReverse:
          v_73 = (parking_cycles_thresh*3);
          v_74 = (v_73/3);
          v_75 = (ncycles_6>v_74);
          if (v_75) {
            nr_4_St_4_GoReverse = true;
            ns_4_St_4_GoReverse = Line_follower__St_4_Stop;
          } else {
            nr_4_St_4_GoReverse = false;
            ns_4_St_4_GoReverse = Line_follower__St_4_GoReverse;
          };
          v_l_St_5_Parking = v_l_St_5_Parking_St_4_GoReverse;
          v_r_St_5_Parking = v_r_St_5_Parking_St_4_GoReverse;
          dir_St_5_Parking = dir_St_5_Parking_St_4_GoReverse;
          ns_4 = ns_4_St_4_GoReverse;
          nr_4 = nr_4_St_4_GoReverse;
          break;
        case Line_follower__St_4_Stop:
          v_l_St_5_Parking = v_l_St_5_Parking_St_4_Stop;
          v_r_St_5_Parking = v_r_St_5_Parking_St_4_Stop;
          dir_St_5_Parking = dir_St_5_Parking_St_4_Stop;
          ns_4 = ns_4_St_4_Stop;
          nr_4 = nr_4_St_4_Stop;
          break;
        default:
          break;
      };
      _out->v_l = v_l_St_5_Parking;
      _out->v_r = v_r_St_5_Parking;
      last_error = last_error_St_5_Parking;
      _out->dir = dir_St_5_Parking;
      {
        long _46;
        for (_46 = 0; _46 < 5; ++_46) {
          thresh_vals_St_5_Parking[_46] = self->thresh_vals_1[_46];
        }
      };
      {
        long _47;
        for (_47 = 0; _47 < 5; ++_47) {
          thresh_vals[_47] = thresh_vals_St_5_Parking[_47];
        }
      };
      {
        long _48;
        for (_48 = 0; _48 < 5; ++_48) {
          min_vals_St_5_Parking[_48] = self->min_vals_1[_48];
        }
      };
      {
        long _49;
        for (_49 = 0; _49 < 5; ++_49) {
          min_vals[_49] = min_vals_St_5_Parking[_49];
        }
      };
      {
        long _50;
        for (_50 = 0; _50 < 5; ++_50) {
          max_vals_St_5_Parking[_50] = self->max_vals_1[_50];
        }
      };
      {
        long _51;
        for (_51 = 0; _51 < 5; ++_51) {
          max_vals[_51] = max_vals_St_5_Parking[_51];
        }
      };
      self->v_172 = nr_4;
      self->v_171 = ns_4;
      break;
    default:
      break;
  };
  self->parking_cycles_thresh_1 = parking_cycles_thresh;
  self->inx_counter_1 = inx_counter;
  {
    long _52;
    for (_52 = 0; _52 < 5; ++_52) {
      self->sen_2[_52] = sen[_52];
    }
  };
  {
    long _53;
    for (_53 = 0; _53 < 5; ++_53) {
      self->thresh_vals_1[_53] = thresh_vals[_53];
    }
  };
  {
    long _54;
    for (_54 = 0; _54 < 5; ++_54) {
      self->min_vals_1[_54] = min_vals[_54];
    }
  };
  {
    long _55;
    for (_55 = 0; _55 < 5; ++_55) {
      self->max_vals_1[_55] = max_vals[_55];
    }
  };
  self->last_error_1 = last_error;
  self->pid_error_11 = pid_error;
  self->pnr_5 = nr_5;
  self->ck = ns_5;
  switch (ck_1) {
    case Line_follower__St_5_ObstacleAvoid:
      switch (ck_6) {
        case Line_follower__St_3_Wait:
          self->v_252 = ncycles;
          self->v_249 = false;
          break;
        case Line_follower__St_3_SlightStraight:
          self->v_246 = ncycles_1;
          self->v_243 = false;
          break;
        case Line_follower__St_3_ExitEnd1:
          self->v_242 = nr_2;
          self->v_239 = ns_2;
          break;
        case Line_follower__St_3_ExitEnd2:
          self->v_227 = sen_1_high1;
          self->v_224 = false;
          self->v_220 = sen_1_low1;
          self->v_217 = false;
          break;
        default:
          break;
      };
      break;
    case Line_follower__St_5_Parking:
      switch (ck_9) {
        case Line_follower__St_4_Train:
          self->v_159 = cycles_right;
          self->v_154 = false;
          self->v_151 = cycles_left;
          self->v_146 = false;
          self->v_144 = right_was_high;
          self->v_141 = false;
          self->v_139 = left_was_high;
          self->v_136 = false;
          break;
        case Line_follower__St_4_FindSpace:
          self->v_130 = cycles_right_1;
          self->v_127 = false;
          self->v_124 = cycles_left_1;
          self->v_121 = false;
          break;
        case Line_follower__St_4_GoBackL:
          self->v_111 = ncycles_2;
          self->v_108 = false;
          break;
        case Line_follower__St_4_GoBackR:
          self->v_103 = ncycles_3;
          self->v_100 = false;
          break;
        case Line_follower__St_4_ParkLeft:
          self->v_95 = ncycles_4;
          self->v_92 = false;
          break;
        case Line_follower__St_4_ParkRight:
          self->v_87 = ncycles_5;
          self->v_84 = false;
          break;
        case Line_follower__St_4_GoReverse:
          self->v_79 = ncycles_6;
          self->v_76 = false;
          break;
        default:
          break;
      };
      break;
    default:
      break;
  };;
}

