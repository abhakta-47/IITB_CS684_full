/* --- Generated the 8/4/2025 at 16:58 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. mar. 8 9:40:4 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#ifndef LINE_FOLLOWER_H
#define LINE_FOLLOWER_H

#include "line_follower_types.h"
typedef struct Line_follower__calPidError_mem {
  long v_10;
  long v_9;
  long v_6;
  long v_5;
  long v_1;
  long v;
} Line_follower__calPidError_mem;

typedef struct Line_follower__calPidError_out {
  long pid_error;
} Line_follower__calPidError_out;

void Line_follower__calPidError_reset(Line_follower__calPidError_mem* self);

void Line_follower__calPidError_step(long value, long scale_down,
                                     Line_follower__calPidError_out* _out,
                                     Line_follower__calPidError_mem* self);

typedef struct Line_follower__weightedSum_out {
  long weighted_sum;
} Line_follower__weightedSum_out;

void Line_follower__weightedSum_step(long sen_value, long sen_weight,
                                     long prev_sum,
                                     Line_follower__weightedSum_out* _out);

typedef struct Line_follower__senWeightedAvg_out {
  long sensor_avg;
} Line_follower__senWeightedAvg_out;

void Line_follower__senWeightedAvg_step(long sen[5],
                                        Line_follower__senWeightedAvg_out* _out);

typedef struct Line_follower__safe_motor_update_out {
  long new_speed;
} Line_follower__safe_motor_update_out;

void Line_follower__safe_motor_update_step(long cur_speed, long change,
                                           Line_follower__safe_motor_update_out* _out);

typedef struct Line_follower__normalize_value_out {
  long norm_val;
} Line_follower__normalize_value_out;

void Line_follower__normalize_value_step(long min_val, long max_val, long value,
                                         Line_follower__normalize_value_out* _out);

typedef struct Line_follower__updateMins_out {
  long new_min;
} Line_follower__updateMins_out;

void Line_follower__updateMins_step(long cur_val, long cur_thresh, long cur_min,
                                    Line_follower__updateMins_out* _out);

typedef struct Line_follower__updateMaxs_out {
  long new_max;
} Line_follower__updateMaxs_out;

void Line_follower__updateMaxs_step(long cur_val, long cur_thresh, long cur_max,
                                    Line_follower__updateMaxs_out* _out);

typedef struct Line_follower__max_out {
  long val_m;
} Line_follower__max_out;

void Line_follower__max_step(long val_a, long val_b,
                             Line_follower__max_out* _out);

typedef struct Line_follower__abs_out {
  long out;
} Line_follower__abs_out;

void Line_follower__abs_step(long input, Line_follower__abs_out* _out);

typedef struct Line_follower__pid_err_to_speeds_park_out {
  long v_l;
  long v_r;
  long dir;
} Line_follower__pid_err_to_speeds_park_out;

void Line_follower__pid_err_to_speeds_park_step(long pid_error,
                                                Line_follower__pid_err_to_speeds_park_out* _out);

typedef struct Line_follower__main_mem {
  Line_follower__st_5 ck;
  long v_79;
  long v_76;
  long v_87;
  long v_84;
  long v_95;
  long v_92;
  long v_103;
  long v_100;
  long v_111;
  long v_108;
  long v_130;
  long v_127;
  long v_124;
  long v_121;
  long v_159;
  long v_154;
  long v_151;
  long v_146;
  long v_144;
  long v_141;
  long v_139;
  long v_136;
  Line_follower__st_4 v_171;
  long v_172;
  Line_follower__st_3 v_216;
  long v_227;
  long v_224;
  long v_220;
  long v_217;
  Line_follower__st_2 v_239;
  long v_242;
  long v_246;
  long v_243;
  long v_252;
  long v_249;
  long v_255;
  Line_follower__st_1 v_351;
  long v_352;
  Line_follower__st v_414;
  long v_447;
  long pnr_5;
  long parking_cycles_thresh_1;
  long inx_counter_1;
  long sen_2[5];
  long thresh_vals_1[5];
  long min_vals_1[5];
  long max_vals_1[5];
  long last_error_1;
  long pid_error_11;
  Line_follower__calPidError_mem calPidError;
  Line_follower__calPidError_mem calPidError_1;
  Line_follower__calPidError_mem calPidError_2;
  Line_follower__calPidError_mem calPidError_3;
  Line_follower__calPidError_mem calPidError_5;
  Line_follower__calPidError_mem calPidError_4;
} Line_follower__main_mem;

typedef struct Line_follower__main_out {
  long v_l;
  long v_r;
  long dir;
} Line_follower__main_out;

void Line_follower__main_reset(Line_follower__main_mem* self);

void Line_follower__main_step(long sen0, long sen1, long sen2, long sen3,
                              long sen4, long ir_value, long obs_left,
                              long obs_right, Line_follower__main_out* _out,
                              Line_follower__main_mem* self);

#endif // LINE_FOLLOWER_H
