/* --- Generated the 8/4/2025 at 16:58 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. mar. 8 9:40:4 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "line_follower_types.h"

Line_follower__st_5 Line_follower__st_5_of_string(char* s) {
  if ((strcmp(s, "St_5_WonB")==0)) {
    return Line_follower__St_5_WonB;
  };
  if ((strcmp(s, "St_5_Start")==0)) {
    return Line_follower__St_5_Start;
  };
  if ((strcmp(s, "St_5_Parking")==0)) {
    return Line_follower__St_5_Parking;
  };
  if ((strcmp(s, "St_5_ObstacleAvoid")==0)) {
    return Line_follower__St_5_ObstacleAvoid;
  };
  if ((strcmp(s, "St_5_Intersection")==0)) {
    return Line_follower__St_5_Intersection;
  };
  if ((strcmp(s, "St_5_Idle")==0)) {
    return Line_follower__St_5_Idle;
  };
  if ((strcmp(s, "St_5_Calibrate")==0)) {
    return Line_follower__St_5_Calibrate;
  };
  if ((strcmp(s, "St_5_BonW")==0)) {
    return Line_follower__St_5_BonW;
  };
}

char* string_of_Line_follower__st_5(Line_follower__st_5 x, char* buf) {
  switch (x) {
    case Line_follower__St_5_WonB:
      strcpy(buf, "St_5_WonB");
      break;
    case Line_follower__St_5_Start:
      strcpy(buf, "St_5_Start");
      break;
    case Line_follower__St_5_Parking:
      strcpy(buf, "St_5_Parking");
      break;
    case Line_follower__St_5_ObstacleAvoid:
      strcpy(buf, "St_5_ObstacleAvoid");
      break;
    case Line_follower__St_5_Intersection:
      strcpy(buf, "St_5_Intersection");
      break;
    case Line_follower__St_5_Idle:
      strcpy(buf, "St_5_Idle");
      break;
    case Line_follower__St_5_Calibrate:
      strcpy(buf, "St_5_Calibrate");
      break;
    case Line_follower__St_5_BonW:
      strcpy(buf, "St_5_BonW");
      break;
    default:
      break;
  };
  return buf;
}

Line_follower__st_4 Line_follower__st_4_of_string(char* s) {
  if ((strcmp(s, "St_4_Train")==0)) {
    return Line_follower__St_4_Train;
  };
  if ((strcmp(s, "St_4_Stop")==0)) {
    return Line_follower__St_4_Stop;
  };
  if ((strcmp(s, "St_4_ParkRight")==0)) {
    return Line_follower__St_4_ParkRight;
  };
  if ((strcmp(s, "St_4_ParkLeft")==0)) {
    return Line_follower__St_4_ParkLeft;
  };
  if ((strcmp(s, "St_4_GoReverse")==0)) {
    return Line_follower__St_4_GoReverse;
  };
  if ((strcmp(s, "St_4_GoBackR")==0)) {
    return Line_follower__St_4_GoBackR;
  };
  if ((strcmp(s, "St_4_GoBackL")==0)) {
    return Line_follower__St_4_GoBackL;
  };
  if ((strcmp(s, "St_4_FindSpace")==0)) {
    return Line_follower__St_4_FindSpace;
  };
}

char* string_of_Line_follower__st_4(Line_follower__st_4 x, char* buf) {
  switch (x) {
    case Line_follower__St_4_Train:
      strcpy(buf, "St_4_Train");
      break;
    case Line_follower__St_4_Stop:
      strcpy(buf, "St_4_Stop");
      break;
    case Line_follower__St_4_ParkRight:
      strcpy(buf, "St_4_ParkRight");
      break;
    case Line_follower__St_4_ParkLeft:
      strcpy(buf, "St_4_ParkLeft");
      break;
    case Line_follower__St_4_GoReverse:
      strcpy(buf, "St_4_GoReverse");
      break;
    case Line_follower__St_4_GoBackR:
      strcpy(buf, "St_4_GoBackR");
      break;
    case Line_follower__St_4_GoBackL:
      strcpy(buf, "St_4_GoBackL");
      break;
    case Line_follower__St_4_FindSpace:
      strcpy(buf, "St_4_FindSpace");
      break;
    default:
      break;
  };
  return buf;
}

Line_follower__st_3 Line_follower__st_3_of_string(char* s) {
  if ((strcmp(s, "St_3_Wait")==0)) {
    return Line_follower__St_3_Wait;
  };
  if ((strcmp(s, "St_3_SlightStraight")==0)) {
    return Line_follower__St_3_SlightStraight;
  };
  if ((strcmp(s, "St_3_SlightRight")==0)) {
    return Line_follower__St_3_SlightRight;
  };
  if ((strcmp(s, "St_3_SlightLeft")==0)) {
    return Line_follower__St_3_SlightLeft;
  };
  if ((strcmp(s, "St_3_FullRight")==0)) {
    return Line_follower__St_3_FullRight;
  };
  if ((strcmp(s, "St_3_ExitStart")==0)) {
    return Line_follower__St_3_ExitStart;
  };
  if ((strcmp(s, "St_3_ExitEnd2")==0)) {
    return Line_follower__St_3_ExitEnd2;
  };
  if ((strcmp(s, "St_3_ExitEnd1")==0)) {
    return Line_follower__St_3_ExitEnd1;
  };
}

char* string_of_Line_follower__st_3(Line_follower__st_3 x, char* buf) {
  switch (x) {
    case Line_follower__St_3_Wait:
      strcpy(buf, "St_3_Wait");
      break;
    case Line_follower__St_3_SlightStraight:
      strcpy(buf, "St_3_SlightStraight");
      break;
    case Line_follower__St_3_SlightRight:
      strcpy(buf, "St_3_SlightRight");
      break;
    case Line_follower__St_3_SlightLeft:
      strcpy(buf, "St_3_SlightLeft");
      break;
    case Line_follower__St_3_FullRight:
      strcpy(buf, "St_3_FullRight");
      break;
    case Line_follower__St_3_ExitStart:
      strcpy(buf, "St_3_ExitStart");
      break;
    case Line_follower__St_3_ExitEnd2:
      strcpy(buf, "St_3_ExitEnd2");
      break;
    case Line_follower__St_3_ExitEnd1:
      strcpy(buf, "St_3_ExitEnd1");
      break;
    default:
      break;
  };
  return buf;
}

Line_follower__st_2 Line_follower__st_2_of_string(char* s) {
  if ((strcmp(s, "St_2_St_low_1")==0)) {
    return Line_follower__St_2_St_low_1;
  };
  if ((strcmp(s, "St_2_St_high_1")==0)) {
    return Line_follower__St_2_St_high_1;
  };
  if ((strcmp(s, "St_2_St_high_0")==0)) {
    return Line_follower__St_2_St_high_0;
  };
}

char* string_of_Line_follower__st_2(Line_follower__st_2 x, char* buf) {
  switch (x) {
    case Line_follower__St_2_St_low_1:
      strcpy(buf, "St_2_St_low_1");
      break;
    case Line_follower__St_2_St_high_1:
      strcpy(buf, "St_2_St_high_1");
      break;
    case Line_follower__St_2_St_high_0:
      strcpy(buf, "St_2_St_high_0");
      break;
    default:
      break;
  };
  return buf;
}

Line_follower__st_1 Line_follower__st_1_of_string(char* s) {
  if ((strcmp(s, "St_1_ExitStraight")==0)) {
    return Line_follower__St_1_ExitStraight;
  };
  if ((strcmp(s, "St_1_ExitRight")==0)) {
    return Line_follower__St_1_ExitRight;
  };
  if ((strcmp(s, "St_1_ExitLeft")==0)) {
    return Line_follower__St_1_ExitLeft;
  };
  if ((strcmp(s, "St_1_Entry")==0)) {
    return Line_follower__St_1_Entry;
  };
  if ((strcmp(s, "St_1_Counter")==0)) {
    return Line_follower__St_1_Counter;
  };
}

char* string_of_Line_follower__st_1(Line_follower__st_1 x, char* buf) {
  switch (x) {
    case Line_follower__St_1_ExitStraight:
      strcpy(buf, "St_1_ExitStraight");
      break;
    case Line_follower__St_1_ExitRight:
      strcpy(buf, "St_1_ExitRight");
      break;
    case Line_follower__St_1_ExitLeft:
      strcpy(buf, "St_1_ExitLeft");
      break;
    case Line_follower__St_1_Entry:
      strcpy(buf, "St_1_Entry");
      break;
    case Line_follower__St_1_Counter:
      strcpy(buf, "St_1_Counter");
      break;
    default:
      break;
  };
  return buf;
}

Line_follower__st Line_follower__st_of_string(char* s) {
  if ((strcmp(s, "St_Sharp")==0)) {
    return Line_follower__St_Sharp;
  };
  if ((strcmp(s, "St_PID")==0)) {
    return Line_follower__St_PID;
  };
}

char* string_of_Line_follower__st(Line_follower__st x, char* buf) {
  switch (x) {
    case Line_follower__St_Sharp:
      strcpy(buf, "St_Sharp");
      break;
    case Line_follower__St_PID:
      strcpy(buf, "St_PID");
      break;
    default:
      break;
  };
  return buf;
}

