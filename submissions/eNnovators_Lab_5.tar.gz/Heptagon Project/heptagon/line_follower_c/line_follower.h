/* --- Generated the 8/4/2025 at 16:58 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. mar. 8 9:40:4 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#ifndef LINE_FOLLOWER_H
#define LINE_FOLLOWER_H

#include "line_follower_types.h"
typedef struct Line_follower__calPidError_mem {
  int v_10;
  int v_9;
  int v_6;
  int v_5;
  int v_1;
  int v;
} Line_follower__calPidError_mem;

typedef struct Line_follower__calPidError_out {
  int pid_error;
} Line_follower__calPidError_out;

void Line_follower__calPidError_reset(Line_follower__calPidError_mem* self);

void Line_follower__calPidError_step(int value, int scale_down,
                                     Line_follower__calPidError_out* _out,
                                     Line_follower__calPidError_mem* self);

typedef struct Line_follower__weightedSum_out {
  int weighted_sum;
} Line_follower__weightedSum_out;

void Line_follower__weightedSum_step(int sen_value, int sen_weight,
                                     int prev_sum,
                                     Line_follower__weightedSum_out* _out);

typedef struct Line_follower__senWeightedAvg_out {
  int sensor_avg;
} Line_follower__senWeightedAvg_out;

void Line_follower__senWeightedAvg_step(int sen[5],
                                        Line_follower__senWeightedAvg_out* _out);

typedef struct Line_follower__safe_motor_update_out {
  int new_speed;
} Line_follower__safe_motor_update_out;

void Line_follower__safe_motor_update_step(int cur_speed, int change,
                                           Line_follower__safe_motor_update_out* _out);

typedef struct Line_follower__normalize_value_out {
  int norm_val;
} Line_follower__normalize_value_out;

void Line_follower__normalize_value_step(int min_val, int max_val, int value,
                                         Line_follower__normalize_value_out* _out);

typedef struct Line_follower__updateMins_out {
  int new_min;
} Line_follower__updateMins_out;

void Line_follower__updateMins_step(int cur_val, int cur_thresh, int cur_min,
                                    Line_follower__updateMins_out* _out);

typedef struct Line_follower__updateMaxs_out {
  int new_max;
} Line_follower__updateMaxs_out;

void Line_follower__updateMaxs_step(int cur_val, int cur_thresh, int cur_max,
                                    Line_follower__updateMaxs_out* _out);

typedef struct Line_follower__max_out {
  int val_m;
} Line_follower__max_out;

void Line_follower__max_step(int val_a, int val_b,
                             Line_follower__max_out* _out);

typedef struct Line_follower__abs_out {
  int out;
} Line_follower__abs_out;

void Line_follower__abs_step(int input, Line_follower__abs_out* _out);

typedef struct Line_follower__pid_err_to_speeds_park_out {
  int v_l;
  int v_r;
  int dir;
} Line_follower__pid_err_to_speeds_park_out;

void Line_follower__pid_err_to_speeds_park_step(int pid_error,
                                                Line_follower__pid_err_to_speeds_park_out* _out);

typedef struct Line_follower__main_mem {
  Line_follower__st_5 ck;
  int v_79;
  int v_76;
  int v_87;
  int v_84;
  int v_95;
  int v_92;
  int v_103;
  int v_100;
  int v_111;
  int v_108;
  int v_130;
  int v_127;
  int v_124;
  int v_121;
  int v_159;
  int v_154;
  int v_151;
  int v_146;
  int v_144;
  int v_141;
  int v_139;
  int v_136;
  Line_follower__st_4 v_171;
  int v_172;
  Line_follower__st_3 v_216;
  int v_227;
  int v_224;
  int v_220;
  int v_217;
  Line_follower__st_2 v_239;
  int v_242;
  int v_246;
  int v_243;
  int v_252;
  int v_249;
  int v_255;
  Line_follower__st_1 v_351;
  int v_352;
  Line_follower__st v_414;
  int v_447;
  int pnr_5;
  int parking_cycles_thresh_1;
  int inx_counter_1;
  int sen_2[5];
  int thresh_vals_1[5];
  int min_vals_1[5];
  int max_vals_1[5];
  int last_error_1;
  int pid_error_11;
  Line_follower__calPidError_mem calPidError;
  Line_follower__calPidError_mem calPidError_1;
  Line_follower__calPidError_mem calPidError_2;
  Line_follower__calPidError_mem calPidError_3;
  Line_follower__calPidError_mem calPidError_5;
  Line_follower__calPidError_mem calPidError_4;
} Line_follower__main_mem;

typedef struct Line_follower__main_out {
  int v_l;
  int v_r;
  int dir;
} Line_follower__main_out;

void Line_follower__main_reset(Line_follower__main_mem* self);

void Line_follower__main_step(int sen0, int sen1, int sen2, int sen3,
                              int sen4, int ir_value, int obs_left,
                              int obs_right, Line_follower__main_out* _out,
                              Line_follower__main_mem* self);

#endif // LINE_FOLLOWER_H
