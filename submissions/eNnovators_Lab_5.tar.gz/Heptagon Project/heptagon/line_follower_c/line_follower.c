/* --- Generated the 8/4/2025 at 16:58 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. mar. 8 9:40:4 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "line_follower.h"

void Line_follower__calPidError_reset(Line_follower__calPidError_mem* self) {
  self->v_9 = true;
  self->v_5 = true;
  self->v = true;
}

void Line_follower__calPidError_step(int value, int scale_down,
                                     Line_follower__calPidError_out* _out,
                                     Line_follower__calPidError_mem* self) {
  
  int v_16;
  int v_15;
  int v_14;
  int v_13;
  int v_12;
  int v_11;
  int v_8;
  int v_7;
  int v_4;
  int v_3;
  int v_2;
  int p;
  int i;
  int d;
  if (self->v_9) {
    v_11 = 0;
  } else {
    v_11 = self->v_10;
  };
  d = (value-v_11);
  v_15 = (Line_follower__kd*d);
  v_7 = (self->v_6+value);
  if (self->v_5) {
    v_8 = 0;
  } else {
    v_8 = v_7;
  };
  v_2 = (self->v_1+value);
  if (self->v) {
    v_3 = 0;
  } else {
    v_3 = v_2;
  };
  v_4 = (v_3<=Line_follower__max_i);
  if (v_4) {
    i = v_8;
  } else {
    i = 200000000;
  };
  v_13 = (Line_follower__ki*i);
  p = value;
  v_12 = (Line_follower__kp*p);
  v_14 = (v_12+v_13);
  v_16 = (v_14+v_15);
  _out->pid_error = (v_16/scale_down);
  self->v_10 = value;
  self->v_9 = false;
  self->v_6 = i;
  self->v_5 = false;
  self->v_1 = i;
  self->v = false;;
}

void Line_follower__weightedSum_step(int sen_value, int sen_weight,
                                     int prev_sum,
                                     Line_follower__weightedSum_out* _out) {
  
  int v;
  v = (sen_value*sen_weight);
  _out->weighted_sum = (prev_sum+v);;
}

void Line_follower__senWeightedAvg_step(int sen[5],
                                        Line_follower__senWeightedAvg_out* _out) {
  Line_follower__weightedSum_out Line_follower__weightedSum_out_st;
  
  int v_19;
  int v_18;
  int v_17;
  int v;
  int aritmetic_sum;
  v_19 = 0;
  {
    int i_9;
    for (i_9 = 0; i_9 < 5; ++i_9) {
      Line_follower__weightedSum_step(sen[i_9],
                                      Line_follower__sensor_weights[i_9],
                                      v_19,
                                      &Line_follower__weightedSum_out_st);
      v_19 = Line_follower__weightedSum_out_st.weighted_sum;
    }
  };
  v_17 = sen[2];
  v = 0;
  {
    int i;
    for (i = 0; i < 5; ++i) {
      v = (sen[i]+v);
    }
  };
  aritmetic_sum = (v-v_17);
  v_18 = (aritmetic_sum==0);
  if (v_18) {
    _out->sensor_avg = 0;
  } else {
    _out->sensor_avg = v_19;
  };;
}

void Line_follower__safe_motor_update_step(int cur_speed, int change,
                                           Line_follower__safe_motor_update_out* _out) {
  
  int v_24;
  int v_23;
  int v_22;
  int v_21;
  int v_20;
  int v;
  v_23 = (cur_speed+change);
  v_21 = (cur_speed+change);
  v_22 = (v_21<0);
  if (v_22) {
    v_24 = 0;
  } else {
    v_24 = v_23;
  };
  v = (cur_speed+change);
  v_20 = (v>100);
  if (v_20) {
    _out->new_speed = 100;
  } else {
    _out->new_speed = v_24;
  };;
}

void Line_follower__normalize_value_step(int min_val, int max_val, int value,
                                         Line_follower__normalize_value_out* _out) {
  
  int v_29;
  int v_28;
  int v_27;
  int v_26;
  int v_25;
  int v;
  int safe_val;
  v_29 = (max_val-min_val);
  v_25 = (value<=min_val);
  if (v_25) {
    v_26 = min_val;
  } else {
    v_26 = value;
  };
  v = (value>=max_val);
  if (v) {
    safe_val = max_val;
  } else {
    safe_val = v_26;
  };
  v_27 = (safe_val-min_val);
  v_28 = (v_27*1000);
  _out->norm_val = (v_28/v_29);;
}

void Line_follower__updateMins_step(int cur_val, int cur_thresh, int cur_min,
                                    Line_follower__updateMins_out* _out) {
  
  int v_31;
  int v_30;
  int v;
  v_30 = (cur_val<cur_thresh);
  v = (cur_val>cur_min);
  v_31 = (v&&v_30);
  if (v_31) {
    _out->new_min = cur_val;
  } else {
    _out->new_min = cur_min;
  };;
}

void Line_follower__updateMaxs_step(int cur_val, int cur_thresh, int cur_max,
                                    Line_follower__updateMaxs_out* _out) {
  
  int v_33;
  int v_32;
  int v;
  v_32 = (cur_val>cur_thresh);
  v = (cur_val<cur_max);
  v_33 = (v&&v_32);
  if (v_33) {
    _out->new_max = cur_val;
  } else {
    _out->new_max = cur_max;
  };;
}

void Line_follower__max_step(int val_a, int val_b,
                             Line_follower__max_out* _out) {
  
  int v;
  v = (val_a>=val_b);
  if (v) {
    _out->val_m = val_a;
  } else {
    _out->val_m = val_b;
  };;
}

void Line_follower__abs_step(int input, Line_follower__abs_out* _out) {
  
  int v_34;
  int v;
  v_34 = (-1*input);
  v = (input>=0);
  if (v) {
    _out->out = input;
  } else {
    _out->out = v_34;
  };;
}

void Line_follower__pid_err_to_speeds_park_step(int pid_error,
                                                Line_follower__pid_err_to_speeds_park_out* _out) {
  Line_follower__abs_out Line_follower__abs_out_st;
  Line_follower__safe_motor_update_out Line_follower__safe_motor_update_out_st;
  
  int v_42;
  int v_41;
  int v_40;
  int v_39;
  int v_38;
  int v_37;
  int v_36;
  int v_35;
  int v;
  int sharp_thresh;
  _out->dir = 1;
  v_40 = (-1*pid_error);
  v_41 = (v_40/2);
  Line_follower__safe_motor_update_step(Line_follower__safe_speed_park, v_41,
                                        &Line_follower__safe_motor_update_out_st);
  v_42 = Line_follower__safe_motor_update_out_st.new_speed;
  Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
  v_38 = Line_follower__abs_out_st.out;
  v_36 = (pid_error/2);
  Line_follower__safe_motor_update_step(Line_follower__safe_speed_park, v_36,
                                        &Line_follower__safe_motor_update_out_st);
  v_37 = Line_follower__safe_motor_update_out_st.new_speed;
  Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
  v = Line_follower__abs_out_st.out;
  sharp_thresh = 40;
  v_39 = (v_38<=sharp_thresh);
  if (v_39) {
    _out->v_r = v_42;
  } else {
    _out->v_r = 100;
  };
  v_35 = (v<=sharp_thresh);
  if (v_35) {
    _out->v_l = v_37;
  } else {
    _out->v_l = 100;
  };;
}

void Line_follower__main_reset(Line_follower__main_mem* self) {
  {
    int i_8;
    for (i_8 = 0; i_8 < 5; ++i_8) {
    }
  };
  Line_follower__calPidError_reset(&self->calPidError_4);
  Line_follower__calPidError_reset(&self->calPidError_5);
  Line_follower__calPidError_reset(&self->calPidError_3);
  Line_follower__calPidError_reset(&self->calPidError_2);
  Line_follower__calPidError_reset(&self->calPidError_1);
  Line_follower__calPidError_reset(&self->calPidError);
  {
    int i_7;
    for (i_7 = 0; i_7 < 5; ++i_7) {
    }
  };
  {
    int i_6;
    for (i_6 = 0; i_6 < 5; ++i_6) {
    }
  };
  self->v_447 = false;
  self->v_414 = Line_follower__St_PID;
  self->v_352 = false;
  self->v_351 = Line_follower__St_1_Counter;
  self->v_255 = false;
  self->v_216 = Line_follower__St_3_Wait;
  self->v_172 = false;
  self->v_171 = Line_follower__St_4_Train;
  self->parking_cycles_thresh_1 = 0;
  self->inx_counter_1 = 0;
  self->sen_2[0] = 0;
  self->sen_2[1] = 0;
  self->sen_2[2] = 0;
  self->sen_2[3] = 0;
  self->sen_2[4] = 0;
  self->thresh_vals_1[0] = 500;
  self->thresh_vals_1[1] = 500;
  self->thresh_vals_1[2] = 500;
  self->thresh_vals_1[3] = 700;
  self->thresh_vals_1[4] = 500;
  self->min_vals_1[0] = 0;
  self->min_vals_1[1] = 0;
  self->min_vals_1[2] = 0;
  self->min_vals_1[3] = 0;
  self->min_vals_1[4] = 0;
  self->max_vals_1[0] = 1023;
  self->max_vals_1[1] = 1023;
  self->max_vals_1[2] = 1023;
  self->max_vals_1[3] = 1023;
  self->max_vals_1[4] = 1023;
  self->last_error_1 = 0;
  self->pid_error_11 = 0;
  self->pnr_5 = false;
  self->ck = Line_follower__St_5_Calibrate;
  self->v_249 = true;
  self->v_243 = true;
  self->v_242 = false;
  self->v_239 = Line_follower__St_2_St_high_0;
  self->v_224 = true;
  self->v_217 = true;
  self->v_154 = true;
  self->v_146 = true;
  self->v_141 = true;
  self->v_136 = true;
  self->v_127 = true;
  self->v_121 = true;
  self->v_108 = true;
  self->v_100 = true;
  self->v_92 = true;
  self->v_84 = true;
  self->v_76 = true;
}

void Line_follower__main_step(int sen0, int sen1, int sen2, int sen3,
                              int sen4, int ir_value, int obs_left,
                              int obs_right, Line_follower__main_out* _out,
                              Line_follower__main_mem* self) {
  Line_follower__normalize_value_out Line_follower__normalize_value_out_st;
  Line_follower__updateMaxs_out Line_follower__updateMaxs_out_st;
  Line_follower__pid_err_to_speeds_park_out Line_follower__pid_err_to_speeds_park_out_st;
  Line_follower__safe_motor_update_out Line_follower__safe_motor_update_out_st;
  Line_follower__abs_out Line_follower__abs_out_st;
  Line_follower__calPidError_out Line_follower__calPidError_out_st;
  Line_follower__max_out Line_follower__max_out_st;
  Line_follower__updateMins_out Line_follower__updateMins_out_st;
  Line_follower__senWeightedAvg_out Line_follower__senWeightedAvg_out_st;
  
  int v_56;
  int v_55;
  int v_58;
  int v_57;
  int v_72;
  int v_71;
  int v_70;
  int v_69;
  int v_68;
  int v_67;
  int v_66;
  int v_65;
  int v_64;
  int v_63;
  int v_62;
  int v_61;
  int v_60;
  int v_59;
  int r_5_St_5_Parking;
  Line_follower__st_5 s_5_St_5_Parking;
  int r_5_St_5_ObstacleAvoid;
  Line_follower__st_5 s_5_St_5_ObstacleAvoid;
  int r_5_St_5_Intersection;
  Line_follower__st_5 s_5_St_5_Intersection;
  int r_5_St_5_BonW;
  Line_follower__st_5 s_5_St_5_BonW;
  int r_5_St_5_WonB;
  Line_follower__st_5 s_5_St_5_WonB;
  int r_5_St_5_Start;
  Line_follower__st_5 s_5_St_5_Start;
  int r_5_St_5_Idle;
  Line_follower__st_5 s_5_St_5_Idle;
  int r_5_St_5_Calibrate;
  Line_follower__st_5 s_5_St_5_Calibrate;
  int v_80;
  int v_78;
  int v_77;
  int v_75;
  int v_74;
  int v_73;
  int ncycles_6;
  int v_88;
  int v_86;
  int v_85;
  int v_83;
  int v_82;
  int v_81;
  int ncycles_5;
  int v_96;
  int v_94;
  int v_93;
  int v_91;
  int v_90;
  int v_89;
  int ncycles_4;
  int v_104;
  int v_102;
  int v_101;
  int v_99;
  int v_98;
  int v_97;
  int r_6;
  int locdir_1;
  int ncycles_3;
  int v_112;
  int v_110;
  int v_109;
  int v_107;
  int v_106;
  int v_105;
  int r_7;
  int locdir;
  int ncycles_2;
  int v_132;
  int v_131;
  int v_129;
  int v_128;
  int v_126;
  int v_125;
  int v_123;
  int v_122;
  int v_120;
  Line_follower__st_4 v_119;
  int v_118;
  int v_117;
  int v_116;
  int v_115;
  int v_114;
  int v_113;
  int r_8;
  int cycles_left_1;
  int cycles_right_1;
  int v_170;
  int v_169;
  int v_168;
  int v_167;
  int v_166;
  int v_165;
  int v_164;
  int v_163;
  int v_162;
  int v_161;
  int v_160;
  int v_158;
  int v_157;
  int v_156;
  int v_155;
  int v_153;
  int v_152;
  int v_150;
  int v_149;
  int v_148;
  int v_147;
  int v_145;
  int v_143;
  int v_142;
  int v_140;
  int v_138;
  int v_137;
  int v_135;
  int v_134;
  int v_133;
  int r_9;
  int cycles_left;
  int cycles_right;
  int left_was_high;
  int right_was_high;
  int nr_4_St_4_Stop;
  Line_follower__st_4 ns_4_St_4_Stop;
  int parking_cycles_thresh_St_5_Parking_St_4_Stop;
  int pid_error_St_5_Parking_St_4_Stop;
  int dir_St_5_Parking_St_4_Stop;
  int v_r_St_5_Parking_St_4_Stop;
  int v_l_St_5_Parking_St_4_Stop;
  int nr_4_St_4_GoReverse;
  Line_follower__st_4 ns_4_St_4_GoReverse;
  int parking_cycles_thresh_St_5_Parking_St_4_GoReverse;
  int pid_error_St_5_Parking_St_4_GoReverse;
  int dir_St_5_Parking_St_4_GoReverse;
  int v_r_St_5_Parking_St_4_GoReverse;
  int v_l_St_5_Parking_St_4_GoReverse;
  int nr_4_St_4_ParkRight;
  Line_follower__st_4 ns_4_St_4_ParkRight;
  int parking_cycles_thresh_St_5_Parking_St_4_ParkRight;
  int pid_error_St_5_Parking_St_4_ParkRight;
  int dir_St_5_Parking_St_4_ParkRight;
  int v_r_St_5_Parking_St_4_ParkRight;
  int v_l_St_5_Parking_St_4_ParkRight;
  int nr_4_St_4_ParkLeft;
  Line_follower__st_4 ns_4_St_4_ParkLeft;
  int parking_cycles_thresh_St_5_Parking_St_4_ParkLeft;
  int pid_error_St_5_Parking_St_4_ParkLeft;
  int dir_St_5_Parking_St_4_ParkLeft;
  int v_r_St_5_Parking_St_4_ParkLeft;
  int v_l_St_5_Parking_St_4_ParkLeft;
  int nr_4_St_4_GoBackR;
  Line_follower__st_4 ns_4_St_4_GoBackR;
  int parking_cycles_thresh_St_5_Parking_St_4_GoBackR;
  int pid_error_St_5_Parking_St_4_GoBackR;
  int dir_St_5_Parking_St_4_GoBackR;
  int v_r_St_5_Parking_St_4_GoBackR;
  int v_l_St_5_Parking_St_4_GoBackR;
  int nr_4_St_4_GoBackL;
  Line_follower__st_4 ns_4_St_4_GoBackL;
  int parking_cycles_thresh_St_5_Parking_St_4_GoBackL;
  int pid_error_St_5_Parking_St_4_GoBackL;
  int dir_St_5_Parking_St_4_GoBackL;
  int v_r_St_5_Parking_St_4_GoBackL;
  int v_l_St_5_Parking_St_4_GoBackL;
  int nr_4_St_4_FindSpace;
  Line_follower__st_4 ns_4_St_4_FindSpace;
  int parking_cycles_thresh_St_5_Parking_St_4_FindSpace;
  int pid_error_St_5_Parking_St_4_FindSpace;
  int dir_St_5_Parking_St_4_FindSpace;
  int v_r_St_5_Parking_St_4_FindSpace;
  int v_l_St_5_Parking_St_4_FindSpace;
  int nr_4_St_4_Train;
  Line_follower__st_4 ns_4_St_4_Train;
  int parking_cycles_thresh_St_5_Parking_St_4_Train;
  int pid_error_St_5_Parking_St_4_Train;
  int dir_St_5_Parking_St_4_Train;
  int v_r_St_5_Parking_St_4_Train;
  int v_l_St_5_Parking_St_4_Train;
  Line_follower__st_4 ck_9;
  Line_follower__st_4 ns_4;
  int r_4;
  int nr_4;
  int pnr_4;
  int v_200;
  Line_follower__st_3 v_199;
  int v_198;
  int v_197;
  int v_196;
  int v_195;
  int v_194;
  int v_193;
  int v_192;
  int v_191;
  int v_190;
  int v_189;
  int v_188;
  int v_187;
  int v_186;
  int v_207;
  Line_follower__st_3 v_206;
  int v_205;
  Line_follower__st_3 v_204;
  int v_203;
  int v_202;
  int v_201;
  int v_215;
  Line_follower__st_3 v_214;
  int v_213;
  Line_follower__st_3 v_212;
  int v_211;
  int v_210;
  int v_209;
  int v_208;
  int r_3_St_3_ExitEnd2;
  Line_follower__st_3 s_3_St_3_ExitEnd2;
  int r_3_St_3_ExitEnd1;
  Line_follower__st_3 s_3_St_3_ExitEnd1;
  int r_3_St_3_ExitStart;
  Line_follower__st_3 s_3_St_3_ExitStart;
  int r_3_St_3_SlightLeft;
  Line_follower__st_3 s_3_St_3_SlightLeft;
  int r_3_St_3_SlightRight;
  Line_follower__st_3 s_3_St_3_SlightRight;
  int r_3_St_3_SlightStraight;
  Line_follower__st_3 s_3_St_3_SlightStraight;
  int r_3_St_3_FullRight;
  Line_follower__st_3 s_3_St_3_FullRight;
  int r_3_St_3_Wait;
  Line_follower__st_3 s_3_St_3_Wait;
  Line_follower__st_3 ck_5;
  int v_233;
  int v_232;
  int v_231;
  int v_230;
  int v_229;
  int v_228;
  int v_226;
  int v_225;
  int v_223;
  int v_222;
  int v_221;
  int v_219;
  int v_218;
  int sen_1_low1;
  int sen_1_high1;
  int v_235;
  int v_234;
  int v_237;
  int v_236;
  int v_238;
  int r_2_St_2_St_high_1;
  Line_follower__st_2 s_2_St_2_St_high_1;
  int r_2_St_2_St_low_1;
  Line_follower__st_2 s_2_St_2_St_low_1;
  int r_2_St_2_St_high_0;
  Line_follower__st_2 s_2_St_2_St_high_0;
  Line_follower__st_2 ck_7;
  int v_240;
  int nr_2_St_2_St_high_1;
  Line_follower__st_2 ns_2_St_2_St_high_1;
  int complete_1_St_3_ExitEnd1_St_2_St_high_1;
  int nr_2_St_2_St_low_1;
  Line_follower__st_2 ns_2_St_2_St_low_1;
  int complete_1_St_3_ExitEnd1_St_2_St_low_1;
  int nr_2_St_2_St_high_0;
  Line_follower__st_2 ns_2_St_2_St_high_0;
  int complete_1_St_3_ExitEnd1_St_2_St_high_0;
  Line_follower__st_2 ck_8;
  int v_241;
  Line_follower__st_2 s_2;
  Line_follower__st_2 ns_2;
  int r_2;
  int nr_2;
  int pnr_2;
  int v_247;
  int v_245;
  int v_244;
  int ncycles_1;
  int v_254;
  int v_253;
  int v_251;
  int v_250;
  int v_248;
  int ncycles;
  int nr_3_St_3_ExitEnd2;
  Line_follower__st_3 ns_3_St_3_ExitEnd2;
  int complete_1_St_3_ExitEnd2;
  int inx_counter_St_5_ObstacleAvoid_St_3_ExitEnd2;
  int dir_St_5_ObstacleAvoid_St_3_ExitEnd2;
  int v_r_St_5_ObstacleAvoid_St_3_ExitEnd2;
  int v_l_St_5_ObstacleAvoid_St_3_ExitEnd2;
  int nr_3_St_3_ExitEnd1;
  Line_follower__st_3 ns_3_St_3_ExitEnd1;
  int complete_1_St_3_ExitEnd1;
  int inx_counter_St_5_ObstacleAvoid_St_3_ExitEnd1;
  int dir_St_5_ObstacleAvoid_St_3_ExitEnd1;
  int v_r_St_5_ObstacleAvoid_St_3_ExitEnd1;
  int v_l_St_5_ObstacleAvoid_St_3_ExitEnd1;
  int nr_3_St_3_ExitStart;
  Line_follower__st_3 ns_3_St_3_ExitStart;
  int complete_1_St_3_ExitStart;
  int inx_counter_St_5_ObstacleAvoid_St_3_ExitStart;
  int dir_St_5_ObstacleAvoid_St_3_ExitStart;
  int v_r_St_5_ObstacleAvoid_St_3_ExitStart;
  int v_l_St_5_ObstacleAvoid_St_3_ExitStart;
  int nr_3_St_3_SlightLeft;
  Line_follower__st_3 ns_3_St_3_SlightLeft;
  int complete_1_St_3_SlightLeft;
  int inx_counter_St_5_ObstacleAvoid_St_3_SlightLeft;
  int dir_St_5_ObstacleAvoid_St_3_SlightLeft;
  int v_r_St_5_ObstacleAvoid_St_3_SlightLeft;
  int v_l_St_5_ObstacleAvoid_St_3_SlightLeft;
  int nr_3_St_3_SlightRight;
  Line_follower__st_3 ns_3_St_3_SlightRight;
  int complete_1_St_3_SlightRight;
  int inx_counter_St_5_ObstacleAvoid_St_3_SlightRight;
  int dir_St_5_ObstacleAvoid_St_3_SlightRight;
  int v_r_St_5_ObstacleAvoid_St_3_SlightRight;
  int v_l_St_5_ObstacleAvoid_St_3_SlightRight;
  int nr_3_St_3_SlightStraight;
  Line_follower__st_3 ns_3_St_3_SlightStraight;
  int complete_1_St_3_SlightStraight;
  int inx_counter_St_5_ObstacleAvoid_St_3_SlightStraight;
  int dir_St_5_ObstacleAvoid_St_3_SlightStraight;
  int v_r_St_5_ObstacleAvoid_St_3_SlightStraight;
  int v_l_St_5_ObstacleAvoid_St_3_SlightStraight;
  int nr_3_St_3_FullRight;
  Line_follower__st_3 ns_3_St_3_FullRight;
  int complete_1_St_3_FullRight;
  int inx_counter_St_5_ObstacleAvoid_St_3_FullRight;
  int dir_St_5_ObstacleAvoid_St_3_FullRight;
  int v_r_St_5_ObstacleAvoid_St_3_FullRight;
  int v_l_St_5_ObstacleAvoid_St_3_FullRight;
  int nr_3_St_3_Wait;
  Line_follower__st_3 ns_3_St_3_Wait;
  int complete_1_St_3_Wait;
  int inx_counter_St_5_ObstacleAvoid_St_3_Wait;
  int dir_St_5_ObstacleAvoid_St_3_Wait;
  int v_r_St_5_ObstacleAvoid_St_3_Wait;
  int v_l_St_5_ObstacleAvoid_St_3_Wait;
  Line_follower__st_3 ck_6;
  int v_185;
  int v_184;
  int v_183;
  int v_182;
  int v_181;
  int v_180;
  int v_179;
  int v_178;
  int v_177;
  int v_176;
  int v_175;
  int v_174;
  int v_173;
  Line_follower__st_3 s_3;
  Line_follower__st_3 ns_3;
  int r_3;
  int nr_3;
  int pnr_3;
  int complete_1;
  int all_very_high;
  int v_263;
  int v_348;
  int v_347;
  int v_346;
  int v_345;
  int v_344;
  int v_343;
  int v_342;
  int v_341;
  int v_340;
  int v_339;
  int v_338;
  int v_337;
  int v_336;
  int v_335;
  int v_334;
  int v_333;
  int v_332;
  int v_331;
  int v_330;
  int v_329;
  int v_328;
  int v_327;
  int v_326;
  int v_325;
  int v_324;
  int v_323;
  int v_322;
  int v_321;
  int v_320;
  int v_319;
  int v_318;
  int v_317;
  int v_316;
  int v_315;
  int v_314;
  int v_313;
  int v_312;
  int v_311;
  int v_310;
  int v_309;
  int v_308;
  int v_307;
  int v_306;
  int v_305;
  int v_304;
  int v_303;
  int v_302;
  int v_301;
  int v_300;
  int v_299;
  int v_298;
  int v_297;
  int v_296;
  int v_295;
  int v_294;
  int v_293;
  int v_292;
  int v_291;
  int v_290;
  int v_289;
  int v_288;
  int v_287;
  int v_286;
  int v_285;
  int v_284;
  int v_283;
  int v_282;
  int v_281;
  int v_280;
  int v_279;
  int v_278;
  int v_277;
  int v_276;
  int v_275;
  Line_follower__st_1 v_274;
  int v_273;
  Line_follower__st_1 v_272;
  int v_271;
  int v_270;
  int v_269;
  int v_268;
  int v_267;
  int v_266;
  int v_265;
  int v_264;
  int only_one_low;
  int v_350;
  int v_349;
  int nr_1_St_1_ExitStraight;
  Line_follower__st_1 ns_1_St_1_ExitStraight;
  int complete_St_1_ExitStraight;
  int inx_counter_St_5_Intersection_St_1_ExitStraight;
  int dir_St_5_Intersection_St_1_ExitStraight;
  int v_r_St_5_Intersection_St_1_ExitStraight;
  int v_l_St_5_Intersection_St_1_ExitStraight;
  int nr_1_St_1_ExitLeft;
  Line_follower__st_1 ns_1_St_1_ExitLeft;
  int complete_St_1_ExitLeft;
  int inx_counter_St_5_Intersection_St_1_ExitLeft;
  int dir_St_5_Intersection_St_1_ExitLeft;
  int v_r_St_5_Intersection_St_1_ExitLeft;
  int v_l_St_5_Intersection_St_1_ExitLeft;
  int nr_1_St_1_ExitRight;
  Line_follower__st_1 ns_1_St_1_ExitRight;
  int complete_St_1_ExitRight;
  int inx_counter_St_5_Intersection_St_1_ExitRight;
  int dir_St_5_Intersection_St_1_ExitRight;
  int v_r_St_5_Intersection_St_1_ExitRight;
  int v_l_St_5_Intersection_St_1_ExitRight;
  int nr_1_St_1_Entry;
  Line_follower__st_1 ns_1_St_1_Entry;
  int complete_St_1_Entry;
  int inx_counter_St_5_Intersection_St_1_Entry;
  int dir_St_5_Intersection_St_1_Entry;
  int v_r_St_5_Intersection_St_1_Entry;
  int v_l_St_5_Intersection_St_1_Entry;
  int nr_1_St_1_Counter;
  Line_follower__st_1 ns_1_St_1_Counter;
  int complete_St_1_Counter;
  int inx_counter_St_5_Intersection_St_1_Counter;
  int dir_St_5_Intersection_St_1_Counter;
  int v_r_St_5_Intersection_St_1_Counter;
  int v_l_St_5_Intersection_St_1_Counter;
  Line_follower__st_1 ck_4;
  int v_262;
  Line_follower__st_5 v_261;
  int v_260;
  int v_259;
  int v_258;
  int v_257;
  int v_256;
  Line_follower__st_1 ns_1;
  int r_1;
  int nr_1;
  int pnr_1;
  int complete;
  int v_399;
  int v_398;
  int v_397;
  int v_396;
  int v_395;
  int v_394;
  int v_393;
  int v_392;
  int v_391;
  int v_390;
  int v_389;
  int v_388;
  int v_387;
  int v_386;
  int v_385;
  int v_384;
  int v_383;
  int v_382;
  int v_381;
  int v_380;
  int v_379;
  int v_378;
  int v_377;
  int v_376;
  int v_375;
  int v_374;
  int v_373;
  int v_372;
  int v_371;
  int v_370;
  int v_369;
  int v_368;
  int v_367;
  int v_366;
  int v_365;
  int v_364;
  int v_363;
  int v_362;
  int v_361;
  int v_360;
  int v_359;
  int v_358;
  int v_357;
  int v_356;
  int v_355;
  int v_354;
  int v_353;
  int r_10;
  int inx_condition;
  int sharp_thresh_1;
  int v_413;
  int v_412;
  int v_411;
  int v_410;
  int v_409;
  int v_408;
  int v_407;
  int v_406;
  int v_405;
  int v_404;
  int v_403;
  int v_402;
  int v_401;
  int v_400;
  int r_St_Sharp;
  Line_follower__st s_St_Sharp;
  int r_St_PID;
  Line_follower__st s_St_PID;
  Line_follower__st ck_2;
  int v_431;
  int v_430;
  int v_429;
  int v_428;
  int v_427;
  int v_426;
  int v_425;
  int v_424;
  int v_423;
  int v_422;
  int v_421;
  int v_420;
  int v_419;
  int v_418;
  int v_417;
  int v_416;
  int v_415;
  int v_446;
  int v_445;
  int v_444;
  int v_443;
  int v_442;
  int v_441;
  int v_440;
  int v_439;
  int v_438;
  int v_437;
  int v_436;
  int v_435;
  int v_434;
  int v_433;
  int v_432;
  int r_11;
  int nr_St_Sharp;
  Line_follower__st ns_St_Sharp;
  int last_error_St_5_WonB_St_Sharp;
  int pid_error_St_5_WonB_St_Sharp;
  int dir_St_5_WonB_St_Sharp;
  int v_r_St_5_WonB_St_Sharp;
  int v_l_St_5_WonB_St_Sharp;
  int nr_St_PID;
  Line_follower__st ns_St_PID;
  int last_error_St_5_WonB_St_PID;
  int pid_error_St_5_WonB_St_PID;
  int dir_St_5_WonB_St_PID;
  int v_r_St_5_WonB_St_PID;
  int v_l_St_5_WonB_St_PID;
  Line_follower__st ck_3;
  Line_follower__st s;
  Line_follower__st ns;
  int r;
  int nr;
  int pnr;
  int sharp_thresh;
  int v_448;
  int nr_5_St_5_Parking;
  Line_follower__st_5 ns_5_St_5_Parking;
  int parking_cycles_thresh_St_5_Parking;
  int inx_counter_St_5_Parking;
  int thresh_vals_St_5_Parking[5];
  int min_vals_St_5_Parking[5];
  int max_vals_St_5_Parking[5];
  int last_error_St_5_Parking;
  int pid_error_St_5_Parking;
  int dir_St_5_Parking;
  int v_r_St_5_Parking;
  int v_l_St_5_Parking;
  int nr_5_St_5_ObstacleAvoid;
  Line_follower__st_5 ns_5_St_5_ObstacleAvoid;
  int parking_cycles_thresh_St_5_ObstacleAvoid;
  int inx_counter_St_5_ObstacleAvoid;
  int thresh_vals_St_5_ObstacleAvoid[5];
  int min_vals_St_5_ObstacleAvoid[5];
  int max_vals_St_5_ObstacleAvoid[5];
  int last_error_St_5_ObstacleAvoid;
  int pid_error_St_5_ObstacleAvoid;
  int dir_St_5_ObstacleAvoid;
  int v_r_St_5_ObstacleAvoid;
  int v_l_St_5_ObstacleAvoid;
  int nr_5_St_5_Intersection;
  Line_follower__st_5 ns_5_St_5_Intersection;
  int parking_cycles_thresh_St_5_Intersection;
  int inx_counter_St_5_Intersection;
  int thresh_vals_St_5_Intersection[5];
  int min_vals_St_5_Intersection[5];
  int max_vals_St_5_Intersection[5];
  int last_error_St_5_Intersection;
  int pid_error_St_5_Intersection;
  int dir_St_5_Intersection;
  int v_r_St_5_Intersection;
  int v_l_St_5_Intersection;
  int nr_5_St_5_BonW;
  Line_follower__st_5 ns_5_St_5_BonW;
  int parking_cycles_thresh_St_5_BonW;
  int inx_counter_St_5_BonW;
  int thresh_vals_St_5_BonW[5];
  int min_vals_St_5_BonW[5];
  int max_vals_St_5_BonW[5];
  int last_error_St_5_BonW;
  int pid_error_St_5_BonW;
  int dir_St_5_BonW;
  int v_r_St_5_BonW;
  int v_l_St_5_BonW;
  int nr_5_St_5_WonB;
  Line_follower__st_5 ns_5_St_5_WonB;
  int parking_cycles_thresh_St_5_WonB;
  int inx_counter_St_5_WonB;
  int thresh_vals_St_5_WonB[5];
  int min_vals_St_5_WonB[5];
  int max_vals_St_5_WonB[5];
  int last_error_St_5_WonB;
  int pid_error_St_5_WonB;
  int dir_St_5_WonB;
  int v_r_St_5_WonB;
  int v_l_St_5_WonB;
  int nr_5_St_5_Start;
  Line_follower__st_5 ns_5_St_5_Start;
  int parking_cycles_thresh_St_5_Start;
  int inx_counter_St_5_Start;
  int thresh_vals_St_5_Start[5];
  int min_vals_St_5_Start[5];
  int max_vals_St_5_Start[5];
  int last_error_St_5_Start;
  int pid_error_St_5_Start;
  int dir_St_5_Start;
  int v_r_St_5_Start;
  int v_l_St_5_Start;
  int nr_5_St_5_Idle;
  Line_follower__st_5 ns_5_St_5_Idle;
  int parking_cycles_thresh_St_5_Idle;
  int inx_counter_St_5_Idle;
  int thresh_vals_St_5_Idle[5];
  int min_vals_St_5_Idle[5];
  int max_vals_St_5_Idle[5];
  int last_error_St_5_Idle;
  int pid_error_St_5_Idle;
  int dir_St_5_Idle;
  int v_r_St_5_Idle;
  int v_l_St_5_Idle;
  int nr_5_St_5_Calibrate;
  Line_follower__st_5 ns_5_St_5_Calibrate;
  int parking_cycles_thresh_St_5_Calibrate;
  int inx_counter_St_5_Calibrate;
  int thresh_vals_St_5_Calibrate[5];
  int min_vals_St_5_Calibrate[5];
  int max_vals_St_5_Calibrate[5];
  int last_error_St_5_Calibrate;
  int pid_error_St_5_Calibrate;
  int dir_St_5_Calibrate;
  int v_r_St_5_Calibrate;
  int v_l_St_5_Calibrate;
  Line_follower__st_5 ck_1;
  int v_54;
  int v_53;
  int v_52;
  int v_51;
  int v_50;
  int v_49;
  int v_48;
  int v_47;
  int v_46;
  int v_45;
  int v_44;
  int v_43;
  int v;
  Line_follower__st_5 s_5;
  Line_follower__st_5 ns_5;
  int r_5;
  int nr_5;
  int raw_sen[5];
  int sensor_avg;
  int all_high;
  int pid_error;
  int last_error;
  int max_vals[5];
  int min_vals[5];
  int thresh_vals[5];
  int sen[5];
  int inx_counter;
  int parking_cycles_thresh;
  switch (self->ck) {
    case Line_follower__St_5_Calibrate:
      r_5_St_5_Calibrate = self->pnr_5;
      s_5_St_5_Calibrate = Line_follower__St_5_Calibrate;
      break;
    case Line_follower__St_5_Start:
      r_5_St_5_Start = self->pnr_5;
      s_5_St_5_Start = Line_follower__St_5_Start;
      break;
    case Line_follower__St_5_BonW:
      v_57 = (ir_value==0);
      v_58 = !(v_57);
      if (v_58) {
        r_5_St_5_BonW = true;
        s_5_St_5_BonW = Line_follower__St_5_ObstacleAvoid;
      } else {
        r_5_St_5_BonW = self->pnr_5;
        s_5_St_5_BonW = Line_follower__St_5_BonW;
      };
      break;
    case Line_follower__St_5_Intersection:
      v_55 = (ir_value==0);
      v_56 = !(v_55);
      if (v_56) {
        r_5_St_5_Intersection = true;
        s_5_St_5_Intersection = Line_follower__St_5_ObstacleAvoid;
      } else {
        r_5_St_5_Intersection = self->pnr_5;
        s_5_St_5_Intersection = Line_follower__St_5_Intersection;
      };
      break;
    case Line_follower__St_5_ObstacleAvoid:
      r_5_St_5_ObstacleAvoid = self->pnr_5;
      s_5_St_5_ObstacleAvoid = Line_follower__St_5_ObstacleAvoid;
      break;
    case Line_follower__St_5_Parking:
      r_5_St_5_Parking = self->pnr_5;
      s_5_St_5_Parking = Line_follower__St_5_Parking;
      break;
    default:
      break;
  };
  raw_sen[0] = sen0;
  raw_sen[1] = sen1;
  raw_sen[2] = sen2;
  raw_sen[3] = sen3;
  raw_sen[4] = sen4;
  {
    int i_8;
    for (i_8 = 0; i_8 < 5; ++i_8) {
      Line_follower__normalize_value_step(self->min_vals_1[i_8],
                                          self->max_vals_1[i_8],
                                          raw_sen[i_8],
                                          &Line_follower__normalize_value_out_st);
      sen[i_8] = Line_follower__normalize_value_out_st.norm_val;
    }
  };
  v_53 = sen[4];
  v_54 = (v_53>=Line_follower__high_thresh);
  v_50 = sen[3];
  v_51 = (v_50>=Line_follower__high_thresh);
  v_47 = sen[2];
  v_48 = (v_47>=Line_follower__high_thresh);
  v_44 = sen[1];
  v_45 = (v_44>=Line_follower__high_thresh);
  v = sen[0];
  v_43 = (v>=Line_follower__high_thresh);
  v_46 = (v_43&&v_45);
  v_49 = (v_46&&v_48);
  v_52 = (v_49&&v_51);
  all_high = (v_52&&v_54);
  Line_follower__senWeightedAvg_step(sen,
                                     &Line_follower__senWeightedAvg_out_st);
  sensor_avg = Line_follower__senWeightedAvg_out_st.sensor_avg;
  switch (self->ck) {
    case Line_follower__St_5_Idle:
      if (all_high) {
        r_5_St_5_Idle = true;
        s_5_St_5_Idle = Line_follower__St_5_Start;
      } else {
        r_5_St_5_Idle = self->pnr_5;
        s_5_St_5_Idle = Line_follower__St_5_Idle;
      };
      s_5 = s_5_St_5_Idle;
      r_5 = r_5_St_5_Idle;
      break;
    case Line_follower__St_5_WonB:
      v_70 = sen[4];
      v_71 = (v_70>=Line_follower__high_thresh);
      v_66 = sen[3];
      v_67 = (v_66<=Line_follower__low_thresh);
      v_63 = sen[2];
      v_64 = (v_63<=Line_follower__low_thresh);
      v_61 = sen[1];
      v_62 = (v_61<=Line_follower__low_thresh);
      v_65 = (v_62||v_64);
      v_68 = (v_65||v_67);
      v_59 = sen[0];
      v_60 = (v_59>=Line_follower__high_thresh);
      v_69 = (v_60&&v_68);
      v_72 = (v_69&&v_71);
      if (v_72) {
        r_5_St_5_WonB = true;
        s_5_St_5_WonB = Line_follower__St_5_BonW;
      } else {
        r_5_St_5_WonB = self->pnr_5;
        s_5_St_5_WonB = Line_follower__St_5_WonB;
      };
      s_5 = s_5_St_5_WonB;
      r_5 = r_5_St_5_WonB;
      break;
    case Line_follower__St_5_Parking:
      s_5 = s_5_St_5_Parking;
      r_5 = r_5_St_5_Parking;
      break;
    case Line_follower__St_5_ObstacleAvoid:
      s_5 = s_5_St_5_ObstacleAvoid;
      r_5 = r_5_St_5_ObstacleAvoid;
      break;
    case Line_follower__St_5_Intersection:
      s_5 = s_5_St_5_Intersection;
      r_5 = r_5_St_5_Intersection;
      break;
    case Line_follower__St_5_BonW:
      s_5 = s_5_St_5_BonW;
      r_5 = r_5_St_5_BonW;
      break;
    case Line_follower__St_5_Start:
      s_5 = s_5_St_5_Start;
      r_5 = r_5_St_5_Start;
      break;
    case Line_follower__St_5_Calibrate:
      s_5 = s_5_St_5_Calibrate;
      r_5 = r_5_St_5_Calibrate;
      break;
    default:
      break;
  };
  ck_1 = s_5;
  switch (ck_1) {
    case Line_follower__St_5_Calibrate:
      parking_cycles_thresh_St_5_Calibrate = self->parking_cycles_thresh_1;
      inx_counter_St_5_Calibrate = self->inx_counter_1;
      last_error_St_5_Calibrate = self->last_error_1;
      pid_error_St_5_Calibrate = self->pid_error_11;
      dir_St_5_Calibrate = 2;
      v_r_St_5_Calibrate = 40;
      v_l_St_5_Calibrate = 40;
      nr_5_St_5_Calibrate = false;
      ns_5_St_5_Calibrate = Line_follower__St_5_Calibrate;
      inx_counter = inx_counter_St_5_Calibrate;
      ns_5 = ns_5_St_5_Calibrate;
      nr_5 = nr_5_St_5_Calibrate;
      pid_error = pid_error_St_5_Calibrate;
      parking_cycles_thresh = parking_cycles_thresh_St_5_Calibrate;
      _out->v_l = v_l_St_5_Calibrate;
      _out->v_r = v_r_St_5_Calibrate;
      last_error = last_error_St_5_Calibrate;
      _out->dir = dir_St_5_Calibrate;
      {
        int _6;
        for (_6 = 0; _6 < 5; ++_6) {
          thresh_vals_St_5_Calibrate[_6] = self->thresh_vals_1[_6];
        }
      };
      {
        int _7;
        for (_7 = 0; _7 < 5; ++_7) {
          thresh_vals[_7] = thresh_vals_St_5_Calibrate[_7];
        }
      };
      {
        int i_7;
        for (i_7 = 0; i_7 < 5; ++i_7) {
          Line_follower__updateMaxs_step(raw_sen[i_7], thresh_vals[i_7],
                                         self->max_vals_1[i_7],
                                         &Line_follower__updateMaxs_out_st);
          max_vals_St_5_Calibrate[i_7] = Line_follower__updateMaxs_out_st.new_max;
        }
      };
      {
        int i_6;
        for (i_6 = 0; i_6 < 5; ++i_6) {
          Line_follower__updateMins_step(raw_sen[i_6], thresh_vals[i_6],
                                         self->min_vals_1[i_6],
                                         &Line_follower__updateMins_out_st);
          min_vals_St_5_Calibrate[i_6] = Line_follower__updateMins_out_st.new_min;
        }
      };
      {
        int _8;
        for (_8 = 0; _8 < 5; ++_8) {
          min_vals[_8] = min_vals_St_5_Calibrate[_8];
        }
      };
      {
        int _9;
        for (_9 = 0; _9 < 5; ++_9) {
          max_vals[_9] = max_vals_St_5_Calibrate[_9];
        }
      };
      break;
    case Line_follower__St_5_Idle:
      parking_cycles_thresh_St_5_Idle = self->parking_cycles_thresh_1;
      inx_counter_St_5_Idle = self->inx_counter_1;
      last_error_St_5_Idle = self->last_error_1;
      pid_error_St_5_Idle = self->pid_error_11;
      dir_St_5_Idle = 9;
      v_r_St_5_Idle = 0;
      v_l_St_5_Idle = 0;
      nr_5_St_5_Idle = false;
      ns_5_St_5_Idle = Line_follower__St_5_Idle;
      inx_counter = inx_counter_St_5_Idle;
      ns_5 = ns_5_St_5_Idle;
      nr_5 = nr_5_St_5_Idle;
      pid_error = pid_error_St_5_Idle;
      parking_cycles_thresh = parking_cycles_thresh_St_5_Idle;
      _out->v_l = v_l_St_5_Idle;
      _out->v_r = v_r_St_5_Idle;
      last_error = last_error_St_5_Idle;
      _out->dir = dir_St_5_Idle;
      {
        int _10;
        for (_10 = 0; _10 < 5; ++_10) {
          thresh_vals_St_5_Idle[_10] = self->thresh_vals_1[_10];
        }
      };
      {
        int _11;
        for (_11 = 0; _11 < 5; ++_11) {
          min_vals_St_5_Idle[_11] = self->min_vals_1[_11];
        }
      };
      {
        int _12;
        for (_12 = 0; _12 < 5; ++_12) {
          max_vals_St_5_Idle[_12] = self->max_vals_1[_12];
        }
      };
      {
        int _13;
        for (_13 = 0; _13 < 5; ++_13) {
          thresh_vals[_13] = thresh_vals_St_5_Idle[_13];
        }
      };
      {
        int _14;
        for (_14 = 0; _14 < 5; ++_14) {
          min_vals[_14] = min_vals_St_5_Idle[_14];
        }
      };
      {
        int _15;
        for (_15 = 0; _15 < 5; ++_15) {
          max_vals[_15] = max_vals_St_5_Idle[_15];
        }
      };
      break;
    case Line_follower__St_5_Start:
      parking_cycles_thresh_St_5_Start = self->parking_cycles_thresh_1;
      inx_counter_St_5_Start = self->inx_counter_1;
      last_error_St_5_Start = self->last_error_1;
      pid_error_St_5_Start = self->pid_error_11;
      dir_St_5_Start = 1;
      v_r_St_5_Start = 40;
      v_l_St_5_Start = 40;
      v_448 = !(all_high);
      if (v_448) {
        nr_5_St_5_Start = true;
        ns_5_St_5_Start = Line_follower__St_5_WonB;
      } else {
        nr_5_St_5_Start = false;
        ns_5_St_5_Start = Line_follower__St_5_Start;
      };
      inx_counter = inx_counter_St_5_Start;
      ns_5 = ns_5_St_5_Start;
      nr_5 = nr_5_St_5_Start;
      pid_error = pid_error_St_5_Start;
      parking_cycles_thresh = parking_cycles_thresh_St_5_Start;
      _out->v_l = v_l_St_5_Start;
      _out->v_r = v_r_St_5_Start;
      last_error = last_error_St_5_Start;
      _out->dir = dir_St_5_Start;
      {
        int _16;
        for (_16 = 0; _16 < 5; ++_16) {
          thresh_vals_St_5_Start[_16] = self->thresh_vals_1[_16];
        }
      };
      {
        int _17;
        for (_17 = 0; _17 < 5; ++_17) {
          min_vals_St_5_Start[_17] = self->min_vals_1[_17];
        }
      };
      {
        int _18;
        for (_18 = 0; _18 < 5; ++_18) {
          max_vals_St_5_Start[_18] = self->max_vals_1[_18];
        }
      };
      {
        int _19;
        for (_19 = 0; _19 < 5; ++_19) {
          thresh_vals[_19] = thresh_vals_St_5_Start[_19];
        }
      };
      {
        int _20;
        for (_20 = 0; _20 < 5; ++_20) {
          min_vals[_20] = min_vals_St_5_Start[_20];
        }
      };
      {
        int _21;
        for (_21 = 0; _21 < 5; ++_21) {
          max_vals[_21] = max_vals_St_5_Start[_21];
        }
      };
      break;
    case Line_follower__St_5_WonB:
      parking_cycles_thresh_St_5_WonB = self->parking_cycles_thresh_1;
      inx_counter_St_5_WonB = self->inx_counter_1;
      if (r_5) {
        pnr = false;
        ck_2 = Line_follower__St_PID;
      } else {
        pnr = self->v_447;
        ck_2 = self->v_414;
      };
      sharp_thresh = 15;
      nr_5_St_5_WonB = false;
      ns_5_St_5_WonB = Line_follower__St_5_WonB;
      switch (ck_2) {
        case Line_follower__St_PID:
          v_411 = sen[4];
          v_412 = (v_411<=Line_follower__low_thresh);
          v_408 = sen[3];
          v_409 = (v_408<=Line_follower__low_thresh);
          v_405 = sen[2];
          v_406 = (v_405<=Line_follower__low_thresh);
          v_402 = sen[1];
          v_403 = (v_402<=Line_follower__low_thresh);
          v_400 = sen[0];
          v_401 = (v_400<=Line_follower__low_thresh);
          v_404 = (v_401&&v_403);
          v_407 = (v_404&&v_406);
          v_410 = (v_407&&v_409);
          v_413 = (v_410&&v_412);
          if (v_413) {
            r_St_PID = true;
            s_St_PID = Line_follower__St_Sharp;
          } else {
            r_St_PID = pnr;
            s_St_PID = Line_follower__St_PID;
          };
          s = s_St_PID;
          r = r_St_PID;
          break;
        case Line_follower__St_Sharp:
          r_St_Sharp = pnr;
          s_St_Sharp = Line_follower__St_Sharp;
          s = s_St_Sharp;
          r = r_St_Sharp;
          break;
        default:
          break;
      };
      ck_3 = s;
      switch (ck_3) {
        case Line_follower__St_PID:
          dir_St_5_WonB_St_PID = 1;
          v_444 = (-1*sharp_thresh);
          v_445 = (v_444/2);
          Line_follower__safe_motor_update_step(Line_follower__base_speed,
                                                v_445,
                                                &Line_follower__safe_motor_update_out_st);
          v_446 = Line_follower__safe_motor_update_out_st.new_speed;
          v_438 = (sharp_thresh/2);
          Line_follower__safe_motor_update_step(Line_follower__base_speed,
                                                v_438,
                                                &Line_follower__safe_motor_update_out_st);
          v_439 = Line_follower__safe_motor_update_out_st.new_speed;
          nr_St_PID = false;
          ns_St_PID = Line_follower__St_PID;
          r_11 = (r_5||r);
          if (r_11) {
            Line_follower__calPidError_reset(&self->calPidError_5);
          };
          Line_follower__calPidError_step(sensor_avg,
                                          Line_follower__kscale_white,
                                          &Line_follower__calPidError_out_st,
                                          &self->calPidError_5);
          pid_error_St_5_WonB_St_PID = Line_follower__calPidError_out_st.pid_error;
          pid_error_St_5_WonB = pid_error_St_5_WonB_St_PID;
          ns = ns_St_PID;
          nr = nr_St_PID;
          break;
        case Line_follower__St_Sharp:
          last_error_St_5_WonB_St_Sharp = self->last_error_1;
          pid_error_St_5_WonB_St_Sharp = self->pid_error_11;
          v_r_St_5_WonB_St_Sharp = 40;
          v_l_St_5_WonB_St_Sharp = 40;
          v_426 = sen[4];
          v_427 = (v_426<=Line_follower__low_thresh);
          v_423 = sen[3];
          v_424 = (v_423<=Line_follower__low_thresh);
          v_420 = sen[2];
          v_421 = (v_420>=Line_follower__high_thresh);
          v_417 = sen[1];
          v_418 = (v_417<=Line_follower__low_thresh);
          v_415 = sen[0];
          v_416 = (v_415<=Line_follower__low_thresh);
          v_419 = (v_416&&v_418);
          v_422 = (v_419&&v_421);
          v_425 = (v_422&&v_424);
          v_428 = (v_425&&v_427);
          if (v_428) {
            nr_St_Sharp = true;
            ns_St_Sharp = Line_follower__St_PID;
          } else {
            nr_St_Sharp = false;
            ns_St_Sharp = Line_follower__St_Sharp;
          };
          pid_error_St_5_WonB = pid_error_St_5_WonB_St_Sharp;
          ns = ns_St_Sharp;
          nr = nr_St_Sharp;
          break;
        default:
          break;
      };
      inx_counter = inx_counter_St_5_WonB;
      ns_5 = ns_5_St_5_WonB;
      nr_5 = nr_5_St_5_WonB;
      pid_error = pid_error_St_5_WonB;
      parking_cycles_thresh = parking_cycles_thresh_St_5_WonB;
      switch (ck_3) {
        case Line_follower__St_PID:
          v_441 = (-1*pid_error);
          v_442 = (v_441/2);
          Line_follower__safe_motor_update_step(Line_follower__base_speed,
                                                v_442,
                                                &Line_follower__safe_motor_update_out_st);
          v_443 = Line_follower__safe_motor_update_out_st.new_speed;
          v_440 = (pid_error<=sharp_thresh);
          if (v_440) {
            v_r_St_5_WonB_St_PID = v_443;
          } else {
            v_r_St_5_WonB_St_PID = v_446;
          };
          v_436 = (pid_error/2);
          Line_follower__safe_motor_update_step(Line_follower__base_speed,
                                                v_436,
                                                &Line_follower__safe_motor_update_out_st);
          v_437 = Line_follower__safe_motor_update_out_st.new_speed;
          v_435 = (pid_error<=sharp_thresh);
          if (v_435) {
            v_l_St_5_WonB_St_PID = v_437;
          } else {
            v_l_St_5_WonB_St_PID = v_439;
          };
          v_433 = (pid_error>0);
          if (v_433) {
            v_434 = 1;
          } else {
            v_434 = -1;
          };
          v_432 = (pid_error<=sharp_thresh);
          if (v_432) {
            last_error_St_5_WonB_St_PID = self->last_error_1;
          } else {
            last_error_St_5_WonB_St_PID = v_434;
          };
          v_l_St_5_WonB = v_l_St_5_WonB_St_PID;
          v_r_St_5_WonB = v_r_St_5_WonB_St_PID;
          last_error_St_5_WonB = last_error_St_5_WonB_St_PID;
          break;
        case Line_follower__St_Sharp:
          v_l_St_5_WonB = v_l_St_5_WonB_St_Sharp;
          v_r_St_5_WonB = v_r_St_5_WonB_St_Sharp;
          last_error_St_5_WonB = last_error_St_5_WonB_St_Sharp;
          break;
        default:
          break;
      };
      _out->v_l = v_l_St_5_WonB;
      _out->v_r = v_r_St_5_WonB;
      last_error = last_error_St_5_WonB;
      switch (ck_3) {
        case Line_follower__St_Sharp:
          v_430 = (last_error>0);
          if (v_430) {
            v_431 = 3;
          } else {
            v_431 = 2;
          };
          v_429 = (last_error==0);
          if (v_429) {
            dir_St_5_WonB_St_Sharp = 4;
          } else {
            dir_St_5_WonB_St_Sharp = v_431;
          };
          dir_St_5_WonB = dir_St_5_WonB_St_Sharp;
          break;
        case Line_follower__St_PID:
          dir_St_5_WonB = dir_St_5_WonB_St_PID;
          break;
        default:
          break;
      };
      _out->dir = dir_St_5_WonB;
      {
        int _22;
        for (_22 = 0; _22 < 5; ++_22) {
          thresh_vals_St_5_WonB[_22] = self->thresh_vals_1[_22];
        }
      };
      {
        int _23;
        for (_23 = 0; _23 < 5; ++_23) {
          min_vals_St_5_WonB[_23] = self->min_vals_1[_23];
        }
      };
      {
        int _24;
        for (_24 = 0; _24 < 5; ++_24) {
          max_vals_St_5_WonB[_24] = self->max_vals_1[_24];
        }
      };
      {
        int _25;
        for (_25 = 0; _25 < 5; ++_25) {
          thresh_vals[_25] = thresh_vals_St_5_WonB[_25];
        }
      };
      {
        int _26;
        for (_26 = 0; _26 < 5; ++_26) {
          min_vals[_26] = min_vals_St_5_WonB[_26];
        }
      };
      {
        int _27;
        for (_27 = 0; _27 < 5; ++_27) {
          max_vals[_27] = max_vals_St_5_WonB[_27];
        }
      };
      self->v_447 = nr;
      self->v_414 = ns;
      break;
    case Line_follower__St_5_BonW:
      parking_cycles_thresh_St_5_BonW = self->parking_cycles_thresh_1;
      inx_counter_St_5_BonW = self->inx_counter_1;
      v_397 = sen[2];
      v_398 = (v_397<=Line_follower__low_thresh);
      v_394 = sen[3];
      v_395 = (v_394<=Line_follower__low_thresh);
      v_392 = sen[4];
      v_393 = (v_392<=Line_follower__low_thresh);
      v_396 = (v_393&&v_395);
      v_399 = (v_396&&v_398);
      v_388 = sen[2];
      v_389 = (v_388<=Line_follower__low_thresh);
      v_385 = sen[1];
      v_386 = (v_385<=Line_follower__low_thresh);
      v_383 = sen[3];
      v_384 = (v_383<=Line_follower__low_thresh);
      v_387 = (v_384&&v_386);
      v_390 = (v_387&&v_389);
      v_380 = sen[2];
      v_381 = (v_380<=Line_follower__low_thresh);
      v_377 = sen[1];
      v_378 = (v_377<=Line_follower__low_thresh);
      v_375 = sen[0];
      v_376 = (v_375<=Line_follower__low_thresh);
      v_379 = (v_376&&v_378);
      v_382 = (v_379&&v_381);
      v_391 = (v_382||v_390);
      inx_condition = (v_391||v_399);
      sharp_thresh_1 = 30;
      if (inx_condition) {
        nr_5_St_5_BonW = true;
        ns_5_St_5_BonW = Line_follower__St_5_Intersection;
      } else {
        nr_5_St_5_BonW = false;
        ns_5_St_5_BonW = Line_follower__St_5_BonW;
      };
      r_10 = r_5;
      if (r_10) {
        Line_follower__calPidError_reset(&self->calPidError_4);
      };
      Line_follower__calPidError_step(sensor_avg,
                                      Line_follower__kscale_black,
                                      &Line_follower__calPidError_out_st,
                                      &self->calPidError_4);
      pid_error_St_5_BonW = Line_follower__calPidError_out_st.pid_error;
      inx_counter = inx_counter_St_5_BonW;
      ns_5 = ns_5_St_5_BonW;
      nr_5 = nr_5_St_5_BonW;
      pid_error = pid_error_St_5_BonW;
      v_373 = (pid_error>0);
      if (v_373) {
        v_374 = 1;
      } else {
        v_374 = -1;
      };
      v_372 = (pid_error==0);
      if (v_372) {
        last_error_St_5_BonW = self->last_error_1;
      } else {
        last_error_St_5_BonW = v_374;
      };
      v_370 = (pid_error>0);
      if (v_370) {
        v_371 = 3;
      } else {
        v_371 = 2;
      };
      Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
      v_368 = Line_follower__abs_out_st.out;
      v_369 = (v_368<=sharp_thresh_1);
      if (v_369) {
        dir_St_5_BonW = 1;
      } else {
        dir_St_5_BonW = v_371;
      };
      Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
      v_365 = Line_follower__abs_out_st.out;
      v_366 = (v_365+20);
      Line_follower__safe_motor_update_step(0, v_366,
                                            &Line_follower__safe_motor_update_out_st);
      v_367 = Line_follower__safe_motor_update_out_st.new_speed;
      v_362 = (-1*pid_error);
      v_363 = (v_362/2);
      Line_follower__safe_motor_update_step(Line_follower__base_speed, v_363,
                                            &Line_follower__safe_motor_update_out_st);
      v_364 = Line_follower__safe_motor_update_out_st.new_speed;
      Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
      v_360 = Line_follower__abs_out_st.out;
      v_361 = (v_360<=sharp_thresh_1);
      if (v_361) {
        v_r_St_5_BonW = v_364;
      } else {
        v_r_St_5_BonW = v_367;
      };
      Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
      v_357 = Line_follower__abs_out_st.out;
      v_358 = (v_357+20);
      Line_follower__safe_motor_update_step(0, v_358,
                                            &Line_follower__safe_motor_update_out_st);
      v_359 = Line_follower__safe_motor_update_out_st.new_speed;
      v_355 = (pid_error/2);
      Line_follower__safe_motor_update_step(Line_follower__base_speed, v_355,
                                            &Line_follower__safe_motor_update_out_st);
      v_356 = Line_follower__safe_motor_update_out_st.new_speed;
      Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
      v_353 = Line_follower__abs_out_st.out;
      v_354 = (v_353<=sharp_thresh_1);
      if (v_354) {
        v_l_St_5_BonW = v_356;
      } else {
        v_l_St_5_BonW = v_359;
      };
      parking_cycles_thresh = parking_cycles_thresh_St_5_BonW;
      _out->v_l = v_l_St_5_BonW;
      _out->v_r = v_r_St_5_BonW;
      last_error = last_error_St_5_BonW;
      _out->dir = dir_St_5_BonW;
      {
        int _28;
        for (_28 = 0; _28 < 5; ++_28) {
          thresh_vals_St_5_BonW[_28] = self->thresh_vals_1[_28];
        }
      };
      {
        int _29;
        for (_29 = 0; _29 < 5; ++_29) {
          min_vals_St_5_BonW[_29] = self->min_vals_1[_29];
        }
      };
      {
        int _30;
        for (_30 = 0; _30 < 5; ++_30) {
          max_vals_St_5_BonW[_30] = self->max_vals_1[_30];
        }
      };
      {
        int _31;
        for (_31 = 0; _31 < 5; ++_31) {
          thresh_vals[_31] = thresh_vals_St_5_BonW[_31];
        }
      };
      {
        int _32;
        for (_32 = 0; _32 < 5; ++_32) {
          min_vals[_32] = min_vals_St_5_BonW[_32];
        }
      };
      {
        int _33;
        for (_33 = 0; _33 < 5; ++_33) {
          max_vals[_33] = max_vals_St_5_BonW[_33];
        }
      };
      break;
    case Line_follower__St_5_Intersection:
      parking_cycles_thresh_St_5_Intersection = self->parking_cycles_thresh_1;
      last_error_St_5_Intersection = self->last_error_1;
      pid_error_St_5_Intersection = self->pid_error_11;
      if (r_5) {
        pnr_1 = false;
      } else {
        pnr_1 = self->v_352;
      };
      r_1 = pnr_1;
      if (r_5) {
        ck_4 = Line_follower__St_1_Counter;
      } else {
        ck_4 = self->v_351;
      };
      switch (ck_4) {
        case Line_follower__St_1_Counter:
          complete_St_1_Counter = false;
          v_350 = (self->inx_counter_1+1);
          v_349 = (self->inx_counter_1>=2);
          if (v_349) {
            inx_counter_St_5_Intersection_St_1_Counter = v_350;
          } else {
            inx_counter_St_5_Intersection_St_1_Counter = self->inx_counter_1;
          };
          v_r_St_5_Intersection_St_1_Counter = 0;
          v_l_St_5_Intersection_St_1_Counter = 0;
          dir_St_5_Intersection_St_1_Counter = 0;
          if (true) {
            nr_1_St_1_Counter = true;
          } else {
            nr_1_St_1_Counter = false;
          };
          if (true) {
            ns_1_St_1_Counter = Line_follower__St_1_Entry;
          } else {
            ns_1_St_1_Counter = Line_follower__St_1_Counter;
          };
          v_l_St_5_Intersection = v_l_St_5_Intersection_St_1_Counter;
          v_r_St_5_Intersection = v_r_St_5_Intersection_St_1_Counter;
          dir_St_5_Intersection = dir_St_5_Intersection_St_1_Counter;
          inx_counter_St_5_Intersection = inx_counter_St_5_Intersection_St_1_Counter;
          complete = complete_St_1_Counter;
          break;
        case Line_follower__St_1_Entry:
          inx_counter_St_5_Intersection_St_1_Entry = self->inx_counter_1;
          v_346 = sen[3];
          v_347 = (v_346>=Line_follower__high_thresh);
          v_343 = sen[2];
          v_344 = (v_343>=Line_follower__high_thresh);
          v_340 = sen[1];
          v_341 = (v_340>=Line_follower__high_thresh);
          v_337 = sen[0];
          v_338 = (v_337>=Line_follower__high_thresh);
          v_335 = sen[4];
          v_336 = (v_335<=Line_follower__low_thresh);
          v_339 = (v_336&&v_338);
          v_342 = (v_339&&v_341);
          v_345 = (v_342&&v_344);
          v_348 = (v_345&&v_347);
          v_331 = sen[4];
          v_332 = (v_331>=Line_follower__high_thresh);
          v_328 = sen[2];
          v_329 = (v_328>=Line_follower__high_thresh);
          v_325 = sen[1];
          v_326 = (v_325>=Line_follower__high_thresh);
          v_322 = sen[0];
          v_323 = (v_322>=Line_follower__high_thresh);
          v_320 = sen[3];
          v_321 = (v_320<=Line_follower__low_thresh);
          v_324 = (v_321&&v_323);
          v_327 = (v_324&&v_326);
          v_330 = (v_327&&v_329);
          v_333 = (v_330&&v_332);
          v_316 = sen[4];
          v_317 = (v_316>=Line_follower__high_thresh);
          v_313 = sen[3];
          v_314 = (v_313>=Line_follower__high_thresh);
          v_310 = sen[1];
          v_311 = (v_310>=Line_follower__high_thresh);
          v_307 = sen[0];
          v_308 = (v_307>=Line_follower__high_thresh);
          v_305 = sen[2];
          v_306 = (v_305<=Line_follower__low_thresh);
          v_309 = (v_306&&v_308);
          v_312 = (v_309&&v_311);
          v_315 = (v_312&&v_314);
          v_318 = (v_315&&v_317);
          v_301 = sen[4];
          v_302 = (v_301>=Line_follower__high_thresh);
          v_298 = sen[3];
          v_299 = (v_298>=Line_follower__high_thresh);
          v_295 = sen[2];
          v_296 = (v_295>=Line_follower__high_thresh);
          v_292 = sen[0];
          v_293 = (v_292>=Line_follower__high_thresh);
          v_290 = sen[1];
          v_291 = (v_290<=Line_follower__low_thresh);
          v_294 = (v_291&&v_293);
          v_297 = (v_294&&v_296);
          v_300 = (v_297&&v_299);
          v_303 = (v_300&&v_302);
          v_287 = sen[4];
          v_288 = (v_287>=Line_follower__high_thresh);
          v_284 = sen[3];
          v_285 = (v_284>=Line_follower__high_thresh);
          v_281 = sen[2];
          v_282 = (v_281>=Line_follower__high_thresh);
          v_278 = sen[1];
          v_279 = (v_278>=Line_follower__high_thresh);
          v_276 = sen[0];
          v_277 = (v_276<=Line_follower__low_thresh);
          v_280 = (v_277&&v_279);
          v_283 = (v_280&&v_282);
          v_286 = (v_283&&v_285);
          v_289 = (v_286&&v_288);
          v_304 = (v_289||v_303);
          v_319 = (v_304||v_318);
          v_334 = (v_319||v_333);
          only_one_low = (v_334||v_348);
          complete_St_1_Entry = false;
          v_r_St_5_Intersection_St_1_Entry = 40;
          v_l_St_5_Intersection_St_1_Entry = 40;
          dir_St_5_Intersection_St_1_Entry = 1;
          v_l_St_5_Intersection = v_l_St_5_Intersection_St_1_Entry;
          v_r_St_5_Intersection = v_r_St_5_Intersection_St_1_Entry;
          dir_St_5_Intersection = dir_St_5_Intersection_St_1_Entry;
          inx_counter_St_5_Intersection = inx_counter_St_5_Intersection_St_1_Entry;
          complete = complete_St_1_Entry;
          break;
        case Line_follower__St_1_ExitRight:
          inx_counter_St_5_Intersection_St_1_ExitRight = self->inx_counter_1;
          complete_St_1_ExitRight = !(all_high);
          v_r_St_5_Intersection_St_1_ExitRight = 40;
          v_l_St_5_Intersection_St_1_ExitRight = 40;
          dir_St_5_Intersection_St_1_ExitRight = 3;
          nr_1_St_1_ExitRight = false;
          ns_1_St_1_ExitRight = Line_follower__St_1_ExitRight;
          v_l_St_5_Intersection = v_l_St_5_Intersection_St_1_ExitRight;
          v_r_St_5_Intersection = v_r_St_5_Intersection_St_1_ExitRight;
          dir_St_5_Intersection = dir_St_5_Intersection_St_1_ExitRight;
          inx_counter_St_5_Intersection = inx_counter_St_5_Intersection_St_1_ExitRight;
          complete = complete_St_1_ExitRight;
          break;
        case Line_follower__St_1_ExitLeft:
          inx_counter_St_5_Intersection_St_1_ExitLeft = self->inx_counter_1;
          v_263 = sen[0];
          complete_St_1_ExitLeft = (v_263<=Line_follower__low_thresh);
          v_r_St_5_Intersection_St_1_ExitLeft = 40;
          v_l_St_5_Intersection_St_1_ExitLeft = 40;
          dir_St_5_Intersection_St_1_ExitLeft = 2;
          nr_1_St_1_ExitLeft = false;
          ns_1_St_1_ExitLeft = Line_follower__St_1_ExitLeft;
          v_l_St_5_Intersection = v_l_St_5_Intersection_St_1_ExitLeft;
          v_r_St_5_Intersection = v_r_St_5_Intersection_St_1_ExitLeft;
          dir_St_5_Intersection = dir_St_5_Intersection_St_1_ExitLeft;
          inx_counter_St_5_Intersection = inx_counter_St_5_Intersection_St_1_ExitLeft;
          complete = complete_St_1_ExitLeft;
          break;
        case Line_follower__St_1_ExitStraight:
          inx_counter_St_5_Intersection_St_1_ExitStraight = self->inx_counter_1;
          complete_St_1_ExitStraight = true;
          v_r_St_5_Intersection_St_1_ExitStraight = 0;
          v_l_St_5_Intersection_St_1_ExitStraight = 0;
          dir_St_5_Intersection_St_1_ExitStraight = 9;
          nr_1_St_1_ExitStraight = false;
          ns_1_St_1_ExitStraight = Line_follower__St_1_ExitStraight;
          v_l_St_5_Intersection = v_l_St_5_Intersection_St_1_ExitStraight;
          v_r_St_5_Intersection = v_r_St_5_Intersection_St_1_ExitStraight;
          dir_St_5_Intersection = dir_St_5_Intersection_St_1_ExitStraight;
          inx_counter_St_5_Intersection = inx_counter_St_5_Intersection_St_1_ExitStraight;
          complete = complete_St_1_ExitStraight;
          break;
        default:
          break;
      };
      inx_counter = inx_counter_St_5_Intersection;
      v_259 = (inx_counter==5);
      v_260 = (complete&&v_259);
      if (v_260) {
        v_262 = true;
        v_261 = Line_follower__St_5_Parking;
      } else {
        v_262 = false;
        v_261 = Line_follower__St_5_Intersection;
      };
      v_256 = (inx_counter==5);
      v_257 = !(v_256);
      v_258 = (complete&&v_257);
      if (v_258) {
        nr_5_St_5_Intersection = true;
        ns_5_St_5_Intersection = Line_follower__St_5_BonW;
      } else {
        nr_5_St_5_Intersection = v_262;
        ns_5_St_5_Intersection = v_261;
      };
      ns_5 = ns_5_St_5_Intersection;
      nr_5 = nr_5_St_5_Intersection;
      switch (ck_4) {
        case Line_follower__St_1_Entry:
          v_270 = (inx_counter==5);
          v_271 = (v_270&&only_one_low);
          if (v_271) {
            v_273 = true;
            v_272 = Line_follower__St_1_ExitStraight;
          } else {
            v_273 = false;
            v_272 = Line_follower__St_1_Entry;
          };
          v_267 = (inx_counter==4);
          v_266 = (inx_counter==3);
          v_268 = (v_266||v_267);
          v_269 = (v_268&&only_one_low);
          if (v_269) {
            v_275 = true;
            v_274 = Line_follower__St_1_ExitLeft;
          } else {
            v_275 = v_273;
            v_274 = v_272;
          };
          v_264 = (inx_counter<=2);
          v_265 = (v_264&&all_high);
          if (v_265) {
            nr_1_St_1_Entry = true;
            ns_1_St_1_Entry = Line_follower__St_1_ExitRight;
          } else {
            nr_1_St_1_Entry = v_275;
            ns_1_St_1_Entry = v_274;
          };
          ns_1 = ns_1_St_1_Entry;
          nr_1 = nr_1_St_1_Entry;
          break;
        case Line_follower__St_1_ExitStraight:
          ns_1 = ns_1_St_1_ExitStraight;
          nr_1 = nr_1_St_1_ExitStraight;
          break;
        case Line_follower__St_1_ExitLeft:
          ns_1 = ns_1_St_1_ExitLeft;
          nr_1 = nr_1_St_1_ExitLeft;
          break;
        case Line_follower__St_1_ExitRight:
          ns_1 = ns_1_St_1_ExitRight;
          nr_1 = nr_1_St_1_ExitRight;
          break;
        case Line_follower__St_1_Counter:
          ns_1 = ns_1_St_1_Counter;
          nr_1 = nr_1_St_1_Counter;
          break;
        default:
          break;
      };
      pid_error = pid_error_St_5_Intersection;
      parking_cycles_thresh = parking_cycles_thresh_St_5_Intersection;
      _out->v_l = v_l_St_5_Intersection;
      _out->v_r = v_r_St_5_Intersection;
      last_error = last_error_St_5_Intersection;
      _out->dir = dir_St_5_Intersection;
      {
        int _34;
        for (_34 = 0; _34 < 5; ++_34) {
          thresh_vals_St_5_Intersection[_34] = self->thresh_vals_1[_34];
        }
      };
      {
        int _35;
        for (_35 = 0; _35 < 5; ++_35) {
          min_vals_St_5_Intersection[_35] = self->min_vals_1[_35];
        }
      };
      {
        int _36;
        for (_36 = 0; _36 < 5; ++_36) {
          max_vals_St_5_Intersection[_36] = self->max_vals_1[_36];
        }
      };
      {
        int _37;
        for (_37 = 0; _37 < 5; ++_37) {
          thresh_vals[_37] = thresh_vals_St_5_Intersection[_37];
        }
      };
      {
        int _38;
        for (_38 = 0; _38 < 5; ++_38) {
          min_vals[_38] = min_vals_St_5_Intersection[_38];
        }
      };
      {
        int _39;
        for (_39 = 0; _39 < 5; ++_39) {
          max_vals[_39] = max_vals_St_5_Intersection[_39];
        }
      };
      self->v_352 = nr_1;
      self->v_351 = ns_1;
      break;
    case Line_follower__St_5_ObstacleAvoid:
      parking_cycles_thresh_St_5_ObstacleAvoid = self->parking_cycles_thresh_1;
      last_error_St_5_ObstacleAvoid = self->last_error_1;
      pid_error_St_5_ObstacleAvoid = self->pid_error_11;
      if (r_5) {
        pnr_3 = false;
        ck_5 = Line_follower__St_3_Wait;
      } else {
        pnr_3 = self->v_255;
        ck_5 = self->v_216;
      };
      v_184 = sen[4];
      v_185 = (v_184>=Line_follower__higher_thresh);
      v_181 = sen[3];
      v_182 = (v_181>=Line_follower__higher_thresh);
      v_178 = sen[2];
      v_179 = (v_178>=Line_follower__higher_thresh);
      v_175 = sen[1];
      v_176 = (v_175>=Line_follower__higher_thresh);
      v_173 = sen[0];
      v_174 = (v_173>=Line_follower__higher_thresh);
      v_177 = (v_174&&v_176);
      v_180 = (v_177&&v_179);
      v_183 = (v_180&&v_182);
      all_very_high = (v_183&&v_185);
      switch (ck_5) {
        case Line_follower__St_3_Wait:
          r_3_St_3_Wait = pnr_3;
          s_3_St_3_Wait = Line_follower__St_3_Wait;
          s_3 = s_3_St_3_Wait;
          r_3 = r_3_St_3_Wait;
          break;
        case Line_follower__St_3_FullRight:
          if (obs_left) {
            r_3_St_3_FullRight = true;
            s_3_St_3_FullRight = Line_follower__St_3_SlightStraight;
          } else {
            r_3_St_3_FullRight = pnr_3;
            s_3_St_3_FullRight = Line_follower__St_3_FullRight;
          };
          s_3 = s_3_St_3_FullRight;
          r_3 = r_3_St_3_FullRight;
          break;
        case Line_follower__St_3_SlightStraight:
          r_3_St_3_SlightStraight = pnr_3;
          s_3_St_3_SlightStraight = Line_follower__St_3_SlightStraight;
          s_3 = s_3_St_3_SlightStraight;
          r_3 = r_3_St_3_SlightStraight;
          break;
        case Line_follower__St_3_SlightRight:
          v_211 = !(all_high);
          if (v_211) {
            v_213 = true;
            v_212 = Line_follower__St_3_ExitStart;
          } else {
            v_213 = pnr_3;
            v_212 = Line_follower__St_3_SlightRight;
          };
          v_209 = (ir_value==0);
          v_210 = !(v_209);
          if (v_210) {
            v_215 = true;
            v_214 = Line_follower__St_3_FullRight;
          } else {
            v_215 = v_213;
            v_214 = v_212;
          };
          v_208 = !(obs_left);
          if (v_208) {
            r_3_St_3_SlightRight = true;
            s_3_St_3_SlightRight = Line_follower__St_3_SlightLeft;
          } else {
            r_3_St_3_SlightRight = v_215;
            s_3_St_3_SlightRight = v_214;
          };
          s_3 = s_3_St_3_SlightRight;
          r_3 = r_3_St_3_SlightRight;
          break;
        case Line_follower__St_3_SlightLeft:
          v_203 = !(all_high);
          if (v_203) {
            v_205 = true;
            v_204 = Line_follower__St_3_ExitStart;
          } else {
            v_205 = pnr_3;
            v_204 = Line_follower__St_3_SlightLeft;
          };
          v_201 = (ir_value==0);
          v_202 = !(v_201);
          if (v_202) {
            v_207 = true;
          } else {
            v_207 = v_205;
          };
          if (obs_left) {
            r_3_St_3_SlightLeft = true;
          } else {
            r_3_St_3_SlightLeft = v_207;
          };
          if (v_202) {
            v_206 = Line_follower__St_3_FullRight;
          } else {
            v_206 = v_204;
          };
          if (obs_left) {
            s_3_St_3_SlightLeft = Line_follower__St_3_SlightRight;
          } else {
            s_3_St_3_SlightLeft = v_206;
          };
          s_3 = s_3_St_3_SlightLeft;
          r_3 = r_3_St_3_SlightLeft;
          break;
        case Line_follower__St_3_ExitStart:
          v_196 = sen[4];
          v_197 = (v_196<=Line_follower__low_thresh);
          v_193 = sen[3];
          v_194 = (v_193<=Line_follower__low_thresh);
          v_191 = sen[2];
          v_192 = (v_191<=Line_follower__low_thresh);
          v_195 = (v_192||v_194);
          v_198 = (v_195||v_197);
          if (v_198) {
            v_200 = true;
            v_199 = Line_follower__St_3_ExitEnd2;
          } else {
            v_200 = pnr_3;
            v_199 = Line_follower__St_3_ExitStart;
          };
          v_188 = sen[1];
          v_189 = (v_188<=Line_follower__low_thresh);
          v_186 = sen[0];
          v_187 = (v_186<=Line_follower__low_thresh);
          v_190 = (v_187||v_189);
          if (v_190) {
            r_3_St_3_ExitStart = true;
            s_3_St_3_ExitStart = Line_follower__St_3_ExitEnd1;
          } else {
            r_3_St_3_ExitStart = v_200;
            s_3_St_3_ExitStart = v_199;
          };
          s_3 = s_3_St_3_ExitStart;
          r_3 = r_3_St_3_ExitStart;
          break;
        case Line_follower__St_3_ExitEnd1:
          r_3_St_3_ExitEnd1 = pnr_3;
          s_3_St_3_ExitEnd1 = Line_follower__St_3_ExitEnd1;
          s_3 = s_3_St_3_ExitEnd1;
          r_3 = r_3_St_3_ExitEnd1;
          break;
        case Line_follower__St_3_ExitEnd2:
          r_3_St_3_ExitEnd2 = pnr_3;
          s_3_St_3_ExitEnd2 = Line_follower__St_3_ExitEnd2;
          s_3 = s_3_St_3_ExitEnd2;
          r_3 = r_3_St_3_ExitEnd2;
          break;
        default:
          break;
      };
      ck_6 = s_3;
      switch (ck_6) {
        case Line_follower__St_3_Wait:
          inx_counter_St_5_ObstacleAvoid_St_3_Wait = self->inx_counter_1;
          v_254 = (ir_value==0);
          if (v_254) {
            complete_1_St_3_Wait = true;
          } else {
            complete_1_St_3_Wait = false;
          };
          v_253 = (self->v_252+1);
          v_250 = (r_5||r_3);
          if (self->v_249) {
            v_251 = true;
          } else {
            v_251 = v_250;
          };
          if (v_251) {
            ncycles = 0;
          } else {
            ncycles = v_253;
          };
          dir_St_5_ObstacleAvoid_St_3_Wait = 9;
          v_r_St_5_ObstacleAvoid_St_3_Wait = 0;
          v_l_St_5_ObstacleAvoid_St_3_Wait = 0;
          v_248 = (ncycles>1000);
          if (v_248) {
            nr_3_St_3_Wait = true;
            ns_3_St_3_Wait = Line_follower__St_3_FullRight;
          } else {
            nr_3_St_3_Wait = false;
            ns_3_St_3_Wait = Line_follower__St_3_Wait;
          };
          v_l_St_5_ObstacleAvoid = v_l_St_5_ObstacleAvoid_St_3_Wait;
          v_r_St_5_ObstacleAvoid = v_r_St_5_ObstacleAvoid_St_3_Wait;
          dir_St_5_ObstacleAvoid = dir_St_5_ObstacleAvoid_St_3_Wait;
          inx_counter_St_5_ObstacleAvoid = inx_counter_St_5_ObstacleAvoid_St_3_Wait;
          ns_3 = ns_3_St_3_Wait;
          nr_3 = nr_3_St_3_Wait;
          complete_1 = complete_1_St_3_Wait;
          break;
        case Line_follower__St_3_FullRight:
          inx_counter_St_5_ObstacleAvoid_St_3_FullRight = self->inx_counter_1;
          complete_1_St_3_FullRight = false;
          dir_St_5_ObstacleAvoid_St_3_FullRight = 3;
          v_r_St_5_ObstacleAvoid_St_3_FullRight = 40;
          v_l_St_5_ObstacleAvoid_St_3_FullRight = 40;
          nr_3_St_3_FullRight = false;
          ns_3_St_3_FullRight = Line_follower__St_3_FullRight;
          v_l_St_5_ObstacleAvoid = v_l_St_5_ObstacleAvoid_St_3_FullRight;
          v_r_St_5_ObstacleAvoid = v_r_St_5_ObstacleAvoid_St_3_FullRight;
          dir_St_5_ObstacleAvoid = dir_St_5_ObstacleAvoid_St_3_FullRight;
          inx_counter_St_5_ObstacleAvoid = inx_counter_St_5_ObstacleAvoid_St_3_FullRight;
          ns_3 = ns_3_St_3_FullRight;
          nr_3 = nr_3_St_3_FullRight;
          complete_1 = complete_1_St_3_FullRight;
          break;
        case Line_follower__St_3_SlightStraight:
          inx_counter_St_5_ObstacleAvoid_St_3_SlightStraight = self->inx_counter_1;
          complete_1_St_3_SlightStraight = false;
          v_247 = (self->v_246+1);
          v_244 = (r_5||r_3);
          if (self->v_243) {
            v_245 = true;
          } else {
            v_245 = v_244;
          };
          if (v_245) {
            ncycles_1 = 0;
          } else {
            ncycles_1 = v_247;
          };
          v_r_St_5_ObstacleAvoid_St_3_SlightStraight = 40;
          v_l_St_5_ObstacleAvoid_St_3_SlightStraight = 40;
          dir_St_5_ObstacleAvoid_St_3_SlightStraight = 1;
          if (all_high) {
            nr_3_St_3_SlightStraight = true;
            ns_3_St_3_SlightStraight = Line_follower__St_3_SlightLeft;
          } else {
            nr_3_St_3_SlightStraight = false;
            ns_3_St_3_SlightStraight = Line_follower__St_3_SlightStraight;
          };
          v_l_St_5_ObstacleAvoid = v_l_St_5_ObstacleAvoid_St_3_SlightStraight;
          v_r_St_5_ObstacleAvoid = v_r_St_5_ObstacleAvoid_St_3_SlightStraight;
          dir_St_5_ObstacleAvoid = dir_St_5_ObstacleAvoid_St_3_SlightStraight;
          inx_counter_St_5_ObstacleAvoid = inx_counter_St_5_ObstacleAvoid_St_3_SlightStraight;
          ns_3 = ns_3_St_3_SlightStraight;
          nr_3 = nr_3_St_3_SlightStraight;
          complete_1 = complete_1_St_3_SlightStraight;
          break;
        case Line_follower__St_3_SlightRight:
          inx_counter_St_5_ObstacleAvoid_St_3_SlightRight = self->inx_counter_1;
          complete_1_St_3_SlightRight = false;
          v_r_St_5_ObstacleAvoid_St_3_SlightRight = 10;
          v_l_St_5_ObstacleAvoid_St_3_SlightRight = 50;
          dir_St_5_ObstacleAvoid_St_3_SlightRight = 1;
          nr_3_St_3_SlightRight = false;
          ns_3_St_3_SlightRight = Line_follower__St_3_SlightRight;
          v_l_St_5_ObstacleAvoid = v_l_St_5_ObstacleAvoid_St_3_SlightRight;
          v_r_St_5_ObstacleAvoid = v_r_St_5_ObstacleAvoid_St_3_SlightRight;
          dir_St_5_ObstacleAvoid = dir_St_5_ObstacleAvoid_St_3_SlightRight;
          inx_counter_St_5_ObstacleAvoid = inx_counter_St_5_ObstacleAvoid_St_3_SlightRight;
          ns_3 = ns_3_St_3_SlightRight;
          nr_3 = nr_3_St_3_SlightRight;
          complete_1 = complete_1_St_3_SlightRight;
          break;
        case Line_follower__St_3_SlightLeft:
          inx_counter_St_5_ObstacleAvoid_St_3_SlightLeft = self->inx_counter_1;
          complete_1_St_3_SlightLeft = false;
          v_r_St_5_ObstacleAvoid_St_3_SlightLeft = 50;
          v_l_St_5_ObstacleAvoid_St_3_SlightLeft = 10;
          dir_St_5_ObstacleAvoid_St_3_SlightLeft = 1;
          nr_3_St_3_SlightLeft = false;
          ns_3_St_3_SlightLeft = Line_follower__St_3_SlightLeft;
          v_l_St_5_ObstacleAvoid = v_l_St_5_ObstacleAvoid_St_3_SlightLeft;
          v_r_St_5_ObstacleAvoid = v_r_St_5_ObstacleAvoid_St_3_SlightLeft;
          dir_St_5_ObstacleAvoid = dir_St_5_ObstacleAvoid_St_3_SlightLeft;
          inx_counter_St_5_ObstacleAvoid = inx_counter_St_5_ObstacleAvoid_St_3_SlightLeft;
          ns_3 = ns_3_St_3_SlightLeft;
          nr_3 = nr_3_St_3_SlightLeft;
          complete_1 = complete_1_St_3_SlightLeft;
          break;
        case Line_follower__St_3_ExitStart:
          inx_counter_St_5_ObstacleAvoid_St_3_ExitStart = 2;
          complete_1_St_3_ExitStart = false;
          v_r_St_5_ObstacleAvoid_St_3_ExitStart = 0;
          v_l_St_5_ObstacleAvoid_St_3_ExitStart = 0;
          dir_St_5_ObstacleAvoid_St_3_ExitStart = 9;
          nr_3_St_3_ExitStart = false;
          ns_3_St_3_ExitStart = Line_follower__St_3_ExitStart;
          v_l_St_5_ObstacleAvoid = v_l_St_5_ObstacleAvoid_St_3_ExitStart;
          v_r_St_5_ObstacleAvoid = v_r_St_5_ObstacleAvoid_St_3_ExitStart;
          dir_St_5_ObstacleAvoid = dir_St_5_ObstacleAvoid_St_3_ExitStart;
          inx_counter_St_5_ObstacleAvoid = inx_counter_St_5_ObstacleAvoid_St_3_ExitStart;
          ns_3 = ns_3_St_3_ExitStart;
          nr_3 = nr_3_St_3_ExitStart;
          complete_1 = complete_1_St_3_ExitStart;
          break;
        case Line_follower__St_3_ExitEnd1:
          inx_counter_St_5_ObstacleAvoid_St_3_ExitEnd1 = self->inx_counter_1;
          v_241 = (r_5||r_3);
          if (v_241) {
            pnr_2 = false;
          } else {
            pnr_2 = self->v_242;
          };
          v_238 = (r_5||r_3);
          if (v_238) {
            ck_7 = Line_follower__St_2_St_high_0;
          } else {
            ck_7 = self->v_239;
          };
          v_r_St_5_ObstacleAvoid_St_3_ExitEnd1 = 10;
          v_l_St_5_ObstacleAvoid_St_3_ExitEnd1 = 50;
          dir_St_5_ObstacleAvoid_St_3_ExitEnd1 = 1;
          nr_3_St_3_ExitEnd1 = false;
          ns_3_St_3_ExitEnd1 = Line_follower__St_3_ExitEnd1;
          v_l_St_5_ObstacleAvoid = v_l_St_5_ObstacleAvoid_St_3_ExitEnd1;
          v_r_St_5_ObstacleAvoid = v_r_St_5_ObstacleAvoid_St_3_ExitEnd1;
          dir_St_5_ObstacleAvoid = dir_St_5_ObstacleAvoid_St_3_ExitEnd1;
          inx_counter_St_5_ObstacleAvoid = inx_counter_St_5_ObstacleAvoid_St_3_ExitEnd1;
          ns_3 = ns_3_St_3_ExitEnd1;
          nr_3 = nr_3_St_3_ExitEnd1;
          switch (ck_7) {
            case Line_follower__St_2_St_high_0:
              v_236 = sen[0];
              v_237 = (v_236<=Line_follower__low_thresh);
              if (v_237) {
                r_2_St_2_St_high_0 = true;
                s_2_St_2_St_high_0 = Line_follower__St_2_St_low_1;
              } else {
                r_2_St_2_St_high_0 = pnr_2;
                s_2_St_2_St_high_0 = Line_follower__St_2_St_high_0;
              };
              s_2 = s_2_St_2_St_high_0;
              r_2 = r_2_St_2_St_high_0;
              break;
            case Line_follower__St_2_St_low_1:
              v_234 = sen[0];
              v_235 = (v_234>=Line_follower__high_thresh);
              if (v_235) {
                r_2_St_2_St_low_1 = true;
                s_2_St_2_St_low_1 = Line_follower__St_2_St_high_1;
              } else {
                r_2_St_2_St_low_1 = pnr_2;
                s_2_St_2_St_low_1 = Line_follower__St_2_St_low_1;
              };
              s_2 = s_2_St_2_St_low_1;
              r_2 = r_2_St_2_St_low_1;
              break;
            case Line_follower__St_2_St_high_1:
              r_2_St_2_St_high_1 = pnr_2;
              s_2_St_2_St_high_1 = Line_follower__St_2_St_high_1;
              s_2 = s_2_St_2_St_high_1;
              r_2 = r_2_St_2_St_high_1;
              break;
            default:
              break;
          };
          ck_8 = s_2;
          switch (ck_8) {
            case Line_follower__St_2_St_high_0:
              complete_1_St_3_ExitEnd1_St_2_St_high_0 = false;
              nr_2_St_2_St_high_0 = false;
              ns_2_St_2_St_high_0 = Line_follower__St_2_St_high_0;
              complete_1_St_3_ExitEnd1 = complete_1_St_3_ExitEnd1_St_2_St_high_0;
              ns_2 = ns_2_St_2_St_high_0;
              nr_2 = nr_2_St_2_St_high_0;
              break;
            case Line_follower__St_2_St_low_1:
              complete_1_St_3_ExitEnd1_St_2_St_low_1 = false;
              nr_2_St_2_St_low_1 = false;
              ns_2_St_2_St_low_1 = Line_follower__St_2_St_low_1;
              complete_1_St_3_ExitEnd1 = complete_1_St_3_ExitEnd1_St_2_St_low_1;
              ns_2 = ns_2_St_2_St_low_1;
              nr_2 = nr_2_St_2_St_low_1;
              break;
            case Line_follower__St_2_St_high_1:
              v_240 = sen[0];
              complete_1_St_3_ExitEnd1_St_2_St_high_1 = (v_240<=Line_follower__low_thresh);
              nr_2_St_2_St_high_1 = false;
              ns_2_St_2_St_high_1 = Line_follower__St_2_St_high_1;
              complete_1_St_3_ExitEnd1 = complete_1_St_3_ExitEnd1_St_2_St_high_1;
              ns_2 = ns_2_St_2_St_high_1;
              nr_2 = nr_2_St_2_St_high_1;
              break;
            default:
              break;
          };
          complete_1 = complete_1_St_3_ExitEnd1;
          break;
        case Line_follower__St_3_ExitEnd2:
          inx_counter_St_5_ObstacleAvoid_St_3_ExitEnd2 = self->inx_counter_1;
          v_232 = sen[2];
          v_233 = (v_232<=Line_follower__low_thresh);
          v_228 = sen[2];
          v_229 = (v_228>=Line_follower__high_thresh);
          v_225 = (r_5||r_3);
          if (self->v_224) {
            v_226 = true;
          } else {
            v_226 = v_225;
          };
          v_221 = sen[1];
          v_222 = (v_221<=Line_follower__low_thresh);
          if (self->v_220) {
            v_223 = true;
          } else {
            v_223 = v_222;
          };
          v_218 = (r_5||r_3);
          if (self->v_217) {
            v_219 = true;
          } else {
            v_219 = v_218;
          };
          if (v_219) {
            sen_1_low1 = false;
          } else {
            sen_1_low1 = v_223;
          };
          v_230 = (sen_1_low1&&v_229);
          if (self->v_227) {
            v_231 = true;
          } else {
            v_231 = v_230;
          };
          if (v_226) {
            sen_1_high1 = false;
          } else {
            sen_1_high1 = v_231;
          };
          complete_1_St_3_ExitEnd2 = (sen_1_high1&&v_233);
          v_r_St_5_ObstacleAvoid_St_3_ExitEnd2 = 10;
          v_l_St_5_ObstacleAvoid_St_3_ExitEnd2 = 50;
          dir_St_5_ObstacleAvoid_St_3_ExitEnd2 = 1;
          nr_3_St_3_ExitEnd2 = false;
          ns_3_St_3_ExitEnd2 = Line_follower__St_3_ExitEnd2;
          v_l_St_5_ObstacleAvoid = v_l_St_5_ObstacleAvoid_St_3_ExitEnd2;
          v_r_St_5_ObstacleAvoid = v_r_St_5_ObstacleAvoid_St_3_ExitEnd2;
          dir_St_5_ObstacleAvoid = dir_St_5_ObstacleAvoid_St_3_ExitEnd2;
          inx_counter_St_5_ObstacleAvoid = inx_counter_St_5_ObstacleAvoid_St_3_ExitEnd2;
          ns_3 = ns_3_St_3_ExitEnd2;
          nr_3 = nr_3_St_3_ExitEnd2;
          complete_1 = complete_1_St_3_ExitEnd2;
          break;
        default:
          break;
      };
      if (complete_1) {
        nr_5_St_5_ObstacleAvoid = true;
        ns_5_St_5_ObstacleAvoid = Line_follower__St_5_BonW;
      } else {
        nr_5_St_5_ObstacleAvoid = false;
        ns_5_St_5_ObstacleAvoid = Line_follower__St_5_ObstacleAvoid;
      };
      inx_counter = inx_counter_St_5_ObstacleAvoid;
      ns_5 = ns_5_St_5_ObstacleAvoid;
      nr_5 = nr_5_St_5_ObstacleAvoid;
      pid_error = pid_error_St_5_ObstacleAvoid;
      parking_cycles_thresh = parking_cycles_thresh_St_5_ObstacleAvoid;
      _out->v_l = v_l_St_5_ObstacleAvoid;
      _out->v_r = v_r_St_5_ObstacleAvoid;
      last_error = last_error_St_5_ObstacleAvoid;
      _out->dir = dir_St_5_ObstacleAvoid;
      {
        int _40;
        for (_40 = 0; _40 < 5; ++_40) {
          thresh_vals_St_5_ObstacleAvoid[_40] = self->thresh_vals_1[_40];
        }
      };
      {
        int _41;
        for (_41 = 0; _41 < 5; ++_41) {
          thresh_vals[_41] = thresh_vals_St_5_ObstacleAvoid[_41];
        }
      };
      {
        int _42;
        for (_42 = 0; _42 < 5; ++_42) {
          min_vals_St_5_ObstacleAvoid[_42] = self->min_vals_1[_42];
        }
      };
      {
        int _43;
        for (_43 = 0; _43 < 5; ++_43) {
          min_vals[_43] = min_vals_St_5_ObstacleAvoid[_43];
        }
      };
      {
        int _44;
        for (_44 = 0; _44 < 5; ++_44) {
          max_vals_St_5_ObstacleAvoid[_44] = self->max_vals_1[_44];
        }
      };
      {
        int _45;
        for (_45 = 0; _45 < 5; ++_45) {
          max_vals[_45] = max_vals_St_5_ObstacleAvoid[_45];
        }
      };
      self->v_255 = nr_3;
      self->v_216 = ns_3;
      break;
    case Line_follower__St_5_Parking:
      inx_counter_St_5_Parking = self->inx_counter_1;
      last_error_St_5_Parking = self->last_error_1;
      if (r_5) {
        pnr_4 = false;
      } else {
        pnr_4 = self->v_172;
      };
      r_4 = pnr_4;
      if (r_5) {
        ck_9 = Line_follower__St_4_Train;
      } else {
        ck_9 = self->v_171;
      };
      nr_5_St_5_Parking = false;
      ns_5_St_5_Parking = Line_follower__St_5_Parking;
      inx_counter = inx_counter_St_5_Parking;
      ns_5 = ns_5_St_5_Parking;
      nr_5 = nr_5_St_5_Parking;
      switch (ck_9) {
        case Line_follower__St_4_Train:
          v_165 = !(obs_right);
          v_163 = !(obs_left);
          v_162 = (obs_left&&obs_right);
          v_160 = (self->v_159+1);
          v_157 = !(obs_right);
          v_155 = (r_5||r_4);
          if (self->v_154) {
            v_156 = true;
          } else {
            v_156 = v_155;
          };
          v_152 = (self->v_151+1);
          v_149 = !(obs_left);
          v_147 = (r_5||r_4);
          if (self->v_146) {
            v_148 = true;
          } else {
            v_148 = v_147;
          };
          if (self->v_144) {
            v_145 = true;
          } else {
            v_145 = obs_right;
          };
          v_142 = (r_5||r_4);
          if (self->v_141) {
            v_143 = true;
          } else {
            v_143 = v_142;
          };
          if (v_143) {
            right_was_high = false;
          } else {
            right_was_high = v_145;
          };
          v_158 = (v_157&&right_was_high);
          if (v_158) {
            v_161 = v_160;
          } else {
            v_161 = 0;
          };
          if (v_156) {
            cycles_right = 0;
          } else {
            cycles_right = v_161;
          };
          Line_follower__max_step(self->parking_cycles_thresh_1,
                                  cycles_right, &Line_follower__max_out_st);
          v_166 = Line_follower__max_out_st.val_m;
          if (self->v_139) {
            v_140 = true;
          } else {
            v_140 = obs_left;
          };
          v_137 = (r_5||r_4);
          if (self->v_136) {
            v_138 = true;
          } else {
            v_138 = v_137;
          };
          if (v_138) {
            left_was_high = false;
          } else {
            left_was_high = v_140;
          };
          v_150 = (v_149&&left_was_high);
          if (v_150) {
            v_153 = v_152;
          } else {
            v_153 = 0;
          };
          if (v_148) {
            cycles_left = 0;
          } else {
            cycles_left = v_153;
          };
          Line_follower__max_step(cycles_left, cycles_right,
                                  &Line_follower__max_out_st);
          v_167 = Line_follower__max_out_st.val_m;
          Line_follower__max_step(self->parking_cycles_thresh_1, v_167,
                                  &Line_follower__max_out_st);
          v_168 = Line_follower__max_out_st.val_m;
          if (v_165) {
            v_169 = v_166;
          } else {
            v_169 = v_168;
          };
          Line_follower__max_step(self->parking_cycles_thresh_1, cycles_left,
                                  &Line_follower__max_out_st);
          v_164 = Line_follower__max_out_st.val_m;
          if (v_163) {
            v_170 = v_164;
          } else {
            v_170 = v_169;
          };
          if (v_162) {
            parking_cycles_thresh_St_5_Parking_St_4_Train = self->parking_cycles_thresh_1;
          } else {
            parking_cycles_thresh_St_5_Parking_St_4_Train = v_170;
          };
          r_9 = (r_5||r_4);
          if (r_9) {
            Line_follower__calPidError_reset(&self->calPidError_3);
          };
          Line_follower__calPidError_step(sensor_avg,
                                          Line_follower__kscale_black,
                                          &Line_follower__calPidError_out_st,
                                          &self->calPidError_3);
          pid_error_St_5_Parking_St_4_Train = Line_follower__calPidError_out_st.pid_error;
          pid_error_St_5_Parking = pid_error_St_5_Parking_St_4_Train;
          parking_cycles_thresh_St_5_Parking = parking_cycles_thresh_St_5_Parking_St_4_Train;
          break;
        case Line_follower__St_4_FindSpace:
          parking_cycles_thresh_St_5_Parking_St_4_FindSpace = self->parking_cycles_thresh_1;
          v_131 = (self->v_130+1);
          if (obs_right) {
            v_132 = 0;
          } else {
            v_132 = v_131;
          };
          v_128 = (r_5||r_4);
          if (self->v_127) {
            v_129 = true;
          } else {
            v_129 = v_128;
          };
          if (v_129) {
            cycles_right_1 = 0;
          } else {
            cycles_right_1 = v_132;
          };
          v_125 = (self->v_124+1);
          if (obs_left) {
            v_126 = 0;
          } else {
            v_126 = v_125;
          };
          v_122 = (r_5||r_4);
          if (self->v_121) {
            v_123 = true;
          } else {
            v_123 = v_122;
          };
          if (v_123) {
            cycles_left_1 = 0;
          } else {
            cycles_left_1 = v_126;
          };
          r_8 = (r_5||r_4);
          if (r_8) {
            Line_follower__calPidError_reset(&self->calPidError_2);
          };
          Line_follower__calPidError_step(sensor_avg,
                                          Line_follower__kscale_black,
                                          &Line_follower__calPidError_out_st,
                                          &self->calPidError_2);
          pid_error_St_5_Parking_St_4_FindSpace = Line_follower__calPidError_out_st.pid_error;
          pid_error_St_5_Parking = pid_error_St_5_Parking_St_4_FindSpace;
          parking_cycles_thresh_St_5_Parking = parking_cycles_thresh_St_5_Parking_St_4_FindSpace;
          break;
        case Line_follower__St_4_GoBackL:
          parking_cycles_thresh_St_5_Parking_St_4_GoBackL = self->parking_cycles_thresh_1;
          dir_St_5_Parking_St_4_GoBackL = 4;
          v_112 = (self->v_111+1);
          v_109 = (r_5||r_4);
          if (self->v_108) {
            v_110 = true;
          } else {
            v_110 = v_109;
          };
          if (v_110) {
            ncycles_2 = 0;
          } else {
            ncycles_2 = v_112;
          };
          r_7 = (r_5||r_4);
          if (r_7) {
            Line_follower__calPidError_reset(&self->calPidError_1);
          };
          Line_follower__calPidError_step(sensor_avg,
                                          Line_follower__kscale_black,
                                          &Line_follower__calPidError_out_st,
                                          &self->calPidError_1);
          pid_error_St_5_Parking_St_4_GoBackL = Line_follower__calPidError_out_st.pid_error;
          pid_error_St_5_Parking = pid_error_St_5_Parking_St_4_GoBackL;
          parking_cycles_thresh_St_5_Parking = parking_cycles_thresh_St_5_Parking_St_4_GoBackL;
          break;
        case Line_follower__St_4_GoBackR:
          parking_cycles_thresh_St_5_Parking_St_4_GoBackR = self->parking_cycles_thresh_1;
          dir_St_5_Parking_St_4_GoBackR = 4;
          v_104 = (self->v_103+1);
          v_101 = (r_5||r_4);
          if (self->v_100) {
            v_102 = true;
          } else {
            v_102 = v_101;
          };
          if (v_102) {
            ncycles_3 = 0;
          } else {
            ncycles_3 = v_104;
          };
          r_6 = (r_5||r_4);
          if (r_6) {
            Line_follower__calPidError_reset(&self->calPidError);
          };
          Line_follower__calPidError_step(sensor_avg,
                                          Line_follower__kscale_black,
                                          &Line_follower__calPidError_out_st,
                                          &self->calPidError);
          pid_error_St_5_Parking_St_4_GoBackR = Line_follower__calPidError_out_st.pid_error;
          pid_error_St_5_Parking = pid_error_St_5_Parking_St_4_GoBackR;
          parking_cycles_thresh_St_5_Parking = parking_cycles_thresh_St_5_Parking_St_4_GoBackR;
          break;
        case Line_follower__St_4_ParkLeft:
          parking_cycles_thresh_St_5_Parking_St_4_ParkLeft = self->parking_cycles_thresh_1;
          pid_error_St_5_Parking_St_4_ParkLeft = self->pid_error_11;
          dir_St_5_Parking_St_4_ParkLeft = 3;
          v_r_St_5_Parking_St_4_ParkLeft = 50;
          v_l_St_5_Parking_St_4_ParkLeft = 50;
          v_96 = (self->v_95+1);
          v_93 = (r_5||r_4);
          if (self->v_92) {
            v_94 = true;
          } else {
            v_94 = v_93;
          };
          if (v_94) {
            ncycles_4 = 0;
          } else {
            ncycles_4 = v_96;
          };
          pid_error_St_5_Parking = pid_error_St_5_Parking_St_4_ParkLeft;
          parking_cycles_thresh_St_5_Parking = parking_cycles_thresh_St_5_Parking_St_4_ParkLeft;
          break;
        case Line_follower__St_4_ParkRight:
          parking_cycles_thresh_St_5_Parking_St_4_ParkRight = self->parking_cycles_thresh_1;
          pid_error_St_5_Parking_St_4_ParkRight = self->pid_error_11;
          dir_St_5_Parking_St_4_ParkRight = 2;
          v_r_St_5_Parking_St_4_ParkRight = 50;
          v_l_St_5_Parking_St_4_ParkRight = 50;
          v_88 = (self->v_87+1);
          v_85 = (r_5||r_4);
          if (self->v_84) {
            v_86 = true;
          } else {
            v_86 = v_85;
          };
          if (v_86) {
            ncycles_5 = 0;
          } else {
            ncycles_5 = v_88;
          };
          pid_error_St_5_Parking = pid_error_St_5_Parking_St_4_ParkRight;
          parking_cycles_thresh_St_5_Parking = parking_cycles_thresh_St_5_Parking_St_4_ParkRight;
          break;
        case Line_follower__St_4_GoReverse:
          parking_cycles_thresh_St_5_Parking_St_4_GoReverse = self->parking_cycles_thresh_1;
          pid_error_St_5_Parking_St_4_GoReverse = self->pid_error_11;
          dir_St_5_Parking_St_4_GoReverse = 4;
          v_r_St_5_Parking_St_4_GoReverse = 50;
          v_l_St_5_Parking_St_4_GoReverse = 50;
          v_80 = (self->v_79+1);
          v_77 = (r_5||r_4);
          if (self->v_76) {
            v_78 = true;
          } else {
            v_78 = v_77;
          };
          if (v_78) {
            ncycles_6 = 0;
          } else {
            ncycles_6 = v_80;
          };
          pid_error_St_5_Parking = pid_error_St_5_Parking_St_4_GoReverse;
          parking_cycles_thresh_St_5_Parking = parking_cycles_thresh_St_5_Parking_St_4_GoReverse;
          break;
        case Line_follower__St_4_Stop:
          parking_cycles_thresh_St_5_Parking_St_4_Stop = self->parking_cycles_thresh_1;
          pid_error_St_5_Parking_St_4_Stop = self->pid_error_11;
          dir_St_5_Parking_St_4_Stop = 9;
          v_r_St_5_Parking_St_4_Stop = 0;
          v_l_St_5_Parking_St_4_Stop = 0;
          nr_4_St_4_Stop = false;
          ns_4_St_4_Stop = Line_follower__St_4_Stop;
          pid_error_St_5_Parking = pid_error_St_5_Parking_St_4_Stop;
          parking_cycles_thresh_St_5_Parking = parking_cycles_thresh_St_5_Parking_St_4_Stop;
          break;
        default:
          break;
      };
      pid_error = pid_error_St_5_Parking;
      parking_cycles_thresh = parking_cycles_thresh_St_5_Parking;
      switch (ck_9) {
        case Line_follower__St_4_Train:
          Line_follower__pid_err_to_speeds_park_step(pid_error,
                                                     &Line_follower__pid_err_to_speeds_park_out_st);
          v_l_St_5_Parking_St_4_Train = Line_follower__pid_err_to_speeds_park_out_st.v_l;
          v_r_St_5_Parking_St_4_Train = Line_follower__pid_err_to_speeds_park_out_st.v_r;
          dir_St_5_Parking_St_4_Train = Line_follower__pid_err_to_speeds_park_out_st.dir;
          v_133 = (parking_cycles_thresh>0);
          v_134 = (v_133&&obs_left);
          v_135 = (v_134&&obs_right);
          if (v_135) {
            nr_4_St_4_Train = true;
            ns_4_St_4_Train = Line_follower__St_4_FindSpace;
          } else {
            nr_4_St_4_Train = false;
            ns_4_St_4_Train = Line_follower__St_4_Train;
          };
          v_l_St_5_Parking = v_l_St_5_Parking_St_4_Train;
          v_r_St_5_Parking = v_r_St_5_Parking_St_4_Train;
          dir_St_5_Parking = dir_St_5_Parking_St_4_Train;
          ns_4 = ns_4_St_4_Train;
          nr_4 = nr_4_St_4_Train;
          break;
        case Line_follower__St_4_FindSpace:
          Line_follower__pid_err_to_speeds_park_step(pid_error,
                                                     &Line_follower__pid_err_to_speeds_park_out_st);
          v_l_St_5_Parking_St_4_FindSpace = Line_follower__pid_err_to_speeds_park_out_st.v_l;
          v_r_St_5_Parking_St_4_FindSpace = Line_follower__pid_err_to_speeds_park_out_st.v_r;
          dir_St_5_Parking_St_4_FindSpace = Line_follower__pid_err_to_speeds_park_out_st.dir;
          v_116 = (parking_cycles_thresh*7);
          v_117 = (v_116/3);
          v_118 = (cycles_right_1>v_117);
          if (v_118) {
            v_120 = true;
            v_119 = Line_follower__St_4_GoBackR;
          } else {
            v_120 = false;
            v_119 = Line_follower__St_4_FindSpace;
          };
          v_113 = (parking_cycles_thresh*7);
          v_114 = (v_113/3);
          v_115 = (cycles_left_1>v_114);
          if (v_115) {
            nr_4_St_4_FindSpace = true;
            ns_4_St_4_FindSpace = Line_follower__St_4_GoBackL;
          } else {
            nr_4_St_4_FindSpace = v_120;
            ns_4_St_4_FindSpace = v_119;
          };
          v_l_St_5_Parking = v_l_St_5_Parking_St_4_FindSpace;
          v_r_St_5_Parking = v_r_St_5_Parking_St_4_FindSpace;
          dir_St_5_Parking = dir_St_5_Parking_St_4_FindSpace;
          ns_4 = ns_4_St_4_FindSpace;
          nr_4 = nr_4_St_4_FindSpace;
          break;
        case Line_follower__St_4_GoBackL:
          Line_follower__pid_err_to_speeds_park_step(pid_error,
                                                     &Line_follower__pid_err_to_speeds_park_out_st);
          v_l_St_5_Parking_St_4_GoBackL = Line_follower__pid_err_to_speeds_park_out_st.v_l;
          v_r_St_5_Parking_St_4_GoBackL = Line_follower__pid_err_to_speeds_park_out_st.v_r;
          locdir = Line_follower__pid_err_to_speeds_park_out_st.dir;
          v_105 = (parking_cycles_thresh*7);
          v_106 = (v_105/6);
          v_107 = (ncycles_2>v_106);
          if (v_107) {
            nr_4_St_4_GoBackL = true;
            ns_4_St_4_GoBackL = Line_follower__St_4_ParkLeft;
          } else {
            nr_4_St_4_GoBackL = false;
            ns_4_St_4_GoBackL = Line_follower__St_4_GoBackL;
          };
          v_l_St_5_Parking = v_l_St_5_Parking_St_4_GoBackL;
          v_r_St_5_Parking = v_r_St_5_Parking_St_4_GoBackL;
          dir_St_5_Parking = dir_St_5_Parking_St_4_GoBackL;
          ns_4 = ns_4_St_4_GoBackL;
          nr_4 = nr_4_St_4_GoBackL;
          break;
        case Line_follower__St_4_GoBackR:
          Line_follower__pid_err_to_speeds_park_step(pid_error,
                                                     &Line_follower__pid_err_to_speeds_park_out_st);
          v_l_St_5_Parking_St_4_GoBackR = Line_follower__pid_err_to_speeds_park_out_st.v_l;
          v_r_St_5_Parking_St_4_GoBackR = Line_follower__pid_err_to_speeds_park_out_st.v_r;
          locdir_1 = Line_follower__pid_err_to_speeds_park_out_st.dir;
          v_97 = (parking_cycles_thresh*7);
          v_98 = (v_97/6);
          v_99 = (ncycles_3>v_98);
          if (v_99) {
            nr_4_St_4_GoBackR = true;
            ns_4_St_4_GoBackR = Line_follower__St_4_ParkRight;
          } else {
            nr_4_St_4_GoBackR = false;
            ns_4_St_4_GoBackR = Line_follower__St_4_GoBackR;
          };
          v_l_St_5_Parking = v_l_St_5_Parking_St_4_GoBackR;
          v_r_St_5_Parking = v_r_St_5_Parking_St_4_GoBackR;
          dir_St_5_Parking = dir_St_5_Parking_St_4_GoBackR;
          ns_4 = ns_4_St_4_GoBackR;
          nr_4 = nr_4_St_4_GoBackR;
          break;
        case Line_follower__St_4_ParkLeft:
          v_89 = (parking_cycles_thresh*3);
          v_90 = (v_89/4);
          v_91 = (ncycles_4>v_90);
          if (v_91) {
            nr_4_St_4_ParkLeft = true;
            ns_4_St_4_ParkLeft = Line_follower__St_4_GoReverse;
          } else {
            nr_4_St_4_ParkLeft = false;
            ns_4_St_4_ParkLeft = Line_follower__St_4_ParkLeft;
          };
          v_l_St_5_Parking = v_l_St_5_Parking_St_4_ParkLeft;
          v_r_St_5_Parking = v_r_St_5_Parking_St_4_ParkLeft;
          dir_St_5_Parking = dir_St_5_Parking_St_4_ParkLeft;
          ns_4 = ns_4_St_4_ParkLeft;
          nr_4 = nr_4_St_4_ParkLeft;
          break;
        case Line_follower__St_4_ParkRight:
          v_81 = (parking_cycles_thresh*3);
          v_82 = (v_81/4);
          v_83 = (ncycles_5>v_82);
          if (v_83) {
            nr_4_St_4_ParkRight = true;
            ns_4_St_4_ParkRight = Line_follower__St_4_GoReverse;
          } else {
            nr_4_St_4_ParkRight = false;
            ns_4_St_4_ParkRight = Line_follower__St_4_ParkRight;
          };
          v_l_St_5_Parking = v_l_St_5_Parking_St_4_ParkRight;
          v_r_St_5_Parking = v_r_St_5_Parking_St_4_ParkRight;
          dir_St_5_Parking = dir_St_5_Parking_St_4_ParkRight;
          ns_4 = ns_4_St_4_ParkRight;
          nr_4 = nr_4_St_4_ParkRight;
          break;
        case Line_follower__St_4_GoReverse:
          v_73 = (parking_cycles_thresh*3);
          v_74 = (v_73/3);
          v_75 = (ncycles_6>v_74);
          if (v_75) {
            nr_4_St_4_GoReverse = true;
            ns_4_St_4_GoReverse = Line_follower__St_4_Stop;
          } else {
            nr_4_St_4_GoReverse = false;
            ns_4_St_4_GoReverse = Line_follower__St_4_GoReverse;
          };
          v_l_St_5_Parking = v_l_St_5_Parking_St_4_GoReverse;
          v_r_St_5_Parking = v_r_St_5_Parking_St_4_GoReverse;
          dir_St_5_Parking = dir_St_5_Parking_St_4_GoReverse;
          ns_4 = ns_4_St_4_GoReverse;
          nr_4 = nr_4_St_4_GoReverse;
          break;
        case Line_follower__St_4_Stop:
          v_l_St_5_Parking = v_l_St_5_Parking_St_4_Stop;
          v_r_St_5_Parking = v_r_St_5_Parking_St_4_Stop;
          dir_St_5_Parking = dir_St_5_Parking_St_4_Stop;
          ns_4 = ns_4_St_4_Stop;
          nr_4 = nr_4_St_4_Stop;
          break;
        default:
          break;
      };
      _out->v_l = v_l_St_5_Parking;
      _out->v_r = v_r_St_5_Parking;
      last_error = last_error_St_5_Parking;
      _out->dir = dir_St_5_Parking;
      {
        int _46;
        for (_46 = 0; _46 < 5; ++_46) {
          thresh_vals_St_5_Parking[_46] = self->thresh_vals_1[_46];
        }
      };
      {
        int _47;
        for (_47 = 0; _47 < 5; ++_47) {
          thresh_vals[_47] = thresh_vals_St_5_Parking[_47];
        }
      };
      {
        int _48;
        for (_48 = 0; _48 < 5; ++_48) {
          min_vals_St_5_Parking[_48] = self->min_vals_1[_48];
        }
      };
      {
        int _49;
        for (_49 = 0; _49 < 5; ++_49) {
          min_vals[_49] = min_vals_St_5_Parking[_49];
        }
      };
      {
        int _50;
        for (_50 = 0; _50 < 5; ++_50) {
          max_vals_St_5_Parking[_50] = self->max_vals_1[_50];
        }
      };
      {
        int _51;
        for (_51 = 0; _51 < 5; ++_51) {
          max_vals[_51] = max_vals_St_5_Parking[_51];
        }
      };
      self->v_172 = nr_4;
      self->v_171 = ns_4;
      break;
    default:
      break;
  };
  self->parking_cycles_thresh_1 = parking_cycles_thresh;
  self->inx_counter_1 = inx_counter;
  {
    int _52;
    for (_52 = 0; _52 < 5; ++_52) {
      self->sen_2[_52] = sen[_52];
    }
  };
  {
    int _53;
    for (_53 = 0; _53 < 5; ++_53) {
      self->thresh_vals_1[_53] = thresh_vals[_53];
    }
  };
  {
    int _54;
    for (_54 = 0; _54 < 5; ++_54) {
      self->min_vals_1[_54] = min_vals[_54];
    }
  };
  {
    int _55;
    for (_55 = 0; _55 < 5; ++_55) {
      self->max_vals_1[_55] = max_vals[_55];
    }
  };
  self->last_error_1 = last_error;
  self->pid_error_11 = pid_error;
  self->pnr_5 = nr_5;
  self->ck = ns_5;
  switch (ck_1) {
    case Line_follower__St_5_ObstacleAvoid:
      switch (ck_6) {
        case Line_follower__St_3_Wait:
          self->v_252 = ncycles;
          self->v_249 = false;
          break;
        case Line_follower__St_3_SlightStraight:
          self->v_246 = ncycles_1;
          self->v_243 = false;
          break;
        case Line_follower__St_3_ExitEnd1:
          self->v_242 = nr_2;
          self->v_239 = ns_2;
          break;
        case Line_follower__St_3_ExitEnd2:
          self->v_227 = sen_1_high1;
          self->v_224 = false;
          self->v_220 = sen_1_low1;
          self->v_217 = false;
          break;
        default:
          break;
      };
      break;
    case Line_follower__St_5_Parking:
      switch (ck_9) {
        case Line_follower__St_4_Train:
          self->v_159 = cycles_right;
          self->v_154 = false;
          self->v_151 = cycles_left;
          self->v_146 = false;
          self->v_144 = right_was_high;
          self->v_141 = false;
          self->v_139 = left_was_high;
          self->v_136 = false;
          break;
        case Line_follower__St_4_FindSpace:
          self->v_130 = cycles_right_1;
          self->v_127 = false;
          self->v_124 = cycles_left_1;
          self->v_121 = false;
          break;
        case Line_follower__St_4_GoBackL:
          self->v_111 = ncycles_2;
          self->v_108 = false;
          break;
        case Line_follower__St_4_GoBackR:
          self->v_103 = ncycles_3;
          self->v_100 = false;
          break;
        case Line_follower__St_4_ParkLeft:
          self->v_95 = ncycles_4;
          self->v_92 = false;
          break;
        case Line_follower__St_4_ParkRight:
          self->v_87 = ncycles_5;
          self->v_84 = false;
          break;
        case Line_follower__St_4_GoReverse:
          self->v_79 = ncycles_6;
          self->v_76 = false;
          break;
        default:
          break;
      };
      break;
    default:
      break;
  };;
}

