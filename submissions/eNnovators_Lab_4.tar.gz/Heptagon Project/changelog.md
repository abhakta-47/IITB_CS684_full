## Files changed
- heptagon/line_follower.ept
- integrate.sh
- supervisor/alphabot_drivers.cpp
- supervisor/alphabot_drivers.h
- supervisor/supervisor.ino

## Commits
7c30994 2025-03-27 11:08:24 ab47 - lab4: stop at 4th interseciton;
6c44253 2025-03-27 10:51:54 ab47 - kp changed to 2; readd color switch transition; stable obstacle exit;
ef0598f 2025-03-27 09:04:39 ab47 - rock solid color switch; integrate: auto rename _mem vars;
e5367ac 2025-03-27 07:38:06 ab47 - stable obstacle edge follow; bad exit;
29ec5a3 2025-03-26 18:04:57 ab47 - stable intersection navigation
e0b5c0a 2025-03-26 14:47:45 ab47 - stable obstacle avoidacnce
4ad7af2 2025-03-26 11:07:57 ab47 - obstacle draft
32a1dfe 2025-03-25 19:29:21 ab47 - obstacle avoidance draft
db6001e 2025-03-25 10:30:56 ab47 - .7 stable color switch & black follow;
edb3cff 2025-03-21 19:07:05 ab47 - bonw no complement
9b04de5 2025-03-21 16:15:46 ab47 - fast wonb: new weights; speed 40 no oled no color switch; recovery hold direction;
033d89c 2025-03-21 11:40:02 ab47 - obs parking init; supervisor #include guards