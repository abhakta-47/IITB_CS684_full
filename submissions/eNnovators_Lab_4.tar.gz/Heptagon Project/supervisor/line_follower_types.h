/* --- Generated the 28/3/2025 at 10:28 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. mar. 8 9:40:4 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#ifndef LINE_FOLLOWER_TYPES_H
#define LINE_FOLLOWER_TYPES_H

#include "stdbool.h"
#include "assert.h"
#include "pervasives.h"
typedef enum {
  Line_follower__St_4_WonB,
  Line_follower__St_4_Transition,
  Line_follower__St_4_Stop,
  Line_follower__St_4_Start,
  Line_follower__St_4_ObstacleAvoid,
  Line_follower__St_4_Idle,
  Line_follower__St_4_Calibrate,
  Line_follower__St_4_BonW
} Line_follower__st_4;

Line_follower__st_4 Line_follower__st_4_of_string(char* s);

char* string_of_Line_follower__st_4(Line_follower__st_4 x, char* buf);

typedef enum {
  Line_follower__St_3_Wait,
  Line_follower__St_3_SlightRight,
  Line_follower__St_3_SlightLeft,
  Line_follower__St_3_FullRight,
  Line_follower__St_3_ExitStart,
  Line_follower__St_3_ExitEnd2,
  Line_follower__St_3_ExitEnd1
} Line_follower__st_3;

Line_follower__st_3 Line_follower__st_3_of_string(char* s);

char* string_of_Line_follower__st_3(Line_follower__st_3 x, char* buf);

typedef enum {
  Line_follower__St_2_PID,
  Line_follower__St_2_Intersection
} Line_follower__st_2;

Line_follower__st_2 Line_follower__st_2_of_string(char* s);

char* string_of_Line_follower__st_2(Line_follower__st_2 x, char* buf);

typedef enum {
  Line_follower__St_1_ExitRight,
  Line_follower__St_1_ExitLeft,
  Line_follower__St_1_Entry,
  Line_follower__St_1_Counter
} Line_follower__st_1;

Line_follower__st_1 Line_follower__st_1_of_string(char* s);

char* string_of_Line_follower__st_1(Line_follower__st_1 x, char* buf);

typedef enum {
  Line_follower__St_Recovery,
  Line_follower__St_PID
} Line_follower__st;

Line_follower__st Line_follower__st_of_string(char* s);

char* string_of_Line_follower__st(Line_follower__st x, char* buf);

static const long Line_follower__sensor_min = 0;

static const long Line_follower__sensor_max = 1000;

static const long Line_follower__sensor_weights[5] = {-5, -2, 0, 2, 5};

static const long Line_follower__kscale_white = 100;

static const long Line_follower__kscale_black = -120;

static const long Line_follower__kp = 2;

static const long Line_follower__kd = 0;

static const long Line_follower__ki = 0;

static const long Line_follower__max_i = 200000000;

static const long Line_follower__acc_thresh = 10;

static const long Line_follower__base_speed = 50;

static const long Line_follower__safe_speed_high = 50;

static const long Line_follower__safe_speed_low = 10;

static const long Line_follower__low_thresh = 499;

static const long Line_follower__high_thresh = 500;

static const long Line_follower__higher_thresh = 800;

static const long Line_follower__obstacle_ahead_thresh = 3;

#endif // LINE_FOLLOWER_TYPES_H
