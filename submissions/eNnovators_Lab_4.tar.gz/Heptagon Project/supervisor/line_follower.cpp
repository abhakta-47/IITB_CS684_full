/* --- Generated the 28/3/2025 at 10:28 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. mar. 8 9:40:4 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "line_follower.h"

void Line_follower__calPidError_reset(Line_follower__calPidError_mem* self) {
  self->v_9 = true;
  self->v_5 = true;
  self->v = true;
}

void Line_follower__calPidError_step(long value, long scale_down,
                                     Line_follower__calPidError_out* _out,
                                     Line_follower__calPidError_mem* self) {
  
  long v_16;
  long v_15;
  long v_14;
  long v_13;
  long v_12;
  long v_11;
  long v_8;
  long v_7;
  long v_4;
  long v_3;
  long v_2;
  long p;
  long i;
  long d;
  if (self->v_9) {
    v_11 = 0;
  } else {
    v_11 = self->v_10;
  };
  d = (value-v_11);
  v_15 = (Line_follower__kd*d);
  v_7 = (self->v_6+value);
  if (self->v_5) {
    v_8 = 0;
  } else {
    v_8 = v_7;
  };
  v_2 = (self->v_1+value);
  if (self->v) {
    v_3 = 0;
  } else {
    v_3 = v_2;
  };
  v_4 = (v_3<=Line_follower__max_i);
  if (v_4) {
    i = v_8;
  } else {
    i = 200000000;
  };
  v_13 = (Line_follower__ki*i);
  p = value;
  v_12 = (Line_follower__kp*p);
  v_14 = (v_12+v_13);
  v_16 = (v_14+v_15);
  _out->pid_error = (v_16/scale_down);
  self->v_10 = value;
  self->v_9 = false;
  self->v_6 = i;
  self->v_5 = false;
  self->v_1 = i;
  self->v = false;;
}

void Line_follower__weightedSum_step(long sen_value, long sen_weight,
                                     long prev_sum,
                                     Line_follower__weightedSum_out* _out) {
  
  long v;
  v = (sen_value*sen_weight);
  _out->weighted_sum = (prev_sum+v);;
}

void Line_follower__senWeightedAvg_step(long sen[5],
                                        Line_follower__senWeightedAvg_out* _out) {
  Line_follower__weightedSum_out Line_follower__weightedSum_out_st;
  
  long v_19;
  long v_18;
  long v_17;
  long v;
  long aritmetic_sum;
  v_19 = 0;
  {
    long i_5;
    for (i_5 = 0; i_5 < 5; ++i_5) {
      Line_follower__weightedSum_step(sen[i_5],
                                      Line_follower__sensor_weights[i_5],
                                      v_19,
                                      &Line_follower__weightedSum_out_st);
      v_19 = Line_follower__weightedSum_out_st.weighted_sum;
    }
  };
  v_17 = sen[2];
  v = 0;
  {
    long i;
    for (i = 0; i < 5; ++i) {
      v = (sen[i]+v);
    }
  };
  aritmetic_sum = (v-v_17);
  v_18 = (aritmetic_sum==0);
  if (v_18) {
    _out->sensor_avg = 0;
  } else {
    _out->sensor_avg = v_19;
  };;
}

void Line_follower__safe_motor_update_step(long cur_speed, long change,
                                           Line_follower__safe_motor_update_out* _out) {
  
  long v_24;
  long v_23;
  long v_22;
  long v_21;
  long v_20;
  long v;
  v_23 = (cur_speed+change);
  v_21 = (cur_speed+change);
  v_22 = (v_21<0);
  if (v_22) {
    v_24 = 0;
  } else {
    v_24 = v_23;
  };
  v = (cur_speed+change);
  v_20 = (v>100);
  if (v_20) {
    _out->new_speed = 100;
  } else {
    _out->new_speed = v_24;
  };;
}

void Line_follower__normalize_value_step(long min_val, long max_val, long value,
                                         Line_follower__normalize_value_out* _out) {
  
  long v_29;
  long v_28;
  long v_27;
  long v_26;
  long v_25;
  long v;
  long safe_val;
  v_29 = (max_val-min_val);
  v_25 = (value<=min_val);
  if (v_25) {
    v_26 = min_val;
  } else {
    v_26 = value;
  };
  v = (value>=max_val);
  if (v) {
    safe_val = max_val;
  } else {
    safe_val = v_26;
  };
  v_27 = (safe_val-min_val);
  v_28 = (v_27*1000);
  _out->norm_val = (v_28/v_29);;
}

void Line_follower__updateMins_step(long cur_val, long cur_min,
                                    Line_follower__updateMins_out* _out) {
  
  long v_32;
  long v_31;
  long v_30;
  long v;
  v_31 = (cur_val<cur_min);
  v = (cur_val==0);
  v_30 = !(v);
  v_32 = (v_30&&v_31);
  if (v_32) {
    _out->new_min = cur_val;
  } else {
    _out->new_min = cur_min;
  };;
}

void Line_follower__updateMaxs_step(long cur_val, long cur_max,
                                    Line_follower__updateMaxs_out* _out) {
  
  long v;
  v = (cur_val>cur_max);
  if (v) {
    _out->new_max = cur_val;
  } else {
    _out->new_max = cur_max;
  };;
}

void Line_follower__abs_step(long input, Line_follower__abs_out* _out) {
  
  long v_33;
  long v;
  v_33 = (-1*input);
  v = (input>=0);
  if (v) {
    _out->out = input;
  } else {
    _out->out = v_33;
  };;
}

void Line_follower__main_reset(Line_follower__main_mem* self) {
  {
    long i_4;
    for (i_4 = 0; i_4 < 5; ++i_4) {
    }
  };
  Line_follower__calPidError_reset(&self->calPidError_1);
  Line_follower__calPidError_reset(&self->calPidError);
  {
    long i_3;
    for (i_3 = 0; i_3 < 5; ++i_3) {
    }
  };
  {
    long i_2;
    for (i_2 = 0; i_2 < 5; ++i_2) {
    }
  };
  self->v_374 = true;
  self->v_372 = false;
  self->v_331 = Line_follower__St_PID;
  self->v_300 = false;
  self->v_267 = Line_follower__St_2_PID;
  self->v_265 = false;
  self->v_240 = Line_follower__St_3_Wait;
  self->v_204 = true;
  self->v_200 = true;
  self->inx_counter_1 = 0;
  self->sen_2[0] = 0;
  self->sen_2[1] = 0;
  self->sen_2[2] = 0;
  self->sen_2[3] = 0;
  self->sen_2[4] = 0;
  self->min_vals_1[0] = 350;
  self->min_vals_1[1] = 360;
  self->min_vals_1[2] = 340;
  self->min_vals_1[3] = 750;
  self->min_vals_1[4] = 400;
  self->max_vals_1[0] = 800;
  self->max_vals_1[1] = 850;
  self->max_vals_1[2] = 830;
  self->max_vals_1[3] = 960;
  self->max_vals_1[4] = 710;
  self->last_error_1 = 0;
  self->pid_error_3 = 0;
  self->pnr_4 = false;
  self->ck = Line_follower__St_4_Calibrate;
  self->v_277 = false;
  self->v_275 = Line_follower__St_1_Counter;
  self->v_259 = true;
  self->v_248 = true;
  self->v_241 = true;
}

void Line_follower__main_step(long sen0, long sen1, long sen2, long sen3,
                              long sen4, long ir_value, long obs_left,
                              long obs_right, Line_follower__main_out* _out,
                              Line_follower__main_mem* self) {
  Line_follower__normalize_value_out Line_follower__normalize_value_out_st;
  Line_follower__updateMaxs_out Line_follower__updateMaxs_out_st;
  Line_follower__safe_motor_update_out Line_follower__safe_motor_update_out_st;
  Line_follower__abs_out Line_follower__abs_out_st;
  Line_follower__calPidError_out Line_follower__calPidError_out_st;
  Line_follower__updateMins_out Line_follower__updateMins_out_st;
  Line_follower__senWeightedAvg_out Line_follower__senWeightedAvg_out_st;
  
  long v_184;
  long v_183;
  long v_199;
  long v_198;
  long v_197;
  long v_196;
  long v_195;
  long v_194;
  long v_193;
  long v_192;
  long v_191;
  long v_190;
  long v_189;
  long v_188;
  long v_187;
  long v_186;
  long v_185;
  long r_4_St_4_Stop;
  Line_follower__st_4 s_4_St_4_Stop;
  long r_4_St_4_ObstacleAvoid;
  Line_follower__st_4 s_4_St_4_ObstacleAvoid;
  long r_4_St_4_BonW;
  Line_follower__st_4 s_4_St_4_BonW;
  long r_4_St_4_Transition;
  Line_follower__st_4 s_4_St_4_Transition;
  long r_4_St_4_WonB;
  Line_follower__st_4 s_4_St_4_WonB;
  long r_4_St_4_Start;
  Line_follower__st_4 s_4_St_4_Start;
  long r_4_St_4_Idle;
  Line_follower__st_4 s_4_St_4_Idle;
  long r_4_St_4_Calibrate;
  Line_follower__st_4 s_4_St_4_Calibrate;
  long v_224;
  Line_follower__st_3 v_223;
  long v_222;
  long v_221;
  long v_220;
  long v_219;
  long v_218;
  long v_217;
  long v_216;
  long v_215;
  long v_214;
  long v_213;
  long v_212;
  long v_211;
  long v_210;
  long v_230;
  Line_follower__st_3 v_229;
  long v_228;
  Line_follower__st_3 v_227;
  long v_226;
  long v_225;
  long v_237;
  Line_follower__st_3 v_236;
  long v_235;
  Line_follower__st_3 v_234;
  long v_233;
  long v_232;
  long v_231;
  long v_239;
  Line_follower__st_3 v_238;
  long r_3_St_3_ExitEnd2;
  Line_follower__st_3 s_3_St_3_ExitEnd2;
  long r_3_St_3_ExitEnd1;
  Line_follower__st_3 s_3_St_3_ExitEnd1;
  long r_3_St_3_ExitStart;
  Line_follower__st_3 s_3_St_3_ExitStart;
  long r_3_St_3_SlightLeft;
  Line_follower__st_3 s_3_St_3_SlightLeft;
  long r_3_St_3_SlightRight;
  Line_follower__st_3 s_3_St_3_SlightRight;
  long r_3_St_3_FullRight;
  Line_follower__st_3 s_3_St_3_FullRight;
  long r_3_St_3_Wait;
  Line_follower__st_3 s_3_St_3_Wait;
  Line_follower__st_3 ck_7;
  long v_257;
  long v_256;
  long v_255;
  long v_254;
  long v_253;
  long v_252;
  long v_250;
  long v_249;
  long v_247;
  long v_246;
  long v_245;
  long v_243;
  long v_242;
  long sen_1_low1;
  long sen_1_high1;
  long v_264;
  long v_263;
  long v_261;
  long v_260;
  long v_258;
  long ncycles_1;
  long nr_3_St_3_ExitEnd2;
  Line_follower__st_3 ns_3_St_3_ExitEnd2;
  long complete_1_St_3_ExitEnd2;
  long dir_St_4_ObstacleAvoid_St_3_ExitEnd2;
  long v_r_St_4_ObstacleAvoid_St_3_ExitEnd2;
  long v_l_St_4_ObstacleAvoid_St_3_ExitEnd2;
  long nr_3_St_3_ExitEnd1;
  Line_follower__st_3 ns_3_St_3_ExitEnd1;
  long complete_1_St_3_ExitEnd1;
  long dir_St_4_ObstacleAvoid_St_3_ExitEnd1;
  long v_r_St_4_ObstacleAvoid_St_3_ExitEnd1;
  long v_l_St_4_ObstacleAvoid_St_3_ExitEnd1;
  long nr_3_St_3_ExitStart;
  Line_follower__st_3 ns_3_St_3_ExitStart;
  long complete_1_St_3_ExitStart;
  long dir_St_4_ObstacleAvoid_St_3_ExitStart;
  long v_r_St_4_ObstacleAvoid_St_3_ExitStart;
  long v_l_St_4_ObstacleAvoid_St_3_ExitStart;
  long nr_3_St_3_SlightLeft;
  Line_follower__st_3 ns_3_St_3_SlightLeft;
  long complete_1_St_3_SlightLeft;
  long dir_St_4_ObstacleAvoid_St_3_SlightLeft;
  long v_r_St_4_ObstacleAvoid_St_3_SlightLeft;
  long v_l_St_4_ObstacleAvoid_St_3_SlightLeft;
  long nr_3_St_3_SlightRight;
  Line_follower__st_3 ns_3_St_3_SlightRight;
  long complete_1_St_3_SlightRight;
  long dir_St_4_ObstacleAvoid_St_3_SlightRight;
  long v_r_St_4_ObstacleAvoid_St_3_SlightRight;
  long v_l_St_4_ObstacleAvoid_St_3_SlightRight;
  long nr_3_St_3_FullRight;
  Line_follower__st_3 ns_3_St_3_FullRight;
  long complete_1_St_3_FullRight;
  long dir_St_4_ObstacleAvoid_St_3_FullRight;
  long v_r_St_4_ObstacleAvoid_St_3_FullRight;
  long v_l_St_4_ObstacleAvoid_St_3_FullRight;
  long nr_3_St_3_Wait;
  Line_follower__st_3 ns_3_St_3_Wait;
  long complete_1_St_3_Wait;
  long dir_St_4_ObstacleAvoid_St_3_Wait;
  long v_r_St_4_ObstacleAvoid_St_3_Wait;
  long v_l_St_4_ObstacleAvoid_St_3_Wait;
  Line_follower__st_3 ck_8;
  long v_209;
  long v_208;
  long v_207;
  long v_205;
  long v_203;
  long v_201;
  Line_follower__st_3 s_3;
  Line_follower__st_3 ns_3;
  long r_3;
  long nr_3;
  long pnr_3;
  long complete_1;
  long white_happened;
  long black_happend;
  long r_2_St_2_Intersection;
  Line_follower__st_2 s_2_St_2_Intersection;
  long r_2_St_2_PID;
  Line_follower__st_2 s_2_St_2_PID;
  Line_follower__st_2 ck_4;
  long v_268;
  long v_273;
  Line_follower__st_1 v_272;
  long v_271;
  long v_270;
  long v_269;
  long v_274;
  long nr_1_St_1_ExitLeft;
  Line_follower__st_1 ns_1_St_1_ExitLeft;
  long complete_St_1_ExitLeft;
  long inx_counter_St_4_BonW_St_2_Intersection_St_1_ExitLeft;
  long dir_St_4_BonW_St_2_Intersection_St_1_ExitLeft;
  long v_r_St_4_BonW_St_2_Intersection_St_1_ExitLeft;
  long v_l_St_4_BonW_St_2_Intersection_St_1_ExitLeft;
  long nr_1_St_1_ExitRight;
  Line_follower__st_1 ns_1_St_1_ExitRight;
  long complete_St_1_ExitRight;
  long inx_counter_St_4_BonW_St_2_Intersection_St_1_ExitRight;
  long dir_St_4_BonW_St_2_Intersection_St_1_ExitRight;
  long v_r_St_4_BonW_St_2_Intersection_St_1_ExitRight;
  long v_l_St_4_BonW_St_2_Intersection_St_1_ExitRight;
  long nr_1_St_1_Entry;
  Line_follower__st_1 ns_1_St_1_Entry;
  long complete_St_1_Entry;
  long inx_counter_St_4_BonW_St_2_Intersection_St_1_Entry;
  long dir_St_4_BonW_St_2_Intersection_St_1_Entry;
  long v_r_St_4_BonW_St_2_Intersection_St_1_Entry;
  long v_l_St_4_BonW_St_2_Intersection_St_1_Entry;
  long nr_1_St_1_Counter;
  Line_follower__st_1 ns_1_St_1_Counter;
  long complete_St_1_Counter;
  long inx_counter_St_4_BonW_St_2_Intersection_St_1_Counter;
  long dir_St_4_BonW_St_2_Intersection_St_1_Counter;
  long v_r_St_4_BonW_St_2_Intersection_St_1_Counter;
  long v_l_St_4_BonW_St_2_Intersection_St_1_Counter;
  Line_follower__st_1 ck_6;
  long v_276;
  Line_follower__st_1 ns_1;
  long r_1;
  long nr_1;
  long pnr_1;
  long complete;
  long v_299;
  long v_298;
  long v_297;
  long v_296;
  long v_295;
  long v_294;
  long v_293;
  long v_292;
  long v_291;
  long v_290;
  long v_289;
  long v_288;
  long v_287;
  long v_286;
  long v_285;
  long v_284;
  long v_283;
  long v_282;
  long v_281;
  long v_280;
  long v_279;
  long v_278;
  long sharp_thresh_1;
  long nr_2_St_2_Intersection;
  Line_follower__st_2 ns_2_St_2_Intersection;
  long inx_counter_St_4_BonW_St_2_Intersection;
  long last_error_St_4_BonW_St_2_Intersection;
  long dir_St_4_BonW_St_2_Intersection;
  long v_r_St_4_BonW_St_2_Intersection;
  long v_l_St_4_BonW_St_2_Intersection;
  long nr_2_St_2_PID;
  Line_follower__st_2 ns_2_St_2_PID;
  long inx_counter_St_4_BonW_St_2_PID;
  long last_error_St_4_BonW_St_2_PID;
  long dir_St_4_BonW_St_2_PID;
  long v_r_St_4_BonW_St_2_PID;
  long v_l_St_4_BonW_St_2_PID;
  Line_follower__st_2 ck_5;
  long v_266;
  long r_5;
  Line_follower__st_2 s_2;
  Line_follower__st_2 ns_2;
  long r_2;
  long nr_2;
  long pnr_2;
  long v_302;
  long v_301;
  long v_330;
  long v_329;
  long v_328;
  long v_327;
  long v_326;
  long v_325;
  long v_324;
  long v_323;
  long v_322;
  long v_321;
  long v_320;
  long v_319;
  long v_318;
  long v_317;
  long r_St_Recovery;
  Line_follower__st s_St_Recovery;
  long r_St_PID;
  Line_follower__st s_St_PID;
  Line_follower__st ck_2;
  long v_349;
  long v_348;
  long v_347;
  long v_346;
  long v_345;
  long v_344;
  long v_343;
  long v_342;
  long v_341;
  long v_340;
  long v_339;
  long v_338;
  long v_337;
  long v_336;
  long v_335;
  long v_334;
  long v_333;
  long v_332;
  long v_371;
  long v_370;
  long v_369;
  long v_368;
  long v_367;
  long v_366;
  long v_365;
  long v_364;
  long v_363;
  long v_362;
  long v_361;
  long v_360;
  long v_359;
  long v_358;
  long v_357;
  long v_356;
  long v_355;
  long v_354;
  long v_353;
  long v_352;
  long v_351;
  long v_350;
  long sharp_thresh;
  long nr_St_Recovery;
  Line_follower__st ns_St_Recovery;
  long last_error_St_4_WonB_St_Recovery;
  long dir_St_4_WonB_St_Recovery;
  long v_r_St_4_WonB_St_Recovery;
  long v_l_St_4_WonB_St_Recovery;
  long nr_St_PID;
  Line_follower__st ns_St_PID;
  long last_error_St_4_WonB_St_PID;
  long dir_St_4_WonB_St_PID;
  long v_r_St_4_WonB_St_PID;
  long v_l_St_4_WonB_St_PID;
  Line_follower__st ck_3;
  long v_316;
  long v_315;
  long v_314;
  long v_313;
  long v_312;
  long v_311;
  long v_310;
  long v_309;
  long v_308;
  long v_307;
  long v_306;
  long v_305;
  long v_304;
  long v_303;
  long r_6;
  Line_follower__st s;
  Line_follower__st ns;
  long r;
  long nr;
  long pnr;
  long v_373;
  long v_377;
  long v_375;
  long ncycles;
  long nr_4_St_4_Stop;
  Line_follower__st_4 ns_4_St_4_Stop;
  long inx_counter_St_4_Stop;
  long min_vals_St_4_Stop[5];
  long max_vals_St_4_Stop[5];
  long last_error_St_4_Stop;
  long pid_error_St_4_Stop;
  long dir_St_4_Stop;
  long v_r_St_4_Stop;
  long v_l_St_4_Stop;
  long nr_4_St_4_ObstacleAvoid;
  Line_follower__st_4 ns_4_St_4_ObstacleAvoid;
  long inx_counter_St_4_ObstacleAvoid;
  long min_vals_St_4_ObstacleAvoid[5];
  long max_vals_St_4_ObstacleAvoid[5];
  long last_error_St_4_ObstacleAvoid;
  long pid_error_St_4_ObstacleAvoid;
  long dir_St_4_ObstacleAvoid;
  long v_r_St_4_ObstacleAvoid;
  long v_l_St_4_ObstacleAvoid;
  long nr_4_St_4_BonW;
  Line_follower__st_4 ns_4_St_4_BonW;
  long inx_counter_St_4_BonW;
  long min_vals_St_4_BonW[5];
  long max_vals_St_4_BonW[5];
  long last_error_St_4_BonW;
  long pid_error_St_4_BonW;
  long dir_St_4_BonW;
  long v_r_St_4_BonW;
  long v_l_St_4_BonW;
  long nr_4_St_4_Transition;
  Line_follower__st_4 ns_4_St_4_Transition;
  long inx_counter_St_4_Transition;
  long min_vals_St_4_Transition[5];
  long max_vals_St_4_Transition[5];
  long last_error_St_4_Transition;
  long pid_error_St_4_Transition;
  long dir_St_4_Transition;
  long v_r_St_4_Transition;
  long v_l_St_4_Transition;
  long nr_4_St_4_WonB;
  Line_follower__st_4 ns_4_St_4_WonB;
  long inx_counter_St_4_WonB;
  long min_vals_St_4_WonB[5];
  long max_vals_St_4_WonB[5];
  long last_error_St_4_WonB;
  long pid_error_St_4_WonB;
  long dir_St_4_WonB;
  long v_r_St_4_WonB;
  long v_l_St_4_WonB;
  long nr_4_St_4_Start;
  Line_follower__st_4 ns_4_St_4_Start;
  long inx_counter_St_4_Start;
  long min_vals_St_4_Start[5];
  long max_vals_St_4_Start[5];
  long last_error_St_4_Start;
  long pid_error_St_4_Start;
  long dir_St_4_Start;
  long v_r_St_4_Start;
  long v_l_St_4_Start;
  long nr_4_St_4_Idle;
  Line_follower__st_4 ns_4_St_4_Idle;
  long inx_counter_St_4_Idle;
  long min_vals_St_4_Idle[5];
  long max_vals_St_4_Idle[5];
  long last_error_St_4_Idle;
  long pid_error_St_4_Idle;
  long dir_St_4_Idle;
  long v_r_St_4_Idle;
  long v_l_St_4_Idle;
  long nr_4_St_4_Calibrate;
  Line_follower__st_4 ns_4_St_4_Calibrate;
  long inx_counter_St_4_Calibrate;
  long min_vals_St_4_Calibrate[5];
  long max_vals_St_4_Calibrate[5];
  long last_error_St_4_Calibrate;
  long pid_error_St_4_Calibrate;
  long dir_St_4_Calibrate;
  long v_r_St_4_Calibrate;
  long v_l_St_4_Calibrate;
  Line_follower__st_4 ck_1;
  long v_182;
  long v_181;
  long v_180;
  long v_179;
  long v_178;
  long v_177;
  long v_176;
  long v_175;
  long v_174;
  long v_173;
  long v_172;
  long v_171;
  long v_170;
  long v_169;
  long v_168;
  long v_167;
  long v_166;
  long v_165;
  long v_164;
  long v_163;
  long v_162;
  long v_161;
  long v_160;
  long v_159;
  long v_158;
  long v_157;
  long v_156;
  long v_155;
  long v_154;
  long v_153;
  long v_152;
  long v_151;
  long v_150;
  long v_149;
  long v_148;
  long v_147;
  long v_146;
  long v_145;
  long v_144;
  long v_143;
  long v_142;
  long v_141;
  long v_140;
  long v_139;
  long v_138;
  long v_137;
  long v_136;
  long v_135;
  long v_134;
  long v_133;
  long v_132;
  long v_131;
  long v_130;
  long v_129;
  long v_128;
  long v_127;
  long v_126;
  long v_125;
  long v_124;
  long v_123;
  long v_122;
  long v_121;
  long v_120;
  long v_119;
  long v_118;
  long v_117;
  long v_116;
  long v_115;
  long v_114;
  long v_113;
  long v_112;
  long v_111;
  long v_110;
  long v_109;
  long v_108;
  long v_107;
  long v_106;
  long v_105;
  long v_104;
  long v_103;
  long v_102;
  long v_101;
  long v_100;
  long v_99;
  long v_98;
  long v_97;
  long v_96;
  long v_95;
  long v_94;
  long v_93;
  long v_92;
  long v_91;
  long v_90;
  long v_89;
  long v_88;
  long v_87;
  long v_86;
  long v_85;
  long v_84;
  long v_83;
  long v_82;
  long v_81;
  long v_80;
  long v_79;
  long v_78;
  long v_77;
  long v_76;
  long v_75;
  long v_74;
  long v_73;
  long v_72;
  long v_71;
  long v_70;
  long v_69;
  long v_68;
  long v_67;
  long v_66;
  long v_65;
  long v_64;
  long v_63;
  long v_62;
  long v_61;
  long v_60;
  long v_59;
  long v_58;
  long v_57;
  long v_56;
  long v_55;
  long v_54;
  long v_53;
  long v_52;
  long v_51;
  long v_50;
  long v_49;
  long v_48;
  long v_47;
  long v_46;
  long v_45;
  long v_44;
  long v_43;
  long v_42;
  long v_41;
  long v_40;
  long v_39;
  long v_38;
  long v_37;
  long v_36;
  long v_35;
  long v_34;
  long v;
  Line_follower__st_4 s_4;
  Line_follower__st_4 ns_4;
  long r_4;
  long nr_4;
  long raw_sen[5];
  long sensor_avg;
  long all_low;
  long all_high;
  long all_very_high;
  long only_middle_low;
  long inx_cond;
  long only_one_low;
  long pid_error;
  long last_error;
  long max_vals[5];
  long min_vals[5];
  long sen[5];
  long inx_counter;
  switch (self->ck) {
    case Line_follower__St_4_Calibrate:
      r_4_St_4_Calibrate = self->pnr_4;
      s_4_St_4_Calibrate = Line_follower__St_4_Calibrate;
      break;
    case Line_follower__St_4_Start:
      r_4_St_4_Start = self->pnr_4;
      s_4_St_4_Start = Line_follower__St_4_Start;
      break;
    case Line_follower__St_4_WonB:
      r_4_St_4_WonB = self->pnr_4;
      s_4_St_4_WonB = Line_follower__St_4_WonB;
      break;
    case Line_follower__St_4_BonW:
      v_183 = (ir_value==0);
      v_184 = !(v_183);
      if (v_184) {
        r_4_St_4_BonW = true;
        s_4_St_4_BonW = Line_follower__St_4_ObstacleAvoid;
      } else {
        r_4_St_4_BonW = self->pnr_4;
        s_4_St_4_BonW = Line_follower__St_4_BonW;
      };
      break;
    case Line_follower__St_4_ObstacleAvoid:
      r_4_St_4_ObstacleAvoid = self->pnr_4;
      s_4_St_4_ObstacleAvoid = Line_follower__St_4_ObstacleAvoid;
      break;
    case Line_follower__St_4_Stop:
      r_4_St_4_Stop = self->pnr_4;
      s_4_St_4_Stop = Line_follower__St_4_Stop;
      break;
    default:
      break;
  };
  raw_sen[0] = sen0;
  raw_sen[1] = sen1;
  raw_sen[2] = sen2;
  raw_sen[3] = sen3;
  raw_sen[4] = sen4;
  {
    long i_4;
    for (i_4 = 0; i_4 < 5; ++i_4) {
      Line_follower__normalize_value_step(self->min_vals_1[i_4],
                                          self->max_vals_1[i_4],
                                          raw_sen[i_4],
                                          &Line_follower__normalize_value_out_st);
      sen[i_4] = Line_follower__normalize_value_out_st.norm_val;
    }
  };
  v_180 = sen[3];
  v_181 = (v_180>=Line_follower__high_thresh);
  v_177 = sen[2];
  v_178 = (v_177>=Line_follower__high_thresh);
  v_174 = sen[1];
  v_175 = (v_174>=Line_follower__high_thresh);
  v_171 = sen[0];
  v_172 = (v_171>=Line_follower__high_thresh);
  v_169 = sen[4];
  v_170 = (v_169<=Line_follower__low_thresh);
  v_173 = (v_170&&v_172);
  v_176 = (v_173&&v_175);
  v_179 = (v_176&&v_178);
  v_182 = (v_179&&v_181);
  v_165 = sen[4];
  v_166 = (v_165>=Line_follower__high_thresh);
  v_162 = sen[2];
  v_163 = (v_162>=Line_follower__high_thresh);
  v_159 = sen[1];
  v_160 = (v_159>=Line_follower__high_thresh);
  v_156 = sen[0];
  v_157 = (v_156>=Line_follower__high_thresh);
  v_154 = sen[3];
  v_155 = (v_154<=Line_follower__low_thresh);
  v_158 = (v_155&&v_157);
  v_161 = (v_158&&v_160);
  v_164 = (v_161&&v_163);
  v_167 = (v_164&&v_166);
  v_150 = sen[4];
  v_151 = (v_150>=Line_follower__high_thresh);
  v_147 = sen[3];
  v_148 = (v_147>=Line_follower__high_thresh);
  v_144 = sen[1];
  v_145 = (v_144>=Line_follower__high_thresh);
  v_141 = sen[0];
  v_142 = (v_141>=Line_follower__high_thresh);
  v_139 = sen[2];
  v_140 = (v_139<=Line_follower__low_thresh);
  v_143 = (v_140&&v_142);
  v_146 = (v_143&&v_145);
  v_149 = (v_146&&v_148);
  v_152 = (v_149&&v_151);
  v_135 = sen[4];
  v_136 = (v_135>=Line_follower__high_thresh);
  v_132 = sen[3];
  v_133 = (v_132>=Line_follower__high_thresh);
  v_129 = sen[2];
  v_130 = (v_129>=Line_follower__high_thresh);
  v_126 = sen[0];
  v_127 = (v_126>=Line_follower__high_thresh);
  v_124 = sen[1];
  v_125 = (v_124<=Line_follower__low_thresh);
  v_128 = (v_125&&v_127);
  v_131 = (v_128&&v_130);
  v_134 = (v_131&&v_133);
  v_137 = (v_134&&v_136);
  v_121 = sen[4];
  v_122 = (v_121>=Line_follower__high_thresh);
  v_118 = sen[3];
  v_119 = (v_118>=Line_follower__high_thresh);
  v_115 = sen[2];
  v_116 = (v_115>=Line_follower__high_thresh);
  v_112 = sen[1];
  v_113 = (v_112>=Line_follower__high_thresh);
  v_110 = sen[0];
  v_111 = (v_110<=Line_follower__low_thresh);
  v_114 = (v_111&&v_113);
  v_117 = (v_114&&v_116);
  v_120 = (v_117&&v_119);
  v_123 = (v_120&&v_122);
  v_138 = (v_123||v_137);
  v_153 = (v_138||v_152);
  v_168 = (v_153||v_167);
  only_one_low = (v_168||v_182);
  v_107 = sen[2];
  v_108 = (v_107<=Line_follower__low_thresh);
  v_104 = sen[3];
  v_105 = (v_104<=Line_follower__low_thresh);
  v_102 = sen[4];
  v_103 = (v_102<=Line_follower__low_thresh);
  v_106 = (v_103&&v_105);
  v_109 = (v_106&&v_108);
  v_98 = sen[2];
  v_99 = (v_98<=Line_follower__low_thresh);
  v_95 = sen[1];
  v_96 = (v_95<=Line_follower__low_thresh);
  v_93 = sen[3];
  v_94 = (v_93<=Line_follower__low_thresh);
  v_97 = (v_94&&v_96);
  v_100 = (v_97&&v_99);
  v_90 = sen[2];
  v_91 = (v_90<=Line_follower__low_thresh);
  v_87 = sen[1];
  v_88 = (v_87<=Line_follower__low_thresh);
  v_85 = sen[0];
  v_86 = (v_85<=Line_follower__low_thresh);
  v_89 = (v_86&&v_88);
  v_92 = (v_89&&v_91);
  v_101 = (v_92||v_100);
  inx_cond = (v_101||v_109);
  v_83 = sen[4];
  v_84 = (v_83>=Line_follower__high_thresh);
  v_80 = sen[3];
  v_81 = (v_80>=Line_follower__high_thresh);
  v_77 = sen[2];
  v_78 = (v_77<=Line_follower__low_thresh);
  v_74 = sen[1];
  v_75 = (v_74>=Line_follower__high_thresh);
  v_72 = sen[0];
  v_73 = (v_72>=Line_follower__high_thresh);
  v_76 = (v_73&&v_75);
  v_79 = (v_76&&v_78);
  v_82 = (v_79&&v_81);
  only_middle_low = (v_82&&v_84);
  v_70 = sen[4];
  v_71 = (v_70>=Line_follower__higher_thresh);
  v_67 = sen[3];
  v_68 = (v_67>=Line_follower__higher_thresh);
  v_64 = sen[2];
  v_65 = (v_64>=Line_follower__higher_thresh);
  v_61 = sen[1];
  v_62 = (v_61>=Line_follower__higher_thresh);
  v_59 = sen[0];
  v_60 = (v_59>=Line_follower__higher_thresh);
  v_63 = (v_60&&v_62);
  v_66 = (v_63&&v_65);
  v_69 = (v_66&&v_68);
  all_very_high = (v_69&&v_71);
  v_57 = sen[4];
  v_58 = (v_57>=Line_follower__high_thresh);
  v_54 = sen[3];
  v_55 = (v_54>=Line_follower__high_thresh);
  v_51 = sen[2];
  v_52 = (v_51>=Line_follower__high_thresh);
  v_48 = sen[1];
  v_49 = (v_48>=Line_follower__high_thresh);
  v_46 = sen[0];
  v_47 = (v_46>=Line_follower__high_thresh);
  v_50 = (v_47&&v_49);
  v_53 = (v_50&&v_52);
  v_56 = (v_53&&v_55);
  all_high = (v_56&&v_58);
  v_44 = sen[4];
  v_45 = (v_44<=Line_follower__low_thresh);
  v_41 = sen[3];
  v_42 = (v_41<=Line_follower__low_thresh);
  v_38 = sen[2];
  v_39 = (v_38<=Line_follower__low_thresh);
  v_35 = sen[1];
  v_36 = (v_35<=Line_follower__low_thresh);
  v = sen[0];
  v_34 = (v<=Line_follower__low_thresh);
  v_37 = (v_34&&v_36);
  v_40 = (v_37&&v_39);
  v_43 = (v_40&&v_42);
  all_low = (v_43&&v_45);
  Line_follower__senWeightedAvg_step(sen,
                                     &Line_follower__senWeightedAvg_out_st);
  sensor_avg = Line_follower__senWeightedAvg_out_st.sensor_avg;
  switch (self->ck) {
    case Line_follower__St_4_Idle:
      if (all_high) {
        r_4_St_4_Idle = true;
        s_4_St_4_Idle = Line_follower__St_4_Start;
      } else {
        r_4_St_4_Idle = self->pnr_4;
        s_4_St_4_Idle = Line_follower__St_4_Idle;
      };
      s_4 = s_4_St_4_Idle;
      r_4 = r_4_St_4_Idle;
      break;
    case Line_follower__St_4_Transition:
      v_196 = sen[4];
      v_197 = (v_196>=Line_follower__high_thresh);
      v_193 = sen[3];
      v_194 = (v_193>=Line_follower__high_thresh);
      v_190 = sen[2];
      v_191 = (v_190>=Line_follower__high_thresh);
      v_187 = sen[1];
      v_188 = (v_187>=Line_follower__high_thresh);
      v_185 = sen[0];
      v_186 = (v_185>=Line_follower__high_thresh);
      v_189 = (v_186&&v_188);
      v_192 = (v_189&&v_191);
      v_195 = (v_192&&v_194);
      v_198 = (v_195&&v_197);
      v_199 = !(v_198);
      if (v_199) {
        r_4_St_4_Transition = true;
        s_4_St_4_Transition = Line_follower__St_4_BonW;
      } else {
        r_4_St_4_Transition = self->pnr_4;
        s_4_St_4_Transition = Line_follower__St_4_Transition;
      };
      s_4 = s_4_St_4_Transition;
      r_4 = r_4_St_4_Transition;
      break;
    case Line_follower__St_4_Stop:
      s_4 = s_4_St_4_Stop;
      r_4 = r_4_St_4_Stop;
      break;
    case Line_follower__St_4_ObstacleAvoid:
      s_4 = s_4_St_4_ObstacleAvoid;
      r_4 = r_4_St_4_ObstacleAvoid;
      break;
    case Line_follower__St_4_BonW:
      s_4 = s_4_St_4_BonW;
      r_4 = r_4_St_4_BonW;
      break;
    case Line_follower__St_4_WonB:
      s_4 = s_4_St_4_WonB;
      r_4 = r_4_St_4_WonB;
      break;
    case Line_follower__St_4_Start:
      s_4 = s_4_St_4_Start;
      r_4 = r_4_St_4_Start;
      break;
    case Line_follower__St_4_Calibrate:
      s_4 = s_4_St_4_Calibrate;
      r_4 = r_4_St_4_Calibrate;
      break;
    default:
      break;
  };
  ck_1 = s_4;
  switch (ck_1) {
    case Line_follower__St_4_Calibrate:
      inx_counter_St_4_Calibrate = self->inx_counter_1;
      last_error_St_4_Calibrate = self->last_error_1;
      pid_error_St_4_Calibrate = self->pid_error_3;
      v_377 = (self->v_376+1);
      if (self->v_374) {
        v_375 = true;
      } else {
        v_375 = r_4;
      };
      if (v_375) {
        ncycles = 0;
      } else {
        ncycles = v_377;
      };
      dir_St_4_Calibrate = 3;
      v_r_St_4_Calibrate = 30;
      v_l_St_4_Calibrate = 30;
      nr_4_St_4_Calibrate = false;
      ns_4_St_4_Calibrate = Line_follower__St_4_Calibrate;
      pid_error = pid_error_St_4_Calibrate;
      last_error = last_error_St_4_Calibrate;
      inx_counter = inx_counter_St_4_Calibrate;
      _out->v_l = v_l_St_4_Calibrate;
      _out->v_r = v_r_St_4_Calibrate;
      _out->dir = dir_St_4_Calibrate;
      ns_4 = ns_4_St_4_Calibrate;
      nr_4 = nr_4_St_4_Calibrate;
      {
        long i_3;
        for (i_3 = 0; i_3 < 5; ++i_3) {
          Line_follower__updateMaxs_step(raw_sen[i_3], self->max_vals_1[i_3],
                                         &Line_follower__updateMaxs_out_st);
          max_vals_St_4_Calibrate[i_3] = Line_follower__updateMaxs_out_st.new_max;
        }
      };
      {
        long i_2;
        for (i_2 = 0; i_2 < 5; ++i_2) {
          Line_follower__updateMins_step(raw_sen[i_2], self->min_vals_1[i_2],
                                         &Line_follower__updateMins_out_st);
          min_vals_St_4_Calibrate[i_2] = Line_follower__updateMins_out_st.new_min;
        }
      };
      {
        long _5;
        for (_5 = 0; _5 < 5; ++_5) {
          min_vals[_5] = min_vals_St_4_Calibrate[_5];
        }
      };
      {
        long _6;
        for (_6 = 0; _6 < 5; ++_6) {
          max_vals[_6] = max_vals_St_4_Calibrate[_6];
        }
      };
      self->v_376 = ncycles;
      self->v_374 = false;
      break;
    case Line_follower__St_4_Idle:
      inx_counter_St_4_Idle = self->inx_counter_1;
      last_error_St_4_Idle = self->last_error_1;
      pid_error_St_4_Idle = self->pid_error_3;
      dir_St_4_Idle = 0;
      v_r_St_4_Idle = 0;
      v_l_St_4_Idle = 0;
      nr_4_St_4_Idle = false;
      ns_4_St_4_Idle = Line_follower__St_4_Idle;
      pid_error = pid_error_St_4_Idle;
      last_error = last_error_St_4_Idle;
      inx_counter = inx_counter_St_4_Idle;
      _out->v_l = v_l_St_4_Idle;
      _out->v_r = v_r_St_4_Idle;
      _out->dir = dir_St_4_Idle;
      ns_4 = ns_4_St_4_Idle;
      nr_4 = nr_4_St_4_Idle;
      {
        long _7;
        for (_7 = 0; _7 < 5; ++_7) {
          min_vals_St_4_Idle[_7] = self->min_vals_1[_7];
        }
      };
      {
        long _8;
        for (_8 = 0; _8 < 5; ++_8) {
          max_vals_St_4_Idle[_8] = self->max_vals_1[_8];
        }
      };
      {
        long _9;
        for (_9 = 0; _9 < 5; ++_9) {
          min_vals[_9] = min_vals_St_4_Idle[_9];
        }
      };
      {
        long _10;
        for (_10 = 0; _10 < 5; ++_10) {
          max_vals[_10] = max_vals_St_4_Idle[_10];
        }
      };
      break;
    case Line_follower__St_4_Start:
      inx_counter_St_4_Start = self->inx_counter_1;
      last_error_St_4_Start = self->last_error_1;
      pid_error_St_4_Start = self->pid_error_3;
      dir_St_4_Start = 1;
      v_r_St_4_Start = 50;
      v_l_St_4_Start = 50;
      v_373 = !(all_high);
      if (v_373) {
        nr_4_St_4_Start = true;
        ns_4_St_4_Start = Line_follower__St_4_WonB;
      } else {
        nr_4_St_4_Start = false;
        ns_4_St_4_Start = Line_follower__St_4_Start;
      };
      pid_error = pid_error_St_4_Start;
      last_error = last_error_St_4_Start;
      inx_counter = inx_counter_St_4_Start;
      _out->v_l = v_l_St_4_Start;
      _out->v_r = v_r_St_4_Start;
      _out->dir = dir_St_4_Start;
      ns_4 = ns_4_St_4_Start;
      nr_4 = nr_4_St_4_Start;
      {
        long _11;
        for (_11 = 0; _11 < 5; ++_11) {
          min_vals_St_4_Start[_11] = self->min_vals_1[_11];
        }
      };
      {
        long _12;
        for (_12 = 0; _12 < 5; ++_12) {
          max_vals_St_4_Start[_12] = self->max_vals_1[_12];
        }
      };
      {
        long _13;
        for (_13 = 0; _13 < 5; ++_13) {
          min_vals[_13] = min_vals_St_4_Start[_13];
        }
      };
      {
        long _14;
        for (_14 = 0; _14 < 5; ++_14) {
          max_vals[_14] = max_vals_St_4_Start[_14];
        }
      };
      break;
    case Line_follower__St_4_WonB:
      inx_counter_St_4_WonB = self->inx_counter_1;
      if (r_4) {
        pnr = false;
        ck_2 = Line_follower__St_PID;
      } else {
        pnr = self->v_372;
        ck_2 = self->v_331;
      };
      v_314 = sen[4];
      v_315 = (v_314>=Line_follower__high_thresh);
      v_310 = sen[3];
      v_311 = (v_310<=Line_follower__low_thresh);
      v_307 = sen[2];
      v_308 = (v_307<=Line_follower__low_thresh);
      v_305 = sen[1];
      v_306 = (v_305<=Line_follower__low_thresh);
      v_309 = (v_306||v_308);
      v_312 = (v_309||v_311);
      v_303 = sen[0];
      v_304 = (v_303>=Line_follower__high_thresh);
      v_313 = (v_304&&v_312);
      v_316 = (v_313&&v_315);
      if (v_316) {
        nr_4_St_4_WonB = true;
        ns_4_St_4_WonB = Line_follower__St_4_Transition;
      } else {
        nr_4_St_4_WonB = false;
        ns_4_St_4_WonB = Line_follower__St_4_WonB;
      };
      r_6 = r_4;
      if (r_6) {
        Line_follower__calPidError_reset(&self->calPidError_1);
      };
      Line_follower__calPidError_step(sensor_avg,
                                      Line_follower__kscale_white,
                                      &Line_follower__calPidError_out_st,
                                      &self->calPidError_1);
      pid_error_St_4_WonB = Line_follower__calPidError_out_st.pid_error;
      pid_error = pid_error_St_4_WonB;
      switch (ck_2) {
        case Line_follower__St_PID:
          v_328 = sen[4];
          v_329 = (v_328<=Line_follower__low_thresh);
          v_325 = sen[3];
          v_326 = (v_325<=Line_follower__low_thresh);
          v_322 = sen[2];
          v_323 = (v_322<=Line_follower__low_thresh);
          v_319 = sen[1];
          v_320 = (v_319<=Line_follower__low_thresh);
          v_317 = sen[0];
          v_318 = (v_317<=Line_follower__low_thresh);
          v_321 = (v_318&&v_320);
          v_324 = (v_321&&v_323);
          v_327 = (v_324&&v_326);
          v_330 = (v_327&&v_329);
          if (v_330) {
            r_St_PID = true;
            s_St_PID = Line_follower__St_Recovery;
          } else {
            r_St_PID = pnr;
            s_St_PID = Line_follower__St_PID;
          };
          s = s_St_PID;
          r = r_St_PID;
          break;
        case Line_follower__St_Recovery:
          r_St_Recovery = pnr;
          s_St_Recovery = Line_follower__St_Recovery;
          s = s_St_Recovery;
          r = r_St_Recovery;
          break;
        default:
          break;
      };
      ck_3 = s;
      switch (ck_3) {
        case Line_follower__St_PID:
          v_370 = (pid_error>0);
          if (v_370) {
            v_371 = 1;
          } else {
            v_371 = -1;
          };
          v_369 = (pid_error==0);
          if (v_369) {
            last_error_St_4_WonB_St_PID = self->last_error_1;
          } else {
            last_error_St_4_WonB_St_PID = v_371;
          };
          v_367 = (pid_error>0);
          if (v_367) {
            v_368 = 3;
          } else {
            v_368 = 2;
          };
          Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
          v_365 = Line_follower__abs_out_st.out;
          Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
          v_362 = Line_follower__abs_out_st.out;
          v_363 = (v_362+20);
          Line_follower__safe_motor_update_step(0, v_363,
                                                &Line_follower__safe_motor_update_out_st);
          v_364 = Line_follower__safe_motor_update_out_st.new_speed;
          v_359 = (-1*pid_error);
          v_360 = (v_359/2);
          Line_follower__safe_motor_update_step(Line_follower__base_speed,
                                                v_360,
                                                &Line_follower__safe_motor_update_out_st);
          v_361 = Line_follower__safe_motor_update_out_st.new_speed;
          Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
          v_357 = Line_follower__abs_out_st.out;
          Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
          v_354 = Line_follower__abs_out_st.out;
          v_355 = (v_354+20);
          Line_follower__safe_motor_update_step(0, v_355,
                                                &Line_follower__safe_motor_update_out_st);
          v_356 = Line_follower__safe_motor_update_out_st.new_speed;
          v_352 = (pid_error/2);
          Line_follower__safe_motor_update_step(Line_follower__base_speed,
                                                v_352,
                                                &Line_follower__safe_motor_update_out_st);
          v_353 = Line_follower__safe_motor_update_out_st.new_speed;
          Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
          v_350 = Line_follower__abs_out_st.out;
          sharp_thresh = 40;
          v_366 = (v_365<=sharp_thresh);
          if (v_366) {
            dir_St_4_WonB_St_PID = 1;
          } else {
            dir_St_4_WonB_St_PID = v_368;
          };
          v_358 = (v_357<=sharp_thresh);
          if (v_358) {
            v_r_St_4_WonB_St_PID = v_361;
          } else {
            v_r_St_4_WonB_St_PID = v_364;
          };
          v_351 = (v_350<=sharp_thresh);
          if (v_351) {
            v_l_St_4_WonB_St_PID = v_353;
          } else {
            v_l_St_4_WonB_St_PID = v_356;
          };
          nr_St_PID = false;
          ns_St_PID = Line_follower__St_PID;
          v_l_St_4_WonB = v_l_St_4_WonB_St_PID;
          v_r_St_4_WonB = v_r_St_4_WonB_St_PID;
          last_error_St_4_WonB = last_error_St_4_WonB_St_PID;
          ns = ns_St_PID;
          nr = nr_St_PID;
          break;
        case Line_follower__St_Recovery:
          last_error_St_4_WonB_St_Recovery = self->last_error_1;
          v_r_St_4_WonB_St_Recovery = 70;
          v_l_St_4_WonB_St_Recovery = 70;
          v_343 = sen[4];
          v_344 = (v_343<=Line_follower__low_thresh);
          v_340 = sen[3];
          v_341 = (v_340<=Line_follower__low_thresh);
          v_337 = sen[2];
          v_338 = (v_337<=Line_follower__low_thresh);
          v_334 = sen[1];
          v_335 = (v_334<=Line_follower__low_thresh);
          v_332 = sen[0];
          v_333 = (v_332<=Line_follower__low_thresh);
          v_336 = (v_333&&v_335);
          v_339 = (v_336&&v_338);
          v_342 = (v_339&&v_341);
          v_345 = (v_342&&v_344);
          v_346 = !(v_345);
          if (v_346) {
            nr_St_Recovery = true;
            ns_St_Recovery = Line_follower__St_PID;
          } else {
            nr_St_Recovery = false;
            ns_St_Recovery = Line_follower__St_Recovery;
          };
          v_l_St_4_WonB = v_l_St_4_WonB_St_Recovery;
          v_r_St_4_WonB = v_r_St_4_WonB_St_Recovery;
          last_error_St_4_WonB = last_error_St_4_WonB_St_Recovery;
          ns = ns_St_Recovery;
          nr = nr_St_Recovery;
          break;
        default:
          break;
      };
      last_error = last_error_St_4_WonB;
      inx_counter = inx_counter_St_4_WonB;
      switch (ck_3) {
        case Line_follower__St_Recovery:
          v_348 = (last_error>0);
          if (v_348) {
            v_349 = 3;
          } else {
            v_349 = 2;
          };
          v_347 = (last_error==0);
          if (v_347) {
            dir_St_4_WonB_St_Recovery = 4;
          } else {
            dir_St_4_WonB_St_Recovery = v_349;
          };
          dir_St_4_WonB = dir_St_4_WonB_St_Recovery;
          break;
        case Line_follower__St_PID:
          dir_St_4_WonB = dir_St_4_WonB_St_PID;
          break;
        default:
          break;
      };
      _out->v_l = v_l_St_4_WonB;
      _out->v_r = v_r_St_4_WonB;
      _out->dir = dir_St_4_WonB;
      ns_4 = ns_4_St_4_WonB;
      nr_4 = nr_4_St_4_WonB;
      {
        long _15;
        for (_15 = 0; _15 < 5; ++_15) {
          min_vals_St_4_WonB[_15] = self->min_vals_1[_15];
        }
      };
      {
        long _16;
        for (_16 = 0; _16 < 5; ++_16) {
          max_vals_St_4_WonB[_16] = self->max_vals_1[_16];
        }
      };
      {
        long _17;
        for (_17 = 0; _17 < 5; ++_17) {
          min_vals[_17] = min_vals_St_4_WonB[_17];
        }
      };
      {
        long _18;
        for (_18 = 0; _18 < 5; ++_18) {
          max_vals[_18] = max_vals_St_4_WonB[_18];
        }
      };
      self->v_372 = nr;
      self->v_331 = ns;
      break;
    case Line_follower__St_4_Transition:
      inx_counter_St_4_Transition = self->inx_counter_1;
      last_error_St_4_Transition = self->last_error_1;
      pid_error_St_4_Transition = self->pid_error_3;
      dir_St_4_Transition = 1;
      nr_4_St_4_Transition = false;
      ns_4_St_4_Transition = Line_follower__St_4_Transition;
      pid_error = pid_error_St_4_Transition;
      last_error = last_error_St_4_Transition;
      v_302 = (last_error>0);
      if (v_302) {
        v_r_St_4_Transition = 50;
      } else {
        v_r_St_4_Transition = 10;
      };
      v_301 = (last_error>0);
      if (v_301) {
        v_l_St_4_Transition = 10;
      } else {
        v_l_St_4_Transition = 50;
      };
      inx_counter = inx_counter_St_4_Transition;
      _out->v_l = v_l_St_4_Transition;
      _out->v_r = v_r_St_4_Transition;
      _out->dir = dir_St_4_Transition;
      ns_4 = ns_4_St_4_Transition;
      nr_4 = nr_4_St_4_Transition;
      {
        long _19;
        for (_19 = 0; _19 < 5; ++_19) {
          min_vals_St_4_Transition[_19] = self->min_vals_1[_19];
        }
      };
      {
        long _20;
        for (_20 = 0; _20 < 5; ++_20) {
          max_vals_St_4_Transition[_20] = self->max_vals_1[_20];
        }
      };
      {
        long _21;
        for (_21 = 0; _21 < 5; ++_21) {
          min_vals[_21] = min_vals_St_4_Transition[_21];
        }
      };
      {
        long _22;
        for (_22 = 0; _22 < 5; ++_22) {
          max_vals[_22] = max_vals_St_4_Transition[_22];
        }
      };
      break;
    case Line_follower__St_4_BonW:
      if (r_4) {
        pnr_2 = false;
        ck_4 = Line_follower__St_2_PID;
      } else {
        pnr_2 = self->v_300;
        ck_4 = self->v_267;
      };
      r_5 = r_4;
      if (r_5) {
        Line_follower__calPidError_reset(&self->calPidError);
      };
      Line_follower__calPidError_step(sensor_avg,
                                      Line_follower__kscale_black,
                                      &Line_follower__calPidError_out_st,
                                      &self->calPidError);
      pid_error_St_4_BonW = Line_follower__calPidError_out_st.pid_error;
      pid_error = pid_error_St_4_BonW;
      switch (ck_4) {
        case Line_follower__St_2_PID:
          if (inx_cond) {
            r_2_St_2_PID = true;
            s_2_St_2_PID = Line_follower__St_2_Intersection;
          } else {
            r_2_St_2_PID = pnr_2;
            s_2_St_2_PID = Line_follower__St_2_PID;
          };
          s_2 = s_2_St_2_PID;
          r_2 = r_2_St_2_PID;
          break;
        case Line_follower__St_2_Intersection:
          r_2_St_2_Intersection = pnr_2;
          s_2_St_2_Intersection = Line_follower__St_2_Intersection;
          s_2 = s_2_St_2_Intersection;
          r_2 = r_2_St_2_Intersection;
          break;
        default:
          break;
      };
      ck_5 = s_2;
      switch (ck_5) {
        case Line_follower__St_2_PID:
          inx_counter_St_4_BonW_St_2_PID = self->inx_counter_1;
          v_298 = (pid_error>0);
          if (v_298) {
            v_299 = 1;
          } else {
            v_299 = -1;
          };
          v_297 = (pid_error==0);
          if (v_297) {
            last_error_St_4_BonW_St_2_PID = self->last_error_1;
          } else {
            last_error_St_4_BonW_St_2_PID = v_299;
          };
          v_295 = (pid_error>0);
          if (v_295) {
            v_296 = 3;
          } else {
            v_296 = 2;
          };
          Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
          v_293 = Line_follower__abs_out_st.out;
          Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
          v_290 = Line_follower__abs_out_st.out;
          v_291 = (v_290+20);
          Line_follower__safe_motor_update_step(0, v_291,
                                                &Line_follower__safe_motor_update_out_st);
          v_292 = Line_follower__safe_motor_update_out_st.new_speed;
          v_287 = (-1*pid_error);
          v_288 = (v_287/2);
          Line_follower__safe_motor_update_step(Line_follower__base_speed,
                                                v_288,
                                                &Line_follower__safe_motor_update_out_st);
          v_289 = Line_follower__safe_motor_update_out_st.new_speed;
          Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
          v_285 = Line_follower__abs_out_st.out;
          Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
          v_282 = Line_follower__abs_out_st.out;
          v_283 = (v_282+20);
          Line_follower__safe_motor_update_step(0, v_283,
                                                &Line_follower__safe_motor_update_out_st);
          v_284 = Line_follower__safe_motor_update_out_st.new_speed;
          v_280 = (pid_error/2);
          Line_follower__safe_motor_update_step(Line_follower__base_speed,
                                                v_280,
                                                &Line_follower__safe_motor_update_out_st);
          v_281 = Line_follower__safe_motor_update_out_st.new_speed;
          Line_follower__abs_step(pid_error, &Line_follower__abs_out_st);
          v_278 = Line_follower__abs_out_st.out;
          sharp_thresh_1 = 30;
          v_294 = (v_293<=sharp_thresh_1);
          if (v_294) {
            dir_St_4_BonW_St_2_PID = 1;
          } else {
            dir_St_4_BonW_St_2_PID = v_296;
          };
          v_286 = (v_285<=sharp_thresh_1);
          if (v_286) {
            v_r_St_4_BonW_St_2_PID = v_289;
          } else {
            v_r_St_4_BonW_St_2_PID = v_292;
          };
          v_279 = (v_278<=sharp_thresh_1);
          if (v_279) {
            v_l_St_4_BonW_St_2_PID = v_281;
          } else {
            v_l_St_4_BonW_St_2_PID = v_284;
          };
          nr_2_St_2_PID = false;
          ns_2_St_2_PID = Line_follower__St_2_PID;
          last_error_St_4_BonW = last_error_St_4_BonW_St_2_PID;
          v_l_St_4_BonW = v_l_St_4_BonW_St_2_PID;
          v_r_St_4_BonW = v_r_St_4_BonW_St_2_PID;
          dir_St_4_BonW = dir_St_4_BonW_St_2_PID;
          inx_counter_St_4_BonW = inx_counter_St_4_BonW_St_2_PID;
          break;
        case Line_follower__St_2_Intersection:
          last_error_St_4_BonW_St_2_Intersection = self->last_error_1;
          v_276 = (r_4||r_2);
          if (v_276) {
            pnr_1 = false;
          } else {
            pnr_1 = self->v_277;
          };
          r_1 = pnr_1;
          v_274 = (r_4||r_2);
          if (v_274) {
            ck_6 = Line_follower__St_1_Counter;
          } else {
            ck_6 = self->v_275;
          };
          last_error_St_4_BonW = last_error_St_4_BonW_St_2_Intersection;
          switch (ck_6) {
            case Line_follower__St_1_Counter:
              complete_St_1_Counter = false;
              inx_counter_St_4_BonW_St_2_Intersection_St_1_Counter = (self->inx_counter_1+1);
              v_r_St_4_BonW_St_2_Intersection_St_1_Counter = 0;
              v_l_St_4_BonW_St_2_Intersection_St_1_Counter = 0;
              dir_St_4_BonW_St_2_Intersection_St_1_Counter = 0;
              if (true) {
                nr_1_St_1_Counter = true;
              } else {
                nr_1_St_1_Counter = false;
              };
              if (true) {
                ns_1_St_1_Counter = Line_follower__St_1_Entry;
              } else {
                ns_1_St_1_Counter = Line_follower__St_1_Counter;
              };
              v_l_St_4_BonW_St_2_Intersection = v_l_St_4_BonW_St_2_Intersection_St_1_Counter;
              v_r_St_4_BonW_St_2_Intersection = v_r_St_4_BonW_St_2_Intersection_St_1_Counter;
              dir_St_4_BonW_St_2_Intersection = dir_St_4_BonW_St_2_Intersection_St_1_Counter;
              inx_counter_St_4_BonW_St_2_Intersection = inx_counter_St_4_BonW_St_2_Intersection_St_1_Counter;
              break;
            case Line_follower__St_1_Entry:
              inx_counter_St_4_BonW_St_2_Intersection_St_1_Entry = self->inx_counter_1;
              v_r_St_4_BonW_St_2_Intersection_St_1_Entry = 50;
              v_l_St_4_BonW_St_2_Intersection_St_1_Entry = 50;
              dir_St_4_BonW_St_2_Intersection_St_1_Entry = 1;
              v_l_St_4_BonW_St_2_Intersection = v_l_St_4_BonW_St_2_Intersection_St_1_Entry;
              v_r_St_4_BonW_St_2_Intersection = v_r_St_4_BonW_St_2_Intersection_St_1_Entry;
              dir_St_4_BonW_St_2_Intersection = dir_St_4_BonW_St_2_Intersection_St_1_Entry;
              inx_counter_St_4_BonW_St_2_Intersection = inx_counter_St_4_BonW_St_2_Intersection_St_1_Entry;
              break;
            case Line_follower__St_1_ExitRight:
              inx_counter_St_4_BonW_St_2_Intersection_St_1_ExitRight = self->inx_counter_1;
              complete_St_1_ExitRight = !(all_high);
              v_r_St_4_BonW_St_2_Intersection_St_1_ExitRight = 30;
              v_l_St_4_BonW_St_2_Intersection_St_1_ExitRight = 30;
              dir_St_4_BonW_St_2_Intersection_St_1_ExitRight = 3;
              nr_1_St_1_ExitRight = false;
              ns_1_St_1_ExitRight = Line_follower__St_1_ExitRight;
              v_l_St_4_BonW_St_2_Intersection = v_l_St_4_BonW_St_2_Intersection_St_1_ExitRight;
              v_r_St_4_BonW_St_2_Intersection = v_r_St_4_BonW_St_2_Intersection_St_1_ExitRight;
              dir_St_4_BonW_St_2_Intersection = dir_St_4_BonW_St_2_Intersection_St_1_ExitRight;
              inx_counter_St_4_BonW_St_2_Intersection = inx_counter_St_4_BonW_St_2_Intersection_St_1_ExitRight;
              break;
            case Line_follower__St_1_ExitLeft:
              inx_counter_St_4_BonW_St_2_Intersection_St_1_ExitLeft = self->inx_counter_1;
              v_268 = sen[0];
              complete_St_1_ExitLeft = (v_268<=Line_follower__low_thresh);
              v_r_St_4_BonW_St_2_Intersection_St_1_ExitLeft = 30;
              v_l_St_4_BonW_St_2_Intersection_St_1_ExitLeft = 30;
              dir_St_4_BonW_St_2_Intersection_St_1_ExitLeft = 2;
              nr_1_St_1_ExitLeft = false;
              ns_1_St_1_ExitLeft = Line_follower__St_1_ExitLeft;
              v_l_St_4_BonW_St_2_Intersection = v_l_St_4_BonW_St_2_Intersection_St_1_ExitLeft;
              v_r_St_4_BonW_St_2_Intersection = v_r_St_4_BonW_St_2_Intersection_St_1_ExitLeft;
              dir_St_4_BonW_St_2_Intersection = dir_St_4_BonW_St_2_Intersection_St_1_ExitLeft;
              inx_counter_St_4_BonW_St_2_Intersection = inx_counter_St_4_BonW_St_2_Intersection_St_1_ExitLeft;
              break;
            default:
              break;
          };
          v_l_St_4_BonW = v_l_St_4_BonW_St_2_Intersection;
          v_r_St_4_BonW = v_r_St_4_BonW_St_2_Intersection;
          dir_St_4_BonW = dir_St_4_BonW_St_2_Intersection;
          inx_counter_St_4_BonW = inx_counter_St_4_BonW_St_2_Intersection;
          break;
        default:
          break;
      };
      last_error = last_error_St_4_BonW;
      inx_counter = inx_counter_St_4_BonW;
      v_266 = (inx_counter==4);
      if (v_266) {
        nr_4_St_4_BonW = true;
        ns_4_St_4_BonW = Line_follower__St_4_Stop;
      } else {
        nr_4_St_4_BonW = false;
        ns_4_St_4_BonW = Line_follower__St_4_BonW;
      };
      switch (ck_5) {
        case Line_follower__St_2_Intersection:
          switch (ck_6) {
            case Line_follower__St_1_Entry:
              complete_St_1_Entry = (inx_counter>=5);
              v_269 = (inx_counter==1);
              v_270 = !(v_269);
              v_271 = (v_270&&only_one_low);
              if (v_271) {
                v_273 = true;
              } else {
                v_273 = false;
              };
              if (all_high) {
                nr_1_St_1_Entry = true;
              } else {
                nr_1_St_1_Entry = v_273;
              };
              if (v_271) {
                v_272 = Line_follower__St_1_ExitLeft;
              } else {
                v_272 = Line_follower__St_1_Entry;
              };
              if (all_high) {
                ns_1_St_1_Entry = Line_follower__St_1_ExitRight;
              } else {
                ns_1_St_1_Entry = v_272;
              };
              complete = complete_St_1_Entry;
              ns_1 = ns_1_St_1_Entry;
              nr_1 = nr_1_St_1_Entry;
              break;
            case Line_follower__St_1_ExitLeft:
              complete = complete_St_1_ExitLeft;
              ns_1 = ns_1_St_1_ExitLeft;
              nr_1 = nr_1_St_1_ExitLeft;
              break;
            case Line_follower__St_1_ExitRight:
              complete = complete_St_1_ExitRight;
              ns_1 = ns_1_St_1_ExitRight;
              nr_1 = nr_1_St_1_ExitRight;
              break;
            case Line_follower__St_1_Counter:
              complete = complete_St_1_Counter;
              ns_1 = ns_1_St_1_Counter;
              nr_1 = nr_1_St_1_Counter;
              break;
            default:
              break;
          };
          if (complete) {
            nr_2_St_2_Intersection = true;
            ns_2_St_2_Intersection = Line_follower__St_2_PID;
          } else {
            nr_2_St_2_Intersection = false;
            ns_2_St_2_Intersection = Line_follower__St_2_Intersection;
          };
          ns_2 = ns_2_St_2_Intersection;
          nr_2 = nr_2_St_2_Intersection;
          break;
        case Line_follower__St_2_PID:
          ns_2 = ns_2_St_2_PID;
          nr_2 = nr_2_St_2_PID;
          break;
        default:
          break;
      };
      _out->v_l = v_l_St_4_BonW;
      _out->v_r = v_r_St_4_BonW;
      _out->dir = dir_St_4_BonW;
      ns_4 = ns_4_St_4_BonW;
      nr_4 = nr_4_St_4_BonW;
      {
        long _23;
        for (_23 = 0; _23 < 5; ++_23) {
          min_vals_St_4_BonW[_23] = self->min_vals_1[_23];
        }
      };
      {
        long _24;
        for (_24 = 0; _24 < 5; ++_24) {
          max_vals_St_4_BonW[_24] = self->max_vals_1[_24];
        }
      };
      {
        long _25;
        for (_25 = 0; _25 < 5; ++_25) {
          min_vals[_25] = min_vals_St_4_BonW[_25];
        }
      };
      {
        long _26;
        for (_26 = 0; _26 < 5; ++_26) {
          max_vals[_26] = max_vals_St_4_BonW[_26];
        }
      };
      self->v_300 = nr_2;
      self->v_267 = ns_2;
      break;
    case Line_follower__St_4_ObstacleAvoid:
      inx_counter_St_4_ObstacleAvoid = self->inx_counter_1;
      last_error_St_4_ObstacleAvoid = self->last_error_1;
      pid_error_St_4_ObstacleAvoid = self->pid_error_3;
      if (r_4) {
        pnr_3 = false;
        ck_7 = Line_follower__St_3_Wait;
      } else {
        pnr_3 = self->v_265;
        ck_7 = self->v_240;
      };
      v_207 = !(all_high);
      if (self->v_204) {
        v_205 = true;
      } else {
        v_205 = r_4;
      };
      if (self->v_202) {
        v_203 = true;
      } else {
        v_203 = all_very_high;
      };
      if (self->v_200) {
        v_201 = true;
      } else {
        v_201 = r_4;
      };
      if (v_201) {
        white_happened = false;
      } else {
        white_happened = v_203;
      };
      v_208 = (white_happened&&v_207);
      if (self->v_206) {
        v_209 = true;
      } else {
        v_209 = v_208;
      };
      if (v_205) {
        black_happend = false;
      } else {
        black_happend = v_209;
      };
      pid_error = pid_error_St_4_ObstacleAvoid;
      switch (ck_7) {
        case Line_follower__St_3_Wait:
          r_3_St_3_Wait = pnr_3;
          s_3_St_3_Wait = Line_follower__St_3_Wait;
          s_3 = s_3_St_3_Wait;
          r_3 = r_3_St_3_Wait;
          break;
        case Line_follower__St_3_FullRight:
          if (all_low) {
            v_239 = true;
          } else {
            v_239 = pnr_3;
          };
          if (obs_left) {
            r_3_St_3_FullRight = true;
          } else {
            r_3_St_3_FullRight = v_239;
          };
          if (all_low) {
            v_238 = Line_follower__St_3_SlightLeft;
          } else {
            v_238 = Line_follower__St_3_FullRight;
          };
          if (obs_left) {
            s_3_St_3_FullRight = Line_follower__St_3_SlightRight;
          } else {
            s_3_St_3_FullRight = v_238;
          };
          s_3 = s_3_St_3_FullRight;
          r_3 = r_3_St_3_FullRight;
          break;
        case Line_follower__St_3_SlightRight:
          if (black_happend) {
            v_235 = true;
            v_234 = Line_follower__St_3_ExitStart;
          } else {
            v_235 = pnr_3;
            v_234 = Line_follower__St_3_SlightRight;
          };
          v_232 = (ir_value==0);
          v_233 = !(v_232);
          if (v_233) {
            v_237 = true;
            v_236 = Line_follower__St_3_FullRight;
          } else {
            v_237 = v_235;
            v_236 = v_234;
          };
          v_231 = !(obs_left);
          if (v_231) {
            r_3_St_3_SlightRight = true;
            s_3_St_3_SlightRight = Line_follower__St_3_SlightLeft;
          } else {
            r_3_St_3_SlightRight = v_237;
            s_3_St_3_SlightRight = v_236;
          };
          s_3 = s_3_St_3_SlightRight;
          r_3 = r_3_St_3_SlightRight;
          break;
        case Line_follower__St_3_SlightLeft:
          if (black_happend) {
            v_228 = true;
            v_227 = Line_follower__St_3_ExitStart;
          } else {
            v_228 = pnr_3;
            v_227 = Line_follower__St_3_SlightLeft;
          };
          v_225 = (ir_value==0);
          v_226 = !(v_225);
          if (v_226) {
            v_230 = true;
          } else {
            v_230 = v_228;
          };
          if (obs_left) {
            r_3_St_3_SlightLeft = true;
          } else {
            r_3_St_3_SlightLeft = v_230;
          };
          if (v_226) {
            v_229 = Line_follower__St_3_FullRight;
          } else {
            v_229 = v_227;
          };
          if (obs_left) {
            s_3_St_3_SlightLeft = Line_follower__St_3_SlightRight;
          } else {
            s_3_St_3_SlightLeft = v_229;
          };
          s_3 = s_3_St_3_SlightLeft;
          r_3 = r_3_St_3_SlightLeft;
          break;
        case Line_follower__St_3_ExitStart:
          v_220 = sen[4];
          v_221 = (v_220<=Line_follower__low_thresh);
          v_217 = sen[3];
          v_218 = (v_217<=Line_follower__low_thresh);
          v_215 = sen[2];
          v_216 = (v_215<=Line_follower__low_thresh);
          v_219 = (v_216||v_218);
          v_222 = (v_219||v_221);
          if (v_222) {
            v_224 = true;
            v_223 = Line_follower__St_3_ExitEnd2;
          } else {
            v_224 = pnr_3;
            v_223 = Line_follower__St_3_ExitStart;
          };
          v_212 = sen[1];
          v_213 = (v_212<=Line_follower__low_thresh);
          v_210 = sen[0];
          v_211 = (v_210<=Line_follower__low_thresh);
          v_214 = (v_211||v_213);
          if (v_214) {
            r_3_St_3_ExitStart = true;
            s_3_St_3_ExitStart = Line_follower__St_3_ExitEnd1;
          } else {
            r_3_St_3_ExitStart = v_224;
            s_3_St_3_ExitStart = v_223;
          };
          s_3 = s_3_St_3_ExitStart;
          r_3 = r_3_St_3_ExitStart;
          break;
        case Line_follower__St_3_ExitEnd1:
          r_3_St_3_ExitEnd1 = pnr_3;
          s_3_St_3_ExitEnd1 = Line_follower__St_3_ExitEnd1;
          s_3 = s_3_St_3_ExitEnd1;
          r_3 = r_3_St_3_ExitEnd1;
          break;
        case Line_follower__St_3_ExitEnd2:
          r_3_St_3_ExitEnd2 = pnr_3;
          s_3_St_3_ExitEnd2 = Line_follower__St_3_ExitEnd2;
          s_3 = s_3_St_3_ExitEnd2;
          r_3 = r_3_St_3_ExitEnd2;
          break;
        default:
          break;
      };
      ck_8 = s_3;
      last_error = last_error_St_4_ObstacleAvoid;
      inx_counter = inx_counter_St_4_ObstacleAvoid;
      switch (ck_8) {
        case Line_follower__St_3_Wait:
          v_264 = (ir_value==0);
          if (v_264) {
            complete_1_St_3_Wait = true;
          } else {
            complete_1_St_3_Wait = false;
          };
          v_263 = (self->v_262+1);
          v_260 = (r_4||r_3);
          if (self->v_259) {
            v_261 = true;
          } else {
            v_261 = v_260;
          };
          if (v_261) {
            ncycles_1 = 0;
          } else {
            ncycles_1 = v_263;
          };
          dir_St_4_ObstacleAvoid_St_3_Wait = 9;
          v_r_St_4_ObstacleAvoid_St_3_Wait = 0;
          v_l_St_4_ObstacleAvoid_St_3_Wait = 0;
          v_258 = (ncycles_1>1000);
          if (v_258) {
            nr_3_St_3_Wait = true;
            ns_3_St_3_Wait = Line_follower__St_3_FullRight;
          } else {
            nr_3_St_3_Wait = false;
            ns_3_St_3_Wait = Line_follower__St_3_Wait;
          };
          v_l_St_4_ObstacleAvoid = v_l_St_4_ObstacleAvoid_St_3_Wait;
          v_r_St_4_ObstacleAvoid = v_r_St_4_ObstacleAvoid_St_3_Wait;
          dir_St_4_ObstacleAvoid = dir_St_4_ObstacleAvoid_St_3_Wait;
          complete_1 = complete_1_St_3_Wait;
          ns_3 = ns_3_St_3_Wait;
          nr_3 = nr_3_St_3_Wait;
          break;
        case Line_follower__St_3_FullRight:
          complete_1_St_3_FullRight = false;
          dir_St_4_ObstacleAvoid_St_3_FullRight = 3;
          v_r_St_4_ObstacleAvoid_St_3_FullRight = 30;
          v_l_St_4_ObstacleAvoid_St_3_FullRight = 30;
          nr_3_St_3_FullRight = false;
          ns_3_St_3_FullRight = Line_follower__St_3_FullRight;
          v_l_St_4_ObstacleAvoid = v_l_St_4_ObstacleAvoid_St_3_FullRight;
          v_r_St_4_ObstacleAvoid = v_r_St_4_ObstacleAvoid_St_3_FullRight;
          dir_St_4_ObstacleAvoid = dir_St_4_ObstacleAvoid_St_3_FullRight;
          complete_1 = complete_1_St_3_FullRight;
          ns_3 = ns_3_St_3_FullRight;
          nr_3 = nr_3_St_3_FullRight;
          break;
        case Line_follower__St_3_SlightRight:
          complete_1_St_3_SlightRight = false;
          v_r_St_4_ObstacleAvoid_St_3_SlightRight = 10;
          v_l_St_4_ObstacleAvoid_St_3_SlightRight = 50;
          dir_St_4_ObstacleAvoid_St_3_SlightRight = 1;
          nr_3_St_3_SlightRight = false;
          ns_3_St_3_SlightRight = Line_follower__St_3_SlightRight;
          v_l_St_4_ObstacleAvoid = v_l_St_4_ObstacleAvoid_St_3_SlightRight;
          v_r_St_4_ObstacleAvoid = v_r_St_4_ObstacleAvoid_St_3_SlightRight;
          dir_St_4_ObstacleAvoid = dir_St_4_ObstacleAvoid_St_3_SlightRight;
          complete_1 = complete_1_St_3_SlightRight;
          ns_3 = ns_3_St_3_SlightRight;
          nr_3 = nr_3_St_3_SlightRight;
          break;
        case Line_follower__St_3_SlightLeft:
          complete_1_St_3_SlightLeft = false;
          v_r_St_4_ObstacleAvoid_St_3_SlightLeft = 50;
          v_l_St_4_ObstacleAvoid_St_3_SlightLeft = 10;
          dir_St_4_ObstacleAvoid_St_3_SlightLeft = 1;
          nr_3_St_3_SlightLeft = false;
          ns_3_St_3_SlightLeft = Line_follower__St_3_SlightLeft;
          v_l_St_4_ObstacleAvoid = v_l_St_4_ObstacleAvoid_St_3_SlightLeft;
          v_r_St_4_ObstacleAvoid = v_r_St_4_ObstacleAvoid_St_3_SlightLeft;
          dir_St_4_ObstacleAvoid = dir_St_4_ObstacleAvoid_St_3_SlightLeft;
          complete_1 = complete_1_St_3_SlightLeft;
          ns_3 = ns_3_St_3_SlightLeft;
          nr_3 = nr_3_St_3_SlightLeft;
          break;
        case Line_follower__St_3_ExitStart:
          complete_1_St_3_ExitStart = false;
          v_r_St_4_ObstacleAvoid_St_3_ExitStart = 0;
          v_l_St_4_ObstacleAvoid_St_3_ExitStart = 0;
          dir_St_4_ObstacleAvoid_St_3_ExitStart = 9;
          nr_3_St_3_ExitStart = false;
          ns_3_St_3_ExitStart = Line_follower__St_3_ExitStart;
          v_l_St_4_ObstacleAvoid = v_l_St_4_ObstacleAvoid_St_3_ExitStart;
          v_r_St_4_ObstacleAvoid = v_r_St_4_ObstacleAvoid_St_3_ExitStart;
          dir_St_4_ObstacleAvoid = dir_St_4_ObstacleAvoid_St_3_ExitStart;
          complete_1 = complete_1_St_3_ExitStart;
          ns_3 = ns_3_St_3_ExitStart;
          nr_3 = nr_3_St_3_ExitStart;
          break;
        case Line_follower__St_3_ExitEnd1:
          complete_1_St_3_ExitEnd1 = true;
          v_r_St_4_ObstacleAvoid_St_3_ExitEnd1 = 30;
          v_l_St_4_ObstacleAvoid_St_3_ExitEnd1 = 30;
          dir_St_4_ObstacleAvoid_St_3_ExitEnd1 = 1;
          nr_3_St_3_ExitEnd1 = false;
          ns_3_St_3_ExitEnd1 = Line_follower__St_3_ExitEnd1;
          v_l_St_4_ObstacleAvoid = v_l_St_4_ObstacleAvoid_St_3_ExitEnd1;
          v_r_St_4_ObstacleAvoid = v_r_St_4_ObstacleAvoid_St_3_ExitEnd1;
          dir_St_4_ObstacleAvoid = dir_St_4_ObstacleAvoid_St_3_ExitEnd1;
          complete_1 = complete_1_St_3_ExitEnd1;
          ns_3 = ns_3_St_3_ExitEnd1;
          nr_3 = nr_3_St_3_ExitEnd1;
          break;
        case Line_follower__St_3_ExitEnd2:
          v_256 = sen[2];
          v_257 = (v_256<=Line_follower__low_thresh);
          v_252 = sen[2];
          v_253 = (v_252>=Line_follower__high_thresh);
          v_249 = (r_4||r_3);
          if (self->v_248) {
            v_250 = true;
          } else {
            v_250 = v_249;
          };
          v_245 = sen[1];
          v_246 = (v_245<=Line_follower__low_thresh);
          if (self->v_244) {
            v_247 = true;
          } else {
            v_247 = v_246;
          };
          v_242 = (r_4||r_3);
          if (self->v_241) {
            v_243 = true;
          } else {
            v_243 = v_242;
          };
          if (v_243) {
            sen_1_low1 = false;
          } else {
            sen_1_low1 = v_247;
          };
          v_254 = (sen_1_low1&&v_253);
          if (self->v_251) {
            v_255 = true;
          } else {
            v_255 = v_254;
          };
          if (v_250) {
            sen_1_high1 = false;
          } else {
            sen_1_high1 = v_255;
          };
          complete_1_St_3_ExitEnd2 = (sen_1_high1&&v_257);
          v_r_St_4_ObstacleAvoid_St_3_ExitEnd2 = 0;
          v_l_St_4_ObstacleAvoid_St_3_ExitEnd2 = 30;
          dir_St_4_ObstacleAvoid_St_3_ExitEnd2 = 1;
          nr_3_St_3_ExitEnd2 = false;
          ns_3_St_3_ExitEnd2 = Line_follower__St_3_ExitEnd2;
          v_l_St_4_ObstacleAvoid = v_l_St_4_ObstacleAvoid_St_3_ExitEnd2;
          v_r_St_4_ObstacleAvoid = v_r_St_4_ObstacleAvoid_St_3_ExitEnd2;
          dir_St_4_ObstacleAvoid = dir_St_4_ObstacleAvoid_St_3_ExitEnd2;
          complete_1 = complete_1_St_3_ExitEnd2;
          ns_3 = ns_3_St_3_ExitEnd2;
          nr_3 = nr_3_St_3_ExitEnd2;
          break;
        default:
          break;
      };
      if (complete_1) {
        nr_4_St_4_ObstacleAvoid = true;
        ns_4_St_4_ObstacleAvoid = Line_follower__St_4_BonW;
      } else {
        nr_4_St_4_ObstacleAvoid = false;
        ns_4_St_4_ObstacleAvoid = Line_follower__St_4_ObstacleAvoid;
      };
      _out->v_l = v_l_St_4_ObstacleAvoid;
      _out->v_r = v_r_St_4_ObstacleAvoid;
      _out->dir = dir_St_4_ObstacleAvoid;
      ns_4 = ns_4_St_4_ObstacleAvoid;
      nr_4 = nr_4_St_4_ObstacleAvoid;
      {
        long _27;
        for (_27 = 0; _27 < 5; ++_27) {
          min_vals_St_4_ObstacleAvoid[_27] = self->min_vals_1[_27];
        }
      };
      {
        long _28;
        for (_28 = 0; _28 < 5; ++_28) {
          min_vals[_28] = min_vals_St_4_ObstacleAvoid[_28];
        }
      };
      {
        long _29;
        for (_29 = 0; _29 < 5; ++_29) {
          max_vals_St_4_ObstacleAvoid[_29] = self->max_vals_1[_29];
        }
      };
      {
        long _30;
        for (_30 = 0; _30 < 5; ++_30) {
          max_vals[_30] = max_vals_St_4_ObstacleAvoid[_30];
        }
      };
      self->v_265 = nr_3;
      self->v_240 = ns_3;
      self->v_206 = black_happend;
      self->v_204 = false;
      self->v_202 = white_happened;
      self->v_200 = false;
      break;
    case Line_follower__St_4_Stop:
      inx_counter_St_4_Stop = self->inx_counter_1;
      last_error_St_4_Stop = self->last_error_1;
      pid_error_St_4_Stop = self->pid_error_3;
      v_r_St_4_Stop = 0;
      v_l_St_4_Stop = 0;
      dir_St_4_Stop = 9;
      nr_4_St_4_Stop = false;
      ns_4_St_4_Stop = Line_follower__St_4_Stop;
      pid_error = pid_error_St_4_Stop;
      last_error = last_error_St_4_Stop;
      inx_counter = inx_counter_St_4_Stop;
      _out->v_l = v_l_St_4_Stop;
      _out->v_r = v_r_St_4_Stop;
      _out->dir = dir_St_4_Stop;
      ns_4 = ns_4_St_4_Stop;
      nr_4 = nr_4_St_4_Stop;
      {
        long _31;
        for (_31 = 0; _31 < 5; ++_31) {
          min_vals_St_4_Stop[_31] = self->min_vals_1[_31];
        }
      };
      {
        long _32;
        for (_32 = 0; _32 < 5; ++_32) {
          min_vals[_32] = min_vals_St_4_Stop[_32];
        }
      };
      {
        long _33;
        for (_33 = 0; _33 < 5; ++_33) {
          max_vals_St_4_Stop[_33] = self->max_vals_1[_33];
        }
      };
      {
        long _34;
        for (_34 = 0; _34 < 5; ++_34) {
          max_vals[_34] = max_vals_St_4_Stop[_34];
        }
      };
      break;
    default:
      break;
  };
  self->inx_counter_1 = inx_counter;
  {
    long _35;
    for (_35 = 0; _35 < 5; ++_35) {
      self->sen_2[_35] = sen[_35];
    }
  };
  {
    long _36;
    for (_36 = 0; _36 < 5; ++_36) {
      self->min_vals_1[_36] = min_vals[_36];
    }
  };
  {
    long _37;
    for (_37 = 0; _37 < 5; ++_37) {
      self->max_vals_1[_37] = max_vals[_37];
    }
  };
  self->last_error_1 = last_error;
  self->pid_error_3 = pid_error;
  self->pnr_4 = nr_4;
  self->ck = ns_4;
  switch (ck_1) {
    case Line_follower__St_4_BonW:
      switch (ck_5) {
        case Line_follower__St_2_Intersection:
          self->v_277 = nr_1;
          self->v_275 = ns_1;
          break;
        default:
          break;
      };
      break;
    case Line_follower__St_4_ObstacleAvoid:
      switch (ck_8) {
        case Line_follower__St_3_Wait:
          self->v_262 = ncycles_1;
          self->v_259 = false;
          break;
        case Line_follower__St_3_ExitEnd2:
          self->v_251 = sen_1_high1;
          self->v_248 = false;
          self->v_244 = sen_1_low1;
          self->v_241 = false;
          break;
        default:
          break;
      };
      break;
    default:
      break;
  };;
}

