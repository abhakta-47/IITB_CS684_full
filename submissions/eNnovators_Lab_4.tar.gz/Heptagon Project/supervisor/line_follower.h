/* --- Generated the 28/3/2025 at 10:28 --- */
/* --- heptagon compiler, version 1.05.00 (compiled sat. mar. 8 9:40:4 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#ifndef LINE_FOLLOWER_H
#define LINE_FOLLOWER_H

#include "line_follower_types.h"
typedef struct Line_follower__calPidError_mem {
  long v_10;
  long v_9;
  long v_6;
  long v_5;
  long v_1;
  long v;
} Line_follower__calPidError_mem;

typedef struct Line_follower__calPidError_out {
  long pid_error;
} Line_follower__calPidError_out;

void Line_follower__calPidError_reset(Line_follower__calPidError_mem* self);

void Line_follower__calPidError_step(long value, long scale_down,
                                     Line_follower__calPidError_out* _out,
                                     Line_follower__calPidError_mem* self);

typedef struct Line_follower__weightedSum_out {
  long weighted_sum;
} Line_follower__weightedSum_out;

void Line_follower__weightedSum_step(long sen_value, long sen_weight,
                                     long prev_sum,
                                     Line_follower__weightedSum_out* _out);

typedef struct Line_follower__senWeightedAvg_out {
  long sensor_avg;
} Line_follower__senWeightedAvg_out;

void Line_follower__senWeightedAvg_step(long sen[5],
                                        Line_follower__senWeightedAvg_out* _out);

typedef struct Line_follower__safe_motor_update_out {
  long new_speed;
} Line_follower__safe_motor_update_out;

void Line_follower__safe_motor_update_step(long cur_speed, long change,
                                           Line_follower__safe_motor_update_out* _out);

typedef struct Line_follower__normalize_value_out {
  long norm_val;
} Line_follower__normalize_value_out;

void Line_follower__normalize_value_step(long min_val, long max_val, long value,
                                         Line_follower__normalize_value_out* _out);

typedef struct Line_follower__updateMins_out {
  long new_min;
} Line_follower__updateMins_out;

void Line_follower__updateMins_step(long cur_val, long cur_min,
                                    Line_follower__updateMins_out* _out);

typedef struct Line_follower__updateMaxs_out {
  long new_max;
} Line_follower__updateMaxs_out;

void Line_follower__updateMaxs_step(long cur_val, long cur_max,
                                    Line_follower__updateMaxs_out* _out);

typedef struct Line_follower__abs_out {
  long out;
} Line_follower__abs_out;

void Line_follower__abs_step(long input, Line_follower__abs_out* _out);

typedef struct Line_follower__main_mem {
  Line_follower__st_4 ck;
  Line_follower__st_3 v_240;
  long v_251;
  long v_248;
  long v_244;
  long v_241;
  long v_262;
  long v_259;
  long v_265;
  long v_206;
  long v_204;
  long v_202;
  long v_200;
  Line_follower__st_2 v_267;
  Line_follower__st_1 v_275;
  long v_277;
  long v_300;
  Line_follower__st v_331;
  long v_372;
  long v_376;
  long v_374;
  long pnr_4;
  long inx_counter_1;
  long sen_2[5];
  long min_vals_1[5];
  long max_vals_1[5];
  long last_error_1;
  long pid_error_3;
  Line_follower__calPidError_mem calPidError;
  Line_follower__calPidError_mem calPidError_1;
} Line_follower__main_mem;

typedef struct Line_follower__main_out {
  long v_l;
  long v_r;
  long dir;
} Line_follower__main_out;

void Line_follower__main_reset(Line_follower__main_mem* self);

void Line_follower__main_step(long sen0, long sen1, long sen2, long sen3,
                              long sen4, long ir_value, long obs_left,
                              long obs_right, Line_follower__main_out* _out,
                              Line_follower__main_mem* self);

#endif // LINE_FOLLOWER_H
